import { Hotel } from '../../src/types';

export interface CuratedHotelData {
  name: string;
  category: string;
  tier: 'Budget' | 'Mid-Range' | 'Luxury';
  address: string;
  price: number;
  rating: number;
  reviewCount: number;
  amenities: string[];
  phone?: string;
  officialWebsite?: string;
  imageUrl: string;
  cancellationPolicy?: string;
}

export const curatedHotelsByDestination: Record<string, CuratedHotelData[]> = {
  // Rajasthan
  'jodhpur': [
    {
      name: 'Umaid Bhawan Palace, Jodhpur',
      category: 'Luxury Palace',
      tier: 'Luxury',
      address: 'Circuit House Road, Cantt Area, Jodhpur, Rajasthan 342006',
      price: 42000,
      rating: 4.9,
      reviewCount: 3820,
      amenities: ['Private Royal Butler Service', 'Jiva Grande Spa', 'Subterranean Zodiac Swimming Pool', 'Polo Heritage Tours', 'Fine Dining Risala'],
      phone: '+91 291 251 0101',
      officialWebsite: 'https://www.tajhotels.com/en-in/taj/umaid-bhawan-palace-jodhpur/',
      imageUrl: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 72 hours before arrival.'
    },
    {
      name: 'RAAS Jodhpur - Boutique Heritage Hotel',
      category: 'Heritage Haveli',
      tier: 'Luxury',
      address: 'Tunwar ji ka Jhalra, Makrana Mohalla, Jodhpur, Rajasthan 342001',
      price: 18500,
      rating: 4.8,
      reviewCount: 1940,
      amenities: ['Direct Mehrangarh Fort Views', 'Stepwell Courtyard Dining', 'Heated Swimming Pool', 'Ayurvedic Spa Treatments', 'High-Speed Wi-Fi'],
      phone: '+91 291 263 6455',
      officialWebsite: 'https://raashotels.com/jodhpur/',
      imageUrl: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 48 hours before arrival.'
    },
    {
      name: 'Ajit Bhawan - A Palace Resort',
      category: 'Heritage Haveli',
      tier: 'Luxury',
      address: 'Near Circuit House, National Highway 65, Jodhpur, Rajasthan 342006',
      price: 11000,
      rating: 4.7,
      reviewCount: 1420,
      amenities: ['Vintage Car Rides', 'Garden Swimming Pool', 'Traditional Rajasthani Thali Dining', 'Spa & Wellness', 'Valet Parking'],
      phone: '+91 291 251 0410',
      officialWebsite: 'https://ajitbhawan.com/',
      imageUrl: 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 48 hours before check-in.'
    },
    {
      name: 'Ratan Vilas Heritage Hotel',
      category: 'Heritage Haveli',
      tier: 'Mid-Range',
      address: 'Loco Shed Road, Near Bhaskar Circle, Ratanada, Jodhpur, Rajasthan 342001',
      price: 6500,
      rating: 4.8,
      reviewCount: 1180,
      amenities: ['Colonial Verandah', 'Courtyard Swimming Pool', 'Home-cooked Rajasthani Dining', 'Free Wi-Fi', 'Heritage Garden'],
      phone: '+91 291 261 4418',
      officialWebsite: 'https://www.ratanvilas.com/',
      imageUrl: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 48 hours before arrival.'
    },
    {
      name: 'The Ummed Jodhpur Palace Resort & Spa',
      category: '5-Star Luxury',
      tier: 'Mid-Range',
      address: 'Banar Road, Mandore, Jodhpur, Rajasthan 342027',
      price: 7200,
      rating: 4.6,
      reviewCount: 2100,
      amenities: ['28 Acres Landscaped Gardens', 'Grand Outdoor Pool', 'Courtyard Bar', 'Fitness Center', 'Free Breakfast Buffet'],
      phone: '+91 291 662 1111',
      officialWebsite: 'https://www.ummedhotels.com/jodhpur/',
      imageUrl: 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 24 hours before arrival.'
    },
    {
      name: 'Pal Haveli Heritage Hotel',
      category: 'Heritage Haveli',
      tier: 'Budget',
      address: 'Gulab Sagar, Near Clock Tower, Jodhpur, Rajasthan 342001',
      price: 3800,
      rating: 4.5,
      reviewCount: 960,
      amenities: ['Rooftop Fort View Restaurant', 'Historic Haveli Rooms', 'Old City Walk Guide', 'Free Wi-Fi', '24/7 Front Desk'],
      phone: '+91 291 329 3328',
      officialWebsite: 'https://www.palhaveli.com/',
      imageUrl: 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 48 hours before check-in.'
    }
  ],

  'jaisalmer': [
    {
      name: 'Suryagarh Jaisalmer',
      category: 'Luxury Palace',
      tier: 'Luxury',
      address: 'Kahala Phata, Sam Road, Jaisalmer, Rajasthan 345001',
      price: 24000,
      rating: 4.9,
      reviewCount: 2890,
      amenities: ['Rakt Safaris into Thar Desert', 'The Rait Spa Treatments', 'Indoor Heated Pool', 'Silk Route Fine Dining', 'Folk Musical Soirees'],
      phone: '+91 78271 51151',
      officialWebsite: 'https://www.suryagarh.com/',
      imageUrl: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 72 hours before arrival.'
    },
    {
      name: 'Jaisalmer Marriott Resort & Spa',
      category: '5-Star Luxury',
      tier: 'Luxury',
      address: 'Jaisalmer-Sam-Dhanana Road, Police Line, Jaisalmer, Rajasthan 345001',
      price: 14500,
      rating: 4.7,
      reviewCount: 2240,
      amenities: ['Quan Spa', 'Heated Outdoor Pool', 'Golden Fort Views', 'Jaisalmer Kitchen', 'Ballroom & Lawns'],
      phone: '+91 2992 266 500',
      officialWebsite: 'https://www.marriott.com/en-us/hotels/jsamc-jaisalmer-marriott-resort-and-spa/',
      imageUrl: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 48 hours before check-in.'
    },
    {
      name: 'Fort Rajwada Jaisalmer',
      category: 'Heritage Haveli',
      tier: 'Mid-Range',
      address: 'Hotel Complex, 1, Jodhpur Barmer Link Road, Jaisalmer, Rajasthan 345001',
      price: 7800,
      rating: 4.6,
      reviewCount: 1650,
      amenities: ['Stone Carved Jharokhas', 'Billiards Room', 'Ayurvedic Massage Center', 'Swimming Pool', 'Camel Safari Desk'],
      phone: '+91 2992 253 293',
      officialWebsite: 'https://www.fortrajwada.com/',
      imageUrl: 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 48 hours before arrival.'
    },
    {
      name: 'Gorbandh Palace - IHCL SeleQtions',
      category: 'Heritage Haveli',
      tier: 'Mid-Range',
      address: 'Tourist Complex, Sam Road, Jaisalmer, Rajasthan 345001',
      price: 8500,
      rating: 4.7,
      reviewCount: 1390,
      amenities: ['Central Pool Courtyard', 'Bikaneri Jharokha Architecture', 'Baradari Multi-Cuisine Dining', 'Free Wi-Fi', 'Evening Cultural Dance'],
      phone: '+91 2992 253 801',
      officialWebsite: 'https://www.seleqtionshotels.com/en-in/gorbandh-palace-jaisalmer/',
      imageUrl: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 48 hours before check-in.'
    },
    {
      name: 'Hotel Rang Mahal Jaisalmer',
      category: 'Comfort 3-Star',
      tier: 'Budget',
      address: '5, Hotel Complex, Sam Road, Jaisalmer, Rajasthan 345001',
      price: 4500,
      rating: 4.5,
      reviewCount: 1200,
      amenities: ['Swimming Pool', 'Rajasthani Folk Evenings', 'Free Breakfast Buffet', 'Travel Desk', 'Wi-Fi Access'],
      phone: '+91 2992 250 907',
      officialWebsite: 'https://hotelrangmahal.com/',
      imageUrl: 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 24 hours before arrival.'
    }
  ],

  // Himachal Pradesh
  'shimla': [
    {
      name: 'Wildflower Hall, An Oberoi Resort, Shimla',
      category: 'Luxury Palace',
      tier: 'Luxury',
      address: 'Chharabra, Shimla, Himachal Pradesh 171012',
      price: 36000,
      rating: 4.9,
      reviewCount: 3100,
      amenities: ['Open-Air Heated Whirlpool Overlooking Himalayas', 'Lord Kitchener Cedar Library', 'Oberoi Spa in Deodar Woods', 'Nature Walking Trails', 'Fine Dining The Restaurant'],
      phone: '+91 177 264 8585',
      officialWebsite: 'https://www.oberoihotels.com/hotels-in-shimla-wfh/',
      imageUrl: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 7 days before check-in.'
    },
    {
      name: 'The Oberoi Cecil, Shimla',
      category: 'Heritage Haveli',
      tier: 'Luxury',
      address: 'Chaura Maidan, Shimla, Himachal Pradesh 171004',
      price: 21000,
      rating: 4.8,
      reviewCount: 2450,
      amenities: ['Indoor Heated Swimming Pool', 'Heritage Ballroom Dining', 'Children Activity Center', 'Full-service Spa', 'Historical Walking Tours'],
      phone: '+91 177 280 4848',
      officialWebsite: 'https://www.oberoihotels.com/hotels-in-shimla-cecil/',
      imageUrl: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 48 hours before arrival.'
    },
    {
      name: 'Clarkes Hotel, Shimla - Heritage Est. 1898',
      category: 'Heritage Haveli',
      tier: 'Mid-Range',
      address: 'The Mall Road, Shimla, Himachal Pradesh 171001',
      price: 9500,
      rating: 4.7,
      reviewCount: 1540,
      amenities: ['Direct Mall Road Pedestrian Access', 'Colonial Dining Hall', '18th-century Lounge Bar', 'Complimentary Wi-Fi', 'Concierge Service'],
      phone: '+91 177 265 1010',
      officialWebsite: 'https://www.clarkeshotel.com/',
      imageUrl: 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 48 hours before check-in.'
    },
    {
      name: 'Radisson Hotel Shimla',
      category: '5-Star Luxury',
      tier: 'Mid-Range',
      address: 'Goodwood Estate, Lower Bharari Road, Shimla, Himachal Pradesh 171001',
      price: 7800,
      rating: 4.6,
      reviewCount: 1890,
      amenities: ['Cedar Garden Terrace', 'Outdoor Heated Swimming Pool', 'Cafe Valley Vue', 'Gymnasium & Spa', 'Mountain View Balconies'],
      phone: '+91 177 265 9012',
      officialWebsite: 'https://www.radissonhotels.com/en-us/hotels/radisson-shimla',
      imageUrl: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 24 hours before check-in.'
    },
    {
      name: 'Hotel Combermere Shimla',
      category: 'Comfort 3-Star',
      tier: 'Budget',
      address: 'The Mall, Opposite Tourism Lift, Shimla, Himachal Pradesh 171001',
      price: 4900,
      rating: 4.5,
      reviewCount: 2200,
      amenities: ['Direct Passenger Lift to Mall Road', 'Seventh Heaven Multi-Cuisine Restaurant', 'Nightclub & Bar', 'Games Room', 'Free Wi-Fi'],
      phone: '+91 177 265 1246',
      officialWebsite: 'https://www.hotelcombermere.com/',
      imageUrl: 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 24 hours before arrival.'
    }
  ],

  'dharamshala-mcleodganj': [
    {
      name: 'Hyatt Regency Dharamshala Resort',
      category: '5-Star Luxury',
      tier: 'Luxury',
      address: 'Village Kandi, Dharamshala, Himachal Pradesh 176215',
      price: 16500,
      rating: 4.8,
      reviewCount: 1820,
      amenities: ['Heated Indoor Shanti Pool', 'Shambhala Spa', 'Himalayan Cedar Woods Trail', 'Thym Food & Wine Dining', 'Meditation Pavilion'],
      phone: '+91 1892 242 123',
      officialWebsite: 'https://www.hyatt.com/en-US/hotel/india/hyatt-regency-dharamshala-resort/dhmrd',
      imageUrl: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 48 hours before check-in.'
    },
    {
      name: 'Fortune Park Moksha, McLeod Ganj',
      category: 'Boutique Resort',
      tier: 'Mid-Range',
      address: 'Strawberry Hills, Satobari, Near Dal Lake, McLeod Ganj, Dharamshala 176216',
      price: 7500,
      rating: 4.6,
      reviewCount: 1410,
      amenities: ['Outdoor Heated Pool', 'Dhauladhar Mountain Vistas', 'Orchid Multi-Cuisine Dining', 'Fitness Center & Sauna', 'Nature Walk Guide'],
      phone: '+91 1892 242 424',
      officialWebsite: 'https://www.fortunehotels.in/mcleod-ganj-fortune-park-moksha.dh.33',
      imageUrl: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 48 hours before check-in.'
    },
    {
      name: 'The Pavillion by HPCA, Dharamshala',
      category: 'Comfort 3-Star',
      tier: 'Budget',
      address: 'Kandi Village, Khanyara Road, Dharamshala, Himachal Pradesh 176215',
      price: 4800,
      rating: 4.5,
      reviewCount: 1100,
      amenities: ['Cricket Theme Pavilion', 'Swimming Pool', 'Mountain View Restaurant', 'Spa Facilities', 'Complimentary Breakfast'],
      phone: '+91 1892 229 600',
      officialWebsite: 'https://thepavilion.in/',
      imageUrl: 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 24 hours before check-in.'
    }
  ],

  // Uttar Pradesh
  'lucknow': [
    {
      name: 'Taj Mahal Lucknow (Gomti Nagar)',
      category: '5-Star Luxury',
      tier: 'Luxury',
      address: 'Vipin Khand, Gomti Nagar, Lucknow, Uttar Pradesh 226010',
      price: 11500,
      rating: 4.8,
      reviewCount: 3120,
      amenities: ['20 Acres Landscaped Gardens', 'Oudhyana Awadhi Specialty Dining', 'Large Outdoor Swimming Pool', 'Jiva Spa & Sauna', '24/7 Butler Service'],
      phone: '+91 522 671 1000',
      officialWebsite: 'https://www.tajhotels.com/en-in/taj/taj-mahal-lucknow/',
      imageUrl: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 24 hours before check-in.'
    },
    {
      name: 'Lebua Lucknow (Saraca Estate)',
      category: 'Heritage Haveli',
      tier: 'Luxury',
      address: '19, Mall Avenue, Saraca Estate, Lucknow, Uttar Pradesh 226001',
      price: 8800,
      rating: 4.7,
      reviewCount: 1450,
      amenities: ['Art Deco 1936 Heritage Manor', 'Azrak Awadhi Fine Dining', 'Courtyard Pool', 'Lounge 1936 Bar', 'Heritage Walking Tours'],
      phone: '+91 522 223 8333',
      officialWebsite: 'https://www.lebua.com/hotels/lebua-lucknow/',
      imageUrl: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 48 hours before check-in.'
    },
    {
      name: 'Hyatt Regency Lucknow',
      category: '5-Star Luxury',
      tier: 'Mid-Range',
      address: 'Vibhuti Khand, Gomti Nagar, Lucknow, Uttar Pradesh 226010',
      price: 6800,
      rating: 4.6,
      reviewCount: 2800,
      amenities: ['Rooftop Swimming Pool', 'Siddh Spa', 'Rocca Italian & Indian Restaurant', 'High-Speed Wi-Fi', 'Executive Club Lounge'],
      phone: '+91 522 426 1234',
      officialWebsite: 'https://www.hyatt.com/en-US/hotel/india/hyatt-regency-lucknow/lkorl',
      imageUrl: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 24 hours before check-in.'
    },
    {
      name: 'Clarks Avadh, Lucknow',
      category: 'Comfort 3-Star',
      tier: 'Budget',
      address: '8, Mahatma Gandhi Marg, Narpatkhera, Hazratganj, Lucknow, Uttar Pradesh 226001',
      price: 4200,
      rating: 4.4,
      reviewCount: 1980,
      amenities: ['Gomti River Views', 'Falaknuma Rooftop Mughlai Dining', 'Central Hazratganj Location', 'Swimming Pool', 'Free Wi-Fi'],
      phone: '+91 522 262 0131',
      officialWebsite: 'https://www.hotelclarks.com/clarks-avadh-lucknow/',
      imageUrl: 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 24 hours before arrival.'
    }
  ],

  // Andhra Pradesh
  'tirupati': [
    {
      name: 'Taj Tirupati',
      category: '5-Star Luxury',
      tier: 'Luxury',
      address: 'Near Ramanuja Circle, Renigunta Road, Tirupati, Andhra Pradesh 517501',
      price: 8900,
      rating: 4.8,
      reviewCount: 2450,
      amenities: ['Temple View Luxury Rooms', 'Satvik & South Indian Specialities', 'Rooftop Swimming Pool', 'Dedicated Tirumala Darshan Desk', 'Jiva Spa'],
      phone: '+91 877 666 0000',
      officialWebsite: 'https://www.tajhotels.com/en-in/taj/taj-tirupati/',
      imageUrl: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 24 hours before check-in.'
    },
    {
      name: 'Marasa Sarovar Premiere, Tirupati',
      category: '5-Star Luxury',
      tier: 'Mid-Range',
      address: 'Upadhyaya Nagar, Karakambadi Road, Tirupati, Andhra Pradesh 517507',
      price: 5800,
      rating: 4.7,
      reviewCount: 3100,
      amenities: ['Dasavatara Mythological Design', 'Pure Vegetarian Restaurant', 'Outdoor Pool', 'Ayurvedic Wellness Center', 'Spacious AC Suites'],
      phone: '+91 877 666 0001',
      officialWebsite: 'https://www.sarovarhotels.com/marasa-sarovar-premiere-tirupati/',
      imageUrl: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 24 hours before check-in.'
    },
    {
      name: 'Fortune Select Grand Ridge, Tirupati',
      category: 'Premium 4-Star',
      tier: 'Mid-Range',
      address: 'Shilparamam, Tiruchanoor Road, Tirupati, Andhra Pradesh 517503',
      price: 4900,
      rating: 4.6,
      reviewCount: 2200,
      amenities: ['Rainbow Pure Veg Multi-Cuisine Dining', 'Swimming Pool & Fitness Club', 'Shilparamam Cultural Park Access', 'Wi-Fi', 'Free Valet Parking'],
      phone: '+91 877 222 1888',
      officialWebsite: 'https://www.fortunehotels.in/tirupati-fortune-select-grand-ridge.dh.27',
      imageUrl: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 24 hours before arrival.'
    },
    {
      name: 'Minerva Grand Tirupati',
      category: 'Comfort 3-Star',
      tier: 'Budget',
      address: 'Renigunta Road, Near Srinivasam Complex, Tirupati, Andhra Pradesh 517501',
      price: 3200,
      rating: 4.4,
      reviewCount: 1850,
      amenities: ['Blue Fox Multi-Cuisine Restaurant', 'Central Railway Station Vicinity', 'Air Conditioned Rooms', 'Travel Desk', '24/7 Room Service'],
      phone: '+91 877 667 8888',
      officialWebsite: 'https://minervagrand.com/tirupati/',
      imageUrl: 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 24 hours before arrival.'
    }
  ],

  'visakhapatnam': [
    {
      name: 'The Park Visakhapatnam',
      category: '5-Star Luxury',
      tier: 'Luxury',
      address: 'Beach Road, Lawsons Bay Colony, Visakhapatnam, Andhra Pradesh 530023',
      price: 9200,
      rating: 4.8,
      reviewCount: 2900,
      amenities: ['Private Beach Access', 'Oceanfront Infinity Pool', 'Vista Waterfront Dining', 'Aura Luxury Spa', 'Sea View Balconies'],
      phone: '+91 891 304 5678',
      officialWebsite: 'https://www.theparkhotels.com/visakhapatnam.html',
      imageUrl: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 48 hours before check-in.'
    },
    {
      name: 'Novotel Visakhapatnam Varun Beach',
      category: '5-Star Luxury',
      tier: 'Luxury',
      address: 'Beach Road, Maharani Peta, Visakhapatnam, Andhra Pradesh 530002',
      price: 8800,
      rating: 4.7,
      reviewCount: 3400,
      amenities: ['Panoramic Bay of Bengal Views', 'Infinity Rooftop Pool', 'The Square International Dining', 'In Balance Fitness & Spa', 'Executive Lounge'],
      phone: '+91 891 282 2222',
      officialWebsite: 'https://all.accor.com/hotel/7535/index.en.shtml',
      imageUrl: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 24 hours before check-in.'
    },
    {
      name: 'Welcomhotel by ITC Hotels, Devee Grand Bay',
      category: '5-Star Luxury',
      tier: 'Mid-Range',
      address: 'Dr NTR Beach Road, Krishna Nagar, Maharani Peta, Visakhapatnam 530002',
      price: 6900,
      rating: 4.6,
      reviewCount: 2150,
      amenities: ['Bay of Bengal Facing Rooms', 'Dakshin Traditional South Indian Dining', 'Swimming Pool', 'Kaya Kalp Spa', 'Business Center'],
      phone: '+91 891 660 0101',
      officialWebsite: 'https://www.itchotels.com/in/en/welcomhoteldeveegrandbay-visakhapatnam',
      imageUrl: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 24 hours before check-in.'
    },
    {
      name: 'Dolphin Hotel Visakhapatnam',
      category: 'Comfort 3-Star',
      tier: 'Budget',
      address: '75 Feet Road, Daba Gardens, Visakhapatnam, Andhra Pradesh 530020',
      price: 3600,
      rating: 4.5,
      reviewCount: 1720,
      amenities: ['Horizon Rooftop Dining', 'Central Commercial District', 'Outdoor Pool', 'Free Airport Shuttle', 'High-Speed Wi-Fi'],
      phone: '+91 891 666 6666',
      officialWebsite: 'https://www.dolphinhotelvisakhapatnam.com/',
      imageUrl: 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 24 hours before arrival.'
    }
  ],

  // Odisha
  'puri': [
    {
      name: 'Mayfair Heritage, Puri',
      category: 'Boutique Resort',
      tier: 'Luxury',
      address: 'Chakratirtha Road, Puri, Odisha 752002',
      price: 9500,
      rating: 4.8,
      reviewCount: 2600,
      amenities: ['Beachfront Access', 'Aquarium Multi-Cuisine Restaurant', 'Swimming Pool with Sea Breeze', 'Mayfair Spa', 'Lush Tropical Landscapes'],
      phone: '+91 6752 227 800',
      officialWebsite: 'https://www.mayfairhotels.com/mayfair-heritage-puri/',
      imageUrl: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 48 hours before check-in.'
    },
    {
      name: 'Sterling Puri Beach Resort',
      category: 'Boutique Resort',
      tier: 'Mid-Range',
      address: '255/1 - A, Gopinathpur, Sipasarubali, Puri, Odisha 752002',
      price: 5800,
      rating: 4.6,
      reviewCount: 1950,
      amenities: ['River & Sea Confluence Private Beach', 'Grand Swimming Pool', 'Subhadra Ayurvedic Wellness', 'Holiday Activity Center', 'Free Breakfast'],
      phone: '+91 6752 230 021',
      officialWebsite: 'https://www.sterlingholidays.com/resorts-hotels/puri',
      imageUrl: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 48 hours before check-in.'
    },
    {
      name: 'The Hans Coco Palms, Puri',
      category: 'Comfort 3-Star',
      tier: 'Budget',
      address: 'Swargadwar, Beach Road, Puri, Odisha 752001',
      price: 3900,
      rating: 4.5,
      reviewCount: 1680,
      amenities: ['Direct Golden Beach Access', 'Ocean Pearl Restaurant', 'Swimming Pool', 'Ayurvedic Massage Deck', 'Free Wi-Fi'],
      phone: '+91 6752 230 038',
      officialWebsite: 'https://www.thehanshotels.com/hans-coco-palms-puri/',
      imageUrl: 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 24 hours before arrival.'
    }
  ],

  // Andaman & Nicobar Islands
  'andaman-havelock': [
    {
      name: 'Taj Exotica Resort & Spa, Andamans',
      category: 'Luxury Palace',
      tier: 'Luxury',
      address: 'Radhanagar Beach No. 7, Havelock Island, Andaman and Nicobar Islands 744211',
      price: 38000,
      rating: 4.9,
      reviewCount: 2200,
      amenities: ['Direct Access to Asia Best Radhanagar Beach', 'Olympic Size Infinity Pool', 'Jiva Grande Rainforest Spa', 'The Settlers Fine Dining', 'Private Scuba & Snorkel Excursions'],
      phone: '+91 3192 283 333',
      officialWebsite: 'https://www.tajhotels.com/en-in/taj/taj-exotica-andaman/',
      imageUrl: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 7 days before check-in.'
    },
    {
      name: 'Barefoot at Havelock',
      category: 'Boutique Resort',
      tier: 'Luxury',
      address: 'Beach No. 7, Radhanagar Village, Havelock Island, Andaman 744211',
      price: 15500,
      rating: 4.8,
      reviewCount: 1850,
      amenities: ['Eco-friendly Thatched Cottages', 'Canopy Rainforest Walk', 'PADI Certified Dive Center', 'Lounge Bar & Seafood Grill', 'Organic Spa'],
      phone: '+91 44 6608 4360',
      officialWebsite: 'https://www.barefoot-andaman.com/',
      imageUrl: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 48 hours before check-in.'
    },
    {
      name: 'SeaShell Resort & Spa Havelock',
      category: 'Boutique Resort',
      tier: 'Mid-Range',
      address: 'Govind Nagar Beach No. 2, Havelock Island, Andaman 744211',
      price: 8900,
      rating: 4.7,
      reviewCount: 2400,
      amenities: ['Beachfront Wooden Chalets', 'Swimming Pool with Sun Deck', 'Urban Tadka Restaurant', 'Fluid Lounge Bar', 'Ferry Concierge'],
      phone: '+91 3192 282 388',
      officialWebsite: 'https://www.seashellhotels.net/havelock/',
      imageUrl: 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 48 hours before arrival.'
    }
  ],

  // Uttarakhand (Nainital & Jim Corbett)
  'nainital-jimcorbett': [
    {
      name: 'Taj Corbett Resort & Spa, Uttarakhand',
      category: '5-Star Luxury',
      tier: 'Luxury',
      address: 'Zero Garjia, Dhikuli Ramnagar, Nainital District, Uttarakhand 244715',
      price: 18000,
      rating: 4.9,
      reviewCount: 3100,
      amenities: ['Kosi Riverfront Dining', 'Safari Jeep Desk with ASI Naturalists', 'Jiva Spa & Himalayan Therapies', 'Large Garden Pool', 'Luxury River Cottages'],
      phone: '+91 5947 266 400',
      officialWebsite: 'https://www.tajhotels.com/en-in/taj/taj-corbett-resort-and-spa-uttarakhand/',
      imageUrl: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 48 hours before check-in.'
    },
    {
      name: 'The Naini Retreat, Nainital (Heritage Est. 1927)',
      category: 'Heritage Haveli',
      tier: 'Luxury',
      address: 'Ayarpatta Slopes, Mallital, Nainital, Uttarakhand 263002',
      price: 12500,
      rating: 4.8,
      reviewCount: 2200,
      amenities: ['Residence of Maharaja of Pilibhit', 'Panoramic Naini Lake Views', 'Gurney House Specialty Dining', 'Spa & Wellness', 'Golf Driving Net'],
      phone: '+91 5942 235 105',
      officialWebsite: 'https://www.leisurehotels.co.in/the-naini-retreat-nainital/',
      imageUrl: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 48 hours before check-in.'
    },
    {
      name: 'The Riverview Retreat, Corbett',
      category: 'Boutique Resort',
      tier: 'Mid-Range',
      address: 'Zero Garjia, Dhikuli, Ramnagar, Uttarakhand 244715',
      price: 7600,
      rating: 4.7,
      reviewCount: 1850,
      amenities: ['Kosi River Bank Viewpoint', 'Large Outdoor Swimming Pool', 'Jim Grill Multi-Cuisine', 'Ayurvedic Wellness Spa', 'Daily Evening Bonfires'],
      phone: '+91 5947 284 374',
      officialWebsite: 'https://www.leisurehotels.co.in/the-riverview-retreat-corbett-national-park/',
      imageUrl: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 48 hours before check-in.'
    },
    {
      name: 'The Manu Maharani, Nainital',
      category: 'Premium 4-Star',
      tier: 'Mid-Range',
      address: 'Grassmere Estate, Mallital, Nainital, Uttarakhand 263001',
      price: 8900,
      rating: 4.6,
      reviewCount: 2400,
      amenities: ['Garden Patio Overlooking Naini Valley', 'Olive Spa & Steam', 'Panorama Multi-Cuisine Dining', 'Free Shuttle to Mall Road', 'Wi-Fi'],
      phone: '+91 5942 237 342',
      officialWebsite: 'https://www.themanumaharani.com/',
      imageUrl: 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=800&q=80',
      cancellationPolicy: 'Free cancellation up to 24 hours before arrival.'
    }
  ]
};
