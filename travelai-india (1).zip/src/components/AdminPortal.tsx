import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { AdminDashboard } from './AdminDashboard';
import { 
  ShieldCheck, 
  Lock, 
  Mail, 
  User, 
  Eye, 
  EyeOff, 
  AlertTriangle, 
  CheckCircle2, 
  ArrowRight,
  LogOut,
  KeyRound
} from 'lucide-react';

interface AdminPortalProps {
  onBackToApp?: () => void;
}

export const AdminPortal: React.FC<AdminPortalProps> = ({ onBackToApp }) => {
  const { user, token, isAdmin, logout, refreshUser } = useAuth();
  
  // Setup & Auth States
  const [checkingStatus, setCheckingStatus] = useState<boolean>(true);
  const [adminExists, setAdminExists] = useState<boolean>(true);
  
  // Setup Form State
  const [setupName, setSetupName] = useState<string>('');
  const [setupEmail, setSetupEmail] = useState<string>('');
  const [setupPassword, setSetupPassword] = useState<string>('');
  const [setupConfirmPassword, setSetupConfirmPassword] = useState<string>('');
  const [showSetupPassword, setShowSetupPassword] = useState<boolean>(false);
  const [setupLoading, setSetupLoading] = useState<boolean>(false);
  const [setupError, setSetupError] = useState<string | null>(null);
  const [setupSuccess, setSetupSuccess] = useState<string | null>(null);

  // Login Form State
  const [loginEmail, setLoginEmail] = useState<string>('');
  const [loginPassword, setLoginPassword] = useState<string>('');
  const [showLoginPassword, setShowLoginPassword] = useState<boolean>(false);
  const [loginLoading, setLoginLoading] = useState<boolean>(false);
  const [loginError, setLoginError] = useState<string | null>(null);

  // Check from backend if an admin account exists
  const checkAdminStatus = async () => {
    try {
      setCheckingStatus(true);
      const res = await fetch('/api/admin/setup-status');
      if (res.ok) {
        const data = await res.json();
        setAdminExists(Boolean(data.adminExists));
      }
    } catch (err) {
      console.error('Failed to check admin setup status:', err);
    } finally {
      setCheckingStatus(false);
    }
  };

  useEffect(() => {
    checkAdminStatus();
  }, []);

  // Handle One-Time Admin Setup
  const handleCreateAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    setSetupError(null);
    setSetupSuccess(null);

    if (!setupName.trim() || !setupEmail.trim() || !setupPassword) {
      setSetupError('All fields are required.');
      return;
    }

    if (setupPassword !== setupConfirmPassword) {
      setSetupError('Passwords do not match.');
      return;
    }

    if (setupPassword.length < 8) {
      setSetupError('Administrator password must be at least 8 characters long.');
      return;
    }

    try {
      setSetupLoading(true);
      const res = await fetch('/api/admin/setup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: setupName.trim(),
          email: setupEmail.trim().toLowerCase(),
          password: setupPassword,
          confirmPassword: setupConfirmPassword
        })
      });

      const data = await res.json();

      if (!res.ok) {
        setSetupError(data.error || 'Failed to create administrator account.');
        if (data.code === 'SETUP_ALREADY_COMPLETED') {
          setAdminExists(true);
        }
        return;
      }

      setSetupSuccess('Administrator account created successfully! Redirecting to Admin Login...');
      setAdminExists(true);
      
      // Clear setup form
      setSetupPassword('');
      setSetupConfirmPassword('');

      // Auto-populate login email
      setLoginEmail(setupEmail.trim().toLowerCase());
    } catch (err: any) {
      setSetupError('Network error during administrator setup. Please try again.');
    } finally {
      setSetupLoading(false);
    }
  };

  // Handle Admin Login
  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);

    if (!loginEmail.trim() || !loginPassword) {
      setLoginError('Please enter admin email and password.');
      return;
    }

    try {
      setLoginLoading(true);
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: loginEmail.trim().toLowerCase(),
          password: loginPassword
        })
      });

      const data = await res.json();

      if (!res.ok) {
        setLoginError(data.error || 'Invalid administrator credentials.');
        return;
      }

      if (data.token) {
        localStorage.setItem('travelai_token', data.token);
        await refreshUser();
      }
    } catch (err: any) {
      setLoginError('Network error during administrator login.');
    } finally {
      setLoginLoading(false);
    }
  };

  // If already authenticated as Administrator, show the Admin Dashboard with top bar
  if (isAdmin && token) {
    return (
      <div className="min-h-screen bg-[#0D0D11] text-white">
        <div className="bg-[#14141A] border-b border-purple-500/20 px-4 sm:px-8 py-3.5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[11px] font-mono tracking-widest uppercase text-purple-400 font-bold block">
                ADMINISTRATOR SESSION ACTIVE
              </span>
              <span className="text-xs text-[#D4D4D8] font-mono">
                {user?.name} ({user?.email})
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {onBackToApp && (
              <button
                type="button"
                onClick={onBackToApp}
                className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-xs font-mono text-[#D4D4D8] hover:text-white border border-white/10 transition-colors cursor-pointer"
              >
                Back to Travel App
              </button>
            )}
            <button
              type="button"
              onClick={logout}
              className="px-3.5 py-1.5 rounded-lg bg-red-950/40 hover:bg-red-900/40 text-red-300 hover:text-red-200 text-xs font-mono font-bold border border-red-500/30 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>LOG OUT ADMIN</span>
            </button>
          </div>
        </div>

        <AdminDashboard />
      </div>
    );
  }

  // Loading state while checking setup status
  if (checkingStatus) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center">
        <div className="text-center space-y-3 font-mono text-xs text-zinc-400">
          <div className="w-8 h-8 mx-auto border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
          <p>Verifying administrator security posture...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[85vh] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md bg-[#121217] border border-purple-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        
        {/* Background Ambient Glow */}
        <div className="absolute top-0 right-0 w-60 h-60 bg-purple-600/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />

        {/* Header Badge */}
        <div className="flex items-center justify-between pb-6 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400 shadow-md">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-mono tracking-widest uppercase text-purple-400 font-bold block">
                ADMIN ACCESS
              </span>
              <h2 className="font-cinzel text-xl font-bold text-white tracking-wide">
                {!adminExists ? 'Initial Setup' : 'Admin Login'}
              </h2>
            </div>
          </div>

          {onBackToApp && (
            <button
              type="button"
              onClick={onBackToApp}
              className="text-xs font-mono text-zinc-400 hover:text-white underline cursor-pointer"
            >
              Back to App
            </button>
          )}
        </div>

        {/* Case A: ONE-TIME ADMIN ACCOUNT CREATION (Only when no admin exists in DB) */}
        {!adminExists ? (
          <div className="mt-6 space-y-5">
            <div className="p-3.5 rounded-xl bg-purple-950/40 border border-purple-500/30 text-xs text-purple-200 space-y-1 font-mono">
              <div className="font-bold text-purple-300 flex items-center gap-1.5">
                <KeyRound className="w-3.5 h-3.5 text-purple-400" />
                <span>One-Time Administrator Setup</span>
              </div>
              <p className="text-[11px] text-zinc-300 font-light leading-relaxed">
                No administrator account exists in the database. Complete this one-time form to establish the primary platform administrator. Once created, this form is permanently disabled.
              </p>
            </div>

            {setupError && (
              <div className="p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-300 text-xs font-mono flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{setupError}</span>
              </div>
            )}

            {setupSuccess && (
              <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs font-mono flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{setupSuccess}</span>
              </div>
            )}

            <form onSubmit={handleCreateAdmin} className="space-y-4">
              <div className="space-y-1">
                <label className="text-[11px] font-mono uppercase text-zinc-400 block font-semibold">
                  Admin Name
                </label>
                <div className="relative">
                  <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                  <input
                    type="text"
                    required
                    value={setupName}
                    onChange={(e) => setSetupName(e.target.value)}
                    placeholder="e.g. Lead Administrator"
                    className="w-full pl-10 pr-4 py-2.5 bg-black/40 border border-white/10 rounded-xl text-xs font-mono text-white placeholder-zinc-600 focus:outline-none focus:border-purple-400"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-mono uppercase text-zinc-400 block font-semibold">
                  Admin Email
                </label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                  <input
                    type="email"
                    required
                    value={setupEmail}
                    onChange={(e) => setSetupEmail(e.target.value)}
                    placeholder="admin@yourdomain.com"
                    className="w-full pl-10 pr-4 py-2.5 bg-black/40 border border-white/10 rounded-xl text-xs font-mono text-white placeholder-zinc-600 focus:outline-none focus:border-purple-400"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-mono uppercase text-zinc-400 block font-semibold">
                  Password (Minimum 8 Characters)
                </label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                  <input
                    type={showSetupPassword ? 'text' : 'password'}
                    required
                    minLength={8}
                    value={setupPassword}
                    onChange={(e) => setSetupPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full pl-10 pr-10 py-2.5 bg-black/40 border border-white/10 rounded-xl text-xs font-mono text-white placeholder-zinc-600 focus:outline-none focus:border-purple-400"
                  />
                  <button
                    type="button"
                    onClick={() => setShowSetupPassword(!showSetupPassword)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white"
                  >
                    {showSetupPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-mono uppercase text-zinc-400 block font-semibold">
                  Confirm Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                  <input
                    type={showSetupPassword ? 'text' : 'password'}
                    required
                    minLength={8}
                    value={setupConfirmPassword}
                    onChange={(e) => setSetupConfirmPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full pl-10 pr-4 py-2.5 bg-black/40 border border-white/10 rounded-xl text-xs font-mono text-white placeholder-zinc-600 focus:outline-none focus:border-purple-400"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={setupLoading}
                className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-mono font-bold text-xs uppercase tracking-wider transition-all cursor-pointer shadow-lg shadow-purple-600/30 flex items-center justify-center gap-2 active:scale-98 disabled:opacity-50"
              >
                {setupLoading ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Creating Admin Account...</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>Create Administrator Account</span>
                  </>
                )}
              </button>
            </form>
          </div>
        ) : (
          /* Case B: SEPARATE ADMIN LOGIN (When admin exists) */
          <div className="mt-6 space-y-5">
            <p className="text-xs text-zinc-400 font-mono">
              Enter your verified administrator credentials to access system telemetry, user accounts, and platform transaction records.
            </p>

            {loginError && (
              <div className="p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-300 text-xs font-mono flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{loginError}</span>
              </div>
            )}

            <form onSubmit={handleAdminLogin} className="space-y-4">
              <div className="space-y-1">
                <label className="text-[11px] font-mono uppercase text-zinc-400 block font-semibold">
                  Admin Email / Username
                </label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                  <input
                    type="email"
                    required
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="admin@yourdomain.com"
                    className="w-full pl-10 pr-4 py-2.5 bg-black/40 border border-white/10 rounded-xl text-xs font-mono text-white placeholder-zinc-600 focus:outline-none focus:border-purple-400"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-mono uppercase text-zinc-400 block font-semibold">
                    Admin Password
                  </label>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                  <input
                    type={showLoginPassword ? 'text' : 'password'}
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full pl-10 pr-10 py-2.5 bg-black/40 border border-white/10 rounded-xl text-xs font-mono text-white placeholder-zinc-600 focus:outline-none focus:border-purple-400"
                  />
                  <button
                    type="button"
                    onClick={() => setShowLoginPassword(!showLoginPassword)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white"
                  >
                    {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loginLoading}
                className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-mono font-bold text-xs uppercase tracking-wider transition-all cursor-pointer shadow-lg shadow-purple-600/30 flex items-center justify-center gap-2 active:scale-98 disabled:opacity-50"
              >
                {loginLoading ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Authenticating...</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>Secure Admin Login</span>
                  </>
                )}
              </button>
            </form>

            <div className="pt-4 border-t border-white/10 text-center">
              <span className="text-[10px] font-mono text-zinc-500">
                🔒 Protected by server-side role validation & bcrypt hashing.
              </span>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default AdminPortal;
