import React from 'react';
import { BudgetRescueModal } from './adaptive/BudgetRescueModal';
import { TripPlan, Hotel, Attraction, FoodItem } from '../types';

export interface BudgetRescueProps {
  isOpen: boolean;
  onClose: () => void;
  currentPlan: TripPlan;
  availableHotels: Hotel[];
  availableAttractions: Attraction[];
  availableFood: FoodItem[];
  targetBudgetINR?: number;
  onApplyOptimizedPlan: (optimizedPlan: TripPlan, savingsSummary: string) => void;
}

export const BudgetRescue: React.FC<BudgetRescueProps> = (props) => {
  return <BudgetRescueModal {...props} />;
};

export default BudgetRescue;
