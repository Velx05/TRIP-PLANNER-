import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  MapPin, 
  Star, 
  Clock, 
  Tag, 
  Navigation, 
  ShieldCheck, 
  Phone, 
  Globe, 
  ExternalLink,
  Car,
  Bike,
  Utensils,
  Landmark,
  Bed,
  Hotel as HotelIcon,
  CheckCircle2,
  Info
} from 'lucide-react';

interface PlaceDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  place: any | null;
  onSelectRouteDestination?: (place: any) => void;
}

export const PlaceDetailsModal: React.FC<PlaceDetailsModalProps> = ({
  isOpen,
  onClose,
  place,
  onSelectRouteDestination
}) => {
  if (!isOpen || !place) return null;

  const type = place.type || (place.rentalType ? `${place.rentalType}_rental` : 'attraction');
  const name = place.name || place.displayName?.text || 'Verified Location';
  const category = 
    place.category || 
    place.hotelCategory || 
    place.cuisine || 
    (type === 'car_rental' ? 'Car Rental' : 
     type === 'bike_rental' ? 'Bike Rental' : 
     type === 'destination' ? 'Verified Destination' : 'Heritage Place');

  const address = place.address || place.formattedAddress || `${place.destinationName || ''}, ${place.state || 'India'}`;
  const rating = place.rating;
  const reviewCount = place.reviewCount;

  // Price formatting
  let priceStr: string | null = null;
  if (type === 'attraction') {
    priceStr = place.entryFeeINR === 0 ? 'Free Entry (₹0)' : place.entryFeeINR ? `Entry: ₹${place.entryFeeINR} / person` : 'Standard Entry Fee';
  } else if (type === 'hotel' || type === 'hostel') {
    priceStr = place.pricePerNightINR ? `₹${place.pricePerNightINR.toLocaleString()} / night` : null;
  } else if (type === 'food' || type === 'restaurant') {
    priceStr = place.priceINR ? `₹${place.priceINR} / person` : place.famousEstablishment?.approxPriceForTwoINR ? `₹${place.famousEstablishment.approxPriceForTwoINR} for two` : '₹250 - ₹600 / person';
  } else if (type === 'car_rental' || type === 'bike_rental') {
    priceStr = place.priceText || (place.pricePerDayINR ? `₹${place.pricePerDayINR.toLocaleString()} / day` : null);
  }

  // Opening Hours
  const openingHours = place.openingHours || place.famousEstablishment?.openingHours || (type === 'hotel' || type === 'hostel' ? 'Check-in: 02:00 PM | 24/7 Front Desk' : null);

  // Description / Available Details
  const description = place.description || place.localSignificance || place.tagline;

  // Fleet for rentals
  const fleet: string[] = place.fleet || [];

  // Amenities for hotels
  const amenities: string[] = place.amenities || [];

  const handleRouteClick = () => {
    if (onSelectRouteDestination) {
      onSelectRouteDestination(place);
    }
    onClose();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ duration: 0.2 }}
          className="relative w-full max-w-2xl bg-[#0E0E14] border border-white/15 rounded-3xl shadow-2xl overflow-hidden my-auto text-white flex flex-col max-h-[90vh]"
        >
          {/* Header Image or Banner */}
          <div className="relative h-48 sm:h-56 bg-zinc-900 overflow-hidden shrink-0">
            {place.imageUrl ? (
              <img
                src={place.imageUrl}
                alt={name}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full bg-gradient-to-br from-amber-950/40 via-zinc-900 to-black flex items-center justify-center">
                {type === 'car_rental' ? <Car className="w-16 h-16 text-blue-400/40" /> :
                 type === 'bike_rental' ? <Bike className="w-16 h-16 text-amber-400/40" /> :
                 type === 'food' ? <Utensils className="w-16 h-16 text-emerald-400/40" /> :
                 type === 'hostel' ? <Bed className="w-16 h-16 text-cyan-400/40" /> :
                 type === 'hotel' ? <HotelIcon className="w-16 h-16 text-purple-400/40" /> :
                 <Landmark className="w-16 h-16 text-amber-400/40" />}
              </div>
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-[#0E0E14] via-[#0E0E14]/40 to-transparent" />

            {/* Close Button */}
            <button
              type="button"
              onClick={onClose}
              className="absolute top-4 right-4 p-2 rounded-xl bg-black/60 hover:bg-black/90 text-zinc-300 hover:text-white border border-white/10 backdrop-blur-md transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Badges on Banner */}
            <div className="absolute bottom-3 left-4 right-4 flex flex-wrap items-center justify-between gap-2">
              <span className="px-2.5 py-1 rounded-lg text-xs font-mono font-bold uppercase tracking-wider bg-amber-400 text-black shadow-lg">
                {category}
              </span>
              {rating && (
                <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-black/70 border border-white/15 text-amber-400 font-bold text-xs font-mono backdrop-blur-md">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  <span>{rating}</span>
                  {reviewCount && (
                    <span className="text-zinc-400 text-[10px] font-normal">
                      ({reviewCount.toLocaleString()} reviews)
                    </span>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Body Content */}
          <div className="p-6 overflow-y-auto space-y-5 font-sans">
            
            {/* Title & Location */}
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 text-emerald-400 font-mono text-[11px] uppercase tracking-wider font-semibold">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Verified Application Record</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-bold font-cinzel text-white leading-tight">
                {name}
              </h3>
              <div className="flex items-start gap-1.5 text-xs text-zinc-400 font-mono pt-1">
                <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>{address}</span>
              </div>
            </div>

            {/* Price & Timing Quick Bar */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-white/10">
              {priceStr && (
                <div className="p-3 rounded-2xl bg-black/40 border border-white/10 space-y-1">
                  <span className="text-[10px] font-mono uppercase text-zinc-400 block flex items-center gap-1">
                    <Tag className="w-3 h-3 text-emerald-400" />
                    <span>Price / Tariff</span>
                  </span>
                  <span className="text-sm font-bold text-emerald-400 font-mono block">
                    {priceStr}
                  </span>
                </div>
              )}

              {openingHours && (
                <div className="p-3 rounded-2xl bg-black/40 border border-white/10 space-y-1">
                  <span className="text-[10px] font-mono uppercase text-zinc-400 block flex items-center gap-1">
                    <Clock className="w-3 h-3 text-amber-400" />
                    <span>Opening Hours</span>
                  </span>
                  <span className="text-xs font-semibold text-zinc-200 block truncate font-mono">
                    {openingHours}
                  </span>
                </div>
              )}
            </div>

            {/* Description / Significance */}
            {description && (
              <div className="space-y-1.5 pt-2 border-t border-white/10">
                <span className="text-[11px] font-mono uppercase text-zinc-400 font-bold block">
                  Available Details & Overview
                </span>
                <p className="text-xs text-zinc-300 leading-relaxed font-light">
                  {description}
                </p>
              </div>
            )}

            {/* Rental Fleet */}
            {fleet.length > 0 && (
              <div className="space-y-2 pt-2 border-t border-white/10">
                <span className="text-[11px] font-mono uppercase text-zinc-400 font-bold block">
                  Available Vehicle Fleet ({fleet.length} Options)
                </span>
                <div className="flex flex-wrap gap-2">
                  {fleet.map((v, i) => (
                    <span 
                      key={i}
                      className="px-2.5 py-1 rounded-xl bg-white/5 border border-white/10 text-xs text-zinc-300 font-mono flex items-center gap-1.5"
                    >
                      <CheckCircle2 className="w-3 h-3 text-amber-400" />
                      <span>{v}</span>
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Hotel Amenities */}
            {amenities.length > 0 && (
              <div className="space-y-2 pt-2 border-t border-white/10">
                <span className="text-[11px] font-mono uppercase text-zinc-400 font-bold block">
                  Featured Amenities
                </span>
                <div className="flex flex-wrap gap-2">
                  {amenities.slice(0, 8).map((a, i) => (
                    <span 
                      key={i}
                      className="px-2.5 py-1 rounded-xl bg-white/5 border border-white/10 text-xs text-zinc-300 font-mono"
                    >
                      {a}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Contact / Links */}
            {(place.contactPhone || place.phone || place.officialWebsite || place.website) && (
              <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-white/10 text-xs font-mono">
                {(place.contactPhone || place.phone) && (
                  <div className="flex items-center gap-1.5 text-zinc-300">
                    <Phone className="w-3.5 h-3.5 text-amber-400" />
                    <span>{place.contactPhone || place.phone}</span>
                  </div>
                )}
                {(place.officialWebsite || place.website) && (
                  <a
                    href={place.officialWebsite || place.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 text-amber-400 hover:text-amber-300 underline"
                  >
                    <Globe className="w-3.5 h-3.5" />
                    <span>Official Portal</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
            )}

          </div>

          {/* Footer Actions */}
          <div className="p-4 sm:p-5 border-t border-white/10 bg-[#12121A] flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono text-zinc-300 hover:text-white transition-colors cursor-pointer"
            >
              Close
            </button>

            <button
              type="button"
              onClick={handleRouteClick}
              className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black font-mono font-bold text-xs uppercase tracking-wider transition-all duration-200 cursor-pointer flex items-center justify-center gap-2 shadow-lg shadow-amber-400/20 active:scale-98"
            >
              <Navigation className="w-4 h-4 text-black" />
              <span>Show Route to this Place</span>
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
