import React from 'react';
import { AIAdaptiveTravelCard } from './adaptive/AIAdaptiveTravelCard';
import { TripPlan } from '../types';

export interface AIAdaptiveTravelProps {
  currentPlan: TripPlan;
  onOpenWhatIf: () => void;
  onOpenTripRecovery: () => void;
  onOpenBudgetRescue?: () => void;
}

export const AIAdaptiveTravel: React.FC<AIAdaptiveTravelProps> = (props) => {
  return <AIAdaptiveTravelCard {...props} />;
};

export default AIAdaptiveTravel;
