// Interactive Map View with Live Navigation & Directions Engine
// Supports Browser Geolocation (Current User Location), Dynamic Destination Search,
// Real Route Calculation (Driving, Transit, Two-Wheeler, Walking), and Interactive Polyline Mapping.

import React, { useEffect, useRef, useState, useMemo } from 'react';
import { 
  Destination, 
  Hotel, 
  Attraction, 
  FoodItem, 
  RentalLocation,
  Coordinates, 
  DirectionsRoute, 
  GeocodeResult 
} from '../types';
import { 
  MapPin, 
  Layers, 
  Landmark, 
  Hotel as HotelIcon, 
  Bed,
  Utensils,
  Car, 
  Bike, 
  Navigation, 
  Search, 
  Route as RouteIcon, 
  Footprints, 
  Train, 
  Clock, 
  AlertCircle,
  Locate,
  CheckCircle2, 
  X, 
  ExternalLink,
  Star,
  Tag,
  Phone,
  Globe,
  Compass,
  Filter,
  Sparkles,
  Info,
  ShieldCheck
} from 'lucide-react';
import { GoogleMapRenderer, MapFilterType } from './GoogleMapRenderer';
import { isHostelProperty, BookingContextParams } from '../utils/bookingLinks';
import { PropertyDetailsModal } from './PropertyDetailsModal';
import { PlaceDetailsModal } from './PlaceDetailsModal';

interface InteractiveMapViewProps {
  destinations: Destination[];
  onSelectDestination?: (destination: Destination) => void;
  onOpenBooking?: (hotel: Hotel, checkIn?: string, checkOut?: string, guests?: number) => void;
}

export const InteractiveMapView: React.FC<InteractiveMapViewProps> = ({
  destinations,
  onSelectDestination,
  onOpenBooking,
}) => {
  // Leaflet map refs
  const leafletMapContainerRef = useRef<HTMLDivElement>(null);
  const leafletMapInstanceRef = useRef<any>(null);
  const leafletMarkersGroupRef = useRef<any>(null);
  const leafletPolylineRef = useRef<any>(null);

  // Map Engine & API Config
  const [mapEngine, setMapEngine] = useState<'google' | 'vector'>('vector');
  const [googleMapsApiKey, setGoogleMapsApiKey] = useState<string>('');
  const [loadingConfig, setLoadingConfig] = useState<boolean>(true);

  // Map Filter State (Strictly requested: All, Attractions, Hotels, Hostels, Restaurants, Car Rental, Bike Rental)
  const [activeFilter, setActiveFilter] = useState<MapFilterType>('all');
  const [selectedCityFilter, setSelectedCityFilter] = useState<string>('all');

  // Detail Modals
  const [selectedPlaceForModal, setSelectedPlaceForModal] = useState<any | null>(null);
  const [selectedHotelForModal, setSelectedHotelForModal] = useState<Hotel | null>(null);

  // Map Data
  const [mapData, setMapData] = useState<{
    hotels: Hotel[];
    attractions: Attraction[];
    food: FoodItem[];
    rentals: RentalLocation[];
  }>({ hotels: [], attractions: [], food: [], rentals: [] });

  // Geolocation & Origin Point State
  const [isDetectingLocation, setIsDetectingLocation] = useState<boolean>(true);
  const [locationPermissionDenied, setLocationPermissionDenied] = useState<boolean>(false);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [routeOrigin, setRouteOrigin] = useState<string>('Detecting your location...');
  const [originCoords, setOriginCoords] = useState<Coordinates | null>(null);

  // Destination State (Strictly User-Selected: No Hardcoded Default)
  const [routeDestination, setRouteDestination] = useState<string>('');
  const [destCoords, setDestCoords] = useState<Coordinates | null>(null);
  const [destinationSearchOpen, setDestinationSearchOpen] = useState<boolean>(false);
  const [destinationQuery, setDestinationQuery] = useState<string>('');

  // Travel Mode & Route State
  const [travelMode, setTravelMode] = useState<'DRIVE' | 'TRANSIT' | 'WALK' | 'TWO_WHEELER'>('DRIVE');
  const [activeRoute, setActiveRoute] = useState<DirectionsRoute | null>(null);
  const [computingRoute, setComputingRoute] = useState<boolean>(false);
  const [routeError, setRouteError] = useState<string | null>(null);

  // Destination & POI Inspector
  const [activeItemDetails, setActiveItemDetails] = useState<any | null>(null);

  // 1. Fetch Maps Configuration & Verified Data on mount
  useEffect(() => {
    async function initDataAndConfig() {
      try {
        setLoadingConfig(true);
        const configRes = await fetch('/api/maps/config');
        if (configRes.ok) {
          const config = await configRes.json();
          if (config.hasGoogleKey && config.googleMapsApiKey) {
            setGoogleMapsApiKey(config.googleMapsApiKey);
            setMapEngine('google');
          } else {
            setGoogleMapsApiKey('');
            setMapEngine('vector');
          }
        }

        const dataRes = await fetch('/api/search?q=');
        let hotels: Hotel[] = [];
        let attractions: Attraction[] = [];
        let food: FoodItem[] = [];
        let rentals: RentalLocation[] = [];

        if (dataRes.ok) {
          const data = await dataRes.json();
          hotels = data.hotels || [];
          attractions = data.attractions || [];
          food = data.food || [];
          rentals = data.rentals || [];
        }

        if (rentals.length === 0) {
          try {
            const rentalRes = await fetch('/api/rentals');
            if (rentalRes.ok) {
              const rData = await rentalRes.json();
              rentals = rData.rentals || [];
            }
          } catch (e) {
            console.error('Failed to load rentals:', e);
          }
        }

        setMapData({ hotels, attractions, food, rentals });
      } catch (err) {
        console.error('Failed to load map data:', err);
      } finally {
        setLoadingConfig(false);
      }
    }
    initDataAndConfig();
  }, []);

  // 2. Browser Geolocation: Get User's Real Device Coordinates & Reverse Geocode
  const detectUserLocation = () => {
    setIsDetectingLocation(true);
    setLocationPermissionDenied(false);
    setLocationError(null);
    setRouteOrigin('Detecting your location...');

    if (!navigator.geolocation) {
      setIsDetectingLocation(false);
      setLocationError('Geolocation is not supported by your browser. Please enter your origin manually.');
      setRouteOrigin('');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        const coords: Coordinates = { lat, lng };
        setOriginCoords(coords);
        setIsDetectingLocation(false);

        // Center map to user's real location
        if (leafletMapInstanceRef.current) {
          leafletMapInstanceRef.current.setView([lat, lng], 13);
        }

        // Reverse geocode to get a human-readable city/address
        try {
          const res = await fetch('/api/maps/geocode', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ lat, lng }),
          });

          if (res.ok) {
            const data = await res.json();
            if (data.results && data.results.length > 0 && data.results[0].formattedAddress) {
              setRouteOrigin(data.results[0].formattedAddress);
              return;
            }
          }
          setRouteOrigin('Your Current Location');
        } catch (err) {
          setRouteOrigin('Your Current Location');
        }
      },
      (err) => {
        setIsDetectingLocation(false);
        setLocationPermissionDenied(true);
        if (err.code === err.PERMISSION_DENIED) {
          setLocationError('Location permission is required to use your current location. Please allow location access or enter your starting point manually.');
        } else {
          setLocationError('Unable to detect your location. Please enter your starting point manually.');
        }
        setRouteOrigin('');
      },
      {
        enableHighAccuracy: true,
        timeout: 12000,
        maximumAge: 60000,
      }
    );
  };

  // Run geolocation detection on mount
  useEffect(() => {
    detectUserLocation();
  }, []);

  // 3. Resolve Destination Suggestions from Real Application Database
  const destinationSuggestions = React.useMemo(() => {
    const q = (destinationQuery || routeDestination).toLowerCase().trim();
    if (!q) {
      return destinations.slice(0, 8).map(d => ({
        title: `${d.name}, ${d.state}`,
        subtitle: 'Verified Destination',
        coords: d.coordinates,
        type: 'destination' as const,
      }));
    }

    const matches: Array<{
      title: string;
      subtitle: string;
      coords: Coordinates;
      type: 'destination' | 'attraction';
    }> = [];

    // Match destinations
    destinations.forEach(d => {
      if (d.name.toLowerCase().includes(q) || d.state.toLowerCase().includes(q)) {
        matches.push({
          title: `${d.name}, ${d.state}`,
          subtitle: 'Verified Destination',
          coords: d.coordinates,
          type: 'destination',
        });
      }
    });

    // Match attractions
    mapData.attractions.forEach(a => {
      if (a.name.toLowerCase().includes(q) || a.destinationName.toLowerCase().includes(q)) {
        matches.push({
          title: `${a.name} (${a.destinationName})`,
          subtitle: a.category || 'Historical Monument',
          coords: a.coordinates,
          type: 'attraction',
        });
      }
    });

    return matches.slice(0, 10);
  }, [destinationQuery, routeDestination, destinations, mapData.attractions]);

  // 4. Handle Route Calculation (Only after user selects destination)
  const handleCalculateRoute = async (customMode?: 'DRIVE' | 'TRANSIT' | 'WALK' | 'TWO_WHEELER') => {
    setRouteError(null);

    // Validate origin
    let activeOriginCoords = originCoords;
    if (!activeOriginCoords) {
      if (!routeOrigin.trim()) {
        setRouteError('Please allow location access or enter an origin point.');
        return;
      }

      // Try geocoding manual origin
      try {
        setComputingRoute(true);
        const geoRes = await fetch('/api/maps/geocode', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ address: routeOrigin.trim() }),
        });
        if (geoRes.ok) {
          const geoData = await geoRes.json();
          if (geoData.results && geoData.results.length > 0) {
            activeOriginCoords = geoData.results[0].coordinates;
            setOriginCoords(activeOriginCoords);
          }
        }
      } catch (err) {
        // continue
      }
    }

    if (!activeOriginCoords) {
      setComputingRoute(false);
      setRouteError('Unable to resolve origin location coordinates. Please enter a valid city or address.');
      return;
    }

    // Validate destination
    let activeDestCoords = destCoords;
    if (!activeDestCoords) {
      if (!routeDestination.trim()) {
        setRouteError('Please enter a destination.');
        return;
      }

      // Try geocoding manual destination
      try {
        setComputingRoute(true);
        const geoRes = await fetch('/api/maps/geocode', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ address: routeDestination.trim() }),
        });
        if (geoRes.ok) {
          const geoData = await geoRes.json();
          if (geoData.results && geoData.results.length > 0) {
            activeDestCoords = geoData.results[0].coordinates;
            setDestCoords(activeDestCoords);
          }
        }
      } catch (err) {
        // continue
      }
    }

    if (!activeDestCoords) {
      setComputingRoute(false);
      setRouteError('Unable to resolve destination coordinates. Please select a valid destination.');
      return;
    }

    try {
      setComputingRoute(true);
      const chosenMode = customMode || travelMode;

      const payload = {
        origin: activeOriginCoords,
        destination: activeDestCoords,
        originName: routeOrigin || 'Current Location',
        destinationName: routeDestination || 'Destination',
        mode: chosenMode,
      };

      const res = await fetch('/api/maps/directions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        throw new Error('Unable to calculate route');
      }

      const route: DirectionsRoute = await res.json();
      setActiveRoute(route);

      // Render Leaflet Polyline & fit bounds
      if (leafletMapInstanceRef.current && route.polylinePoints.length > 0) {
        const L = await import('leaflet');
        if (leafletPolylineRef.current) {
          leafletPolylineRef.current.remove();
        }
        const latLngs: [number, number][] = route.polylinePoints.map((p) => [p.lat, p.lng]);
        leafletPolylineRef.current = L.polyline(latLngs, {
          color: '#F27D26',
          weight: 5,
          opacity: 0.9,
        }).addTo(leafletMapInstanceRef.current);

        leafletMapInstanceRef.current.fitBounds(leafletPolylineRef.current.getBounds(), {
          padding: [50, 50],
        });
      }
    } catch (err: any) {
      console.error('Route calculation error:', err);
      setRouteError('Unable to calculate the route. Please check the destination and try again.');
    } finally {
      setComputingRoute(false);
    }
  };

  // 5. Initialize Leaflet Map for Vector Canvas
  useEffect(() => {
    if (mapEngine !== 'vector') return;
    let isMounted = true;

    async function initLeaflet() {
      if (!leafletMapContainerRef.current) return;
      const L = await import('leaflet');
      if (!isMounted) return;

      if (!leafletMapInstanceRef.current) {
        const initialCenter: [number, number] = originCoords 
          ? [originCoords.lat, originCoords.lng] 
          : [20.5937, 78.9629];

        const map = L.map(leafletMapContainerRef.current, {
          center: initialCenter,
          zoom: originCoords ? 12 : 5,
          zoomControl: true,
        });

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          maxZoom: 19,
          attribution: '&copy; OpenStreetMap contributors | Real-time Routing Engine',
        }).addTo(map);

        const markersGroup = L.layerGroup().addTo(map);
        leafletMapInstanceRef.current = map;
        leafletMarkersGroupRef.current = markersGroup;

        // Ensure clean layout and tiles rendering
        setTimeout(() => {
          if (leafletMapInstanceRef.current) {
            leafletMapInstanceRef.current.invalidateSize();
          }
        }, 200);

        const handleResize = () => {
          if (leafletMapInstanceRef.current) {
            leafletMapInstanceRef.current.invalidateSize();
          }
        };
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
      }
    }

    initLeaflet();

    return () => {
      isMounted = false;
      if (leafletMapInstanceRef.current) {
        leafletMapInstanceRef.current.remove();
        leafletMapInstanceRef.current = null;
      }
    };
  }, [mapEngine]);

  // 6. Update Leaflet Markers when origin, destination, or route changes
  useEffect(() => {
    if (mapEngine !== 'vector' || !leafletMapInstanceRef.current || !leafletMarkersGroupRef.current) return;

    async function updateMarkers() {
      const L = await import('leaflet');
      const group = leafletMarkersGroupRef.current;
      const map = leafletMapInstanceRef.current;
      if (!group || !map) return;

      group.clearLayers();

      const createCustomPin = (color: string, label: string) => {
        return L.divIcon({
          className: 'custom-map-pin',
          html: `<div style="background-color: ${color}; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px solid white; box-shadow: 0 4px 10px rgba(0,0,0,0.6); font-size: 13px;">${label}</div>`,
          iconSize: [28, 28],
          iconAnchor: [14, 14],
          popupAnchor: [0, -16],
        });
      };

      // Plot User Current Location Pin (Green GPS marker)
      if (originCoords) {
        const originMarker = L.marker([originCoords.lat, originCoords.lng], {
          icon: createCustomPin('#10B981', '📍'),
        });
        originMarker.bindPopup(`
          <div style="font-family: sans-serif; color: #111; min-width: 150px;">
            <strong style="color: #059669; font-size: 11px; text-transform: uppercase; display: block;">ORIGIN POINT</strong>
            <p style="margin: 4px 0 0; font-size: 12px; font-weight: bold;">${routeOrigin || 'Your Current Location'}</p>
          </div>
        `);
        group.addLayer(originMarker);
      }

      // Plot Destination Pin
      if (destCoords) {
        const destMarker = L.marker([destCoords.lat, destCoords.lng], {
          icon: createCustomPin('#F27D26', '🎯'),
        });
        destMarker.bindPopup(`
          <div style="font-family: sans-serif; color: #111; min-width: 150px;">
            <strong style="color: #d97706; font-size: 11px; text-transform: uppercase; display: block;">DESTINATION</strong>
            <p style="margin: 4px 0 0; font-size: 12px; font-weight: bold;">${routeDestination}</p>
          </div>
        `);
        group.addLayer(destMarker);
      }

      // Helper to generate popup HTML with all marker details
      const makePopupHtml = (title: string, category: string, address: string, rating?: number, reviewCount?: number, price?: string, hours?: string, desc?: string) => `
        <div style="font-family: sans-serif; color: #111; min-width: 200px; max-width: 250px; line-height: 1.4;">
          <div style="display: flex; align-items: center; justify-content: space-between; gap: 4px; margin-bottom: 4px;">
            <span style="font-size: 10px; font-weight: bold; text-transform: uppercase; color: #d97706; background: #fef3c7; padding: 2px 6px; border-radius: 4px;">${category}</span>
            ${rating ? `<span style="font-size: 11px; font-weight: bold; color: #b45309;">★ ${rating}</span>` : ''}
          </div>
          <strong style="font-size: 13px; color: #111; display: block; margin-bottom: 2px;">${title}</strong>
          ${address ? `<p style="font-size: 11px; color: #555; margin: 0 0 4px;">📍 ${address}</p>` : ''}
          ${price ? `<div style="font-size: 11px; font-weight: bold; color: #047857; margin-bottom: 3px;">🏷️ ${price}</div>` : ''}
          ${hours ? `<p style="font-size: 10px; color: #666; margin: 0 0 4px;">⏰ ${hours}</p>` : ''}
          ${desc ? `<p style="font-size: 10px; color: #777; margin: 0 0 6px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">${desc}</p>` : ''}
          <div style="font-size: 10px; color: #d97706; font-weight: bold; text-align: center; border-top: 1px solid #eee; padding-top: 4px;">Click marker to view details & route ➔</div>
        </div>
      `;

      // Plot verified items when no route is active
      if (!activeRoute) {
        // 1. Destinations (Rose)
        if ((activeFilter === 'all' || activeFilter === 'attractions') && selectedCityFilter === 'all') {
          destinations.forEach((d) => {
            const isSelected = destCoords && Math.abs(destCoords.lat - d.coordinates.lat) < 0.001;
            if (!isSelected) {
              const destPin = L.marker([d.coordinates.lat, d.coordinates.lng], {
                icon: createCustomPin('#E11D48', '📍'),
              });
              destPin.bindPopup(makePopupHtml(d.name, 'Destination', `${d.name}, ${d.state}`, 4.9, undefined, undefined, 'Open All Year', d.tagline || d.description));
              destPin.on('click', () => {
                setActiveItemDetails({ type: 'destination', ...d });
              });
              group.addLayer(destPin);
            }
          });
        }

        // 2. Attractions (Amber)
        if (activeFilter === 'all' || activeFilter === 'attractions') {
          mapData.attractions
            .filter((a) => selectedCityFilter === 'all' || a.destinationId === selectedCityFilter)
            .forEach((a) => {
              if (a.coordinates) {
                const pin = L.marker([a.coordinates.lat, a.coordinates.lng], {
                  icon: createCustomPin('#D97706', '🏛️'),
                });
                const fee = a.entryFeeINR === 0 ? 'Free Entry (₹0)' : a.entryFeeINR ? `₹${a.entryFeeINR} / person` : 'Entry Ticket';
                pin.bindPopup(makePopupHtml(a.name, a.category || 'Attraction', a.address || `${a.destinationName}, ${a.state || 'India'}`, a.rating, a.reviewCount, fee, a.openingHours, a.description));
                pin.on('click', () => {
                  setActiveItemDetails({ type: 'attraction', ...a });
                });
                group.addLayer(pin);
              }
            });
        }

        // 3. Hotels (Purple)
        if (activeFilter === 'all' || activeFilter === 'hotels') {
          mapData.hotels
            .filter((h) => (selectedCityFilter === 'all' || h.destinationId === selectedCityFilter) && !isHostelProperty(h))
            .forEach((h) => {
              if (h.coordinates) {
                const pin = L.marker([h.coordinates.lat, h.coordinates.lng], {
                  icon: createCustomPin('#9333EA', '🏨'),
                });
                const tariff = h.pricePerNightINR ? `₹${h.pricePerNightINR.toLocaleString()} / night` : undefined;
                pin.bindPopup(makePopupHtml(h.name, h.hotelCategory || 'Hotel & Stay', h.address || `${h.destinationName}`, h.rating, h.reviewCount, tariff, 'Check-in: 02:00 PM', h.description));
                pin.on('click', () => {
                  setActiveItemDetails({ type: 'hotel', ...h });
                });
                group.addLayer(pin);
              }
            });
        }

        // 4. Hostels (Cyan)
        if (activeFilter === 'all' || activeFilter === 'hostels') {
          mapData.hotels
            .filter((h) => (selectedCityFilter === 'all' || h.destinationId === selectedCityFilter) && isHostelProperty(h))
            .forEach((h) => {
              if (h.coordinates) {
                const pin = L.marker([h.coordinates.lat, h.coordinates.lng], {
                  icon: createCustomPin('#06B6D4', '🛏️'),
                });
                const tariff = h.pricePerNightINR ? `₹${h.pricePerNightINR.toLocaleString()} / night` : undefined;
                pin.bindPopup(makePopupHtml(h.name, 'Backpacker Hostel', h.address || `${h.destinationName}`, h.rating, h.reviewCount, tariff, '24/7 Front Desk', h.description));
                pin.on('click', () => {
                  setActiveItemDetails({ type: 'hostel', ...h });
                });
                group.addLayer(pin);
              }
            });
        }

        // 5. Restaurants / Food (Emerald)
        if (activeFilter === 'all' || activeFilter === 'restaurants') {
          mapData.food
            .filter((f) => selectedCityFilter === 'all' || f.destinationId === selectedCityFilter)
            .forEach((f) => {
              const coords = f.coordinates || f.famousEstablishment?.coordinates;
              if (coords) {
                const pin = L.marker([coords.lat, coords.lng], {
                  icon: createCustomPin('#10B981', '🍽️'),
                });
                const price = f.priceINR ? `₹${f.priceINR} / person` : f.famousEstablishment?.approxPriceForTwoINR ? `₹${f.famousEstablishment.approxPriceForTwoINR} for two` : '₹250 - ₹600';
                const name = f.famousEstablishment?.name || f.name;
                const cat = f.cuisine ? `${f.cuisine} Cuisine` : 'Culinary Spot';
                pin.bindPopup(makePopupHtml(name, cat, f.famousEstablishment?.address || f.destinationName, f.famousEstablishment?.rating || 4.8, undefined, price, f.famousEstablishment?.openingHours, f.description));
                pin.on('click', () => {
                  setActiveItemDetails({ type: 'food', ...f });
                });
                group.addLayer(pin);
              }
            });
        }

        // 6. Car Rental (Blue)
        if (activeFilter === 'all' || activeFilter === 'car_rental') {
          (mapData.rentals || [])
            .filter((r) => (selectedCityFilter === 'all' || r.destinationId === selectedCityFilter) && r.rentalType === 'car')
            .forEach((r) => {
              if (r.coordinates) {
                const pin = L.marker([r.coordinates.lat, r.coordinates.lng], {
                  icon: createCustomPin('#3B82F6', '🚗'),
                });
                pin.bindPopup(makePopupHtml(r.name, 'Car Rental Hub', r.address, r.rating, r.reviewCount, r.priceText, r.openingHours, r.description));
                pin.on('click', () => {
                  setActiveItemDetails({ type: 'car_rental', ...r });
                });
                group.addLayer(pin);
              }
            });
        }

        // 7. Bike Rental (Orange)
        if (activeFilter === 'all' || activeFilter === 'bike_rental') {
          (mapData.rentals || [])
            .filter((r) => (selectedCityFilter === 'all' || r.destinationId === selectedCityFilter) && r.rentalType === 'bike')
            .forEach((r) => {
              if (r.coordinates) {
                const pin = L.marker([r.coordinates.lat, r.coordinates.lng], {
                  icon: createCustomPin('#F97316', '🏍️'),
                });
                pin.bindPopup(makePopupHtml(r.name, 'Bike & Scooter Rental', r.address, r.rating, r.reviewCount, r.priceText, r.openingHours, r.description));
                pin.on('click', () => {
                  setActiveItemDetails({ type: 'bike_rental', ...r });
                });
                group.addLayer(pin);
              }
            });
        }
      }
    }

    updateMarkers();
  }, [mapEngine, originCoords, destCoords, routeOrigin, routeDestination, activeRoute, destinations, mapData, activeFilter, selectedCityFilter]);

  return (
    <div className="w-full max-w-[1600px] 2xl:max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8 xl:px-10 py-6 space-y-6">
      
      {/* Production-Ready Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-white/10">
        <div>
          <div className="flex items-center gap-2 text-amber-400 font-mono text-xs uppercase tracking-widest mb-1 font-bold">
            <RouteIcon className="w-4 h-4" />
            <span>REAL-TIME NAVIGATION ENGINE</span>
          </div>
          <h1 className="font-cinzel text-2xl sm:text-3xl font-bold text-white uppercase tracking-tight">
            Directions & Live Routes
          </h1>
          <p className="text-xs sm:text-sm text-[#A1A1AA] mt-1 font-sans">
            Calculate traffic-aware routes from your current location to any Indian heritage sight or city.
          </p>
        </div>

        {/* Map Engine Toggle (Only shown when a valid Google Maps API Key is configured) */}
        {googleMapsApiKey && googleMapsApiKey.startsWith('AIza') && (
          <div className="flex items-center gap-2 self-start sm:self-auto">
            <div className="flex items-center bg-[#14141A] p-1 rounded-xl border border-white/10 text-xs font-mono">
              <button
                type="button"
                onClick={() => setMapEngine('google')}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer font-semibold ${
                  mapEngine === 'google'
                    ? 'bg-amber-400 text-black shadow-md'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                Google Maps
              </button>
              <button
                type="button"
                onClick={() => setMapEngine('vector')}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer font-semibold ${
                  mapEngine === 'vector'
                    ? 'bg-zinc-800 text-white shadow-md'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                Vector Canvas
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Map Category Filters & Destination Scope Bar */}
      <div className="bg-[#121218] p-3.5 sm:p-4 rounded-3xl border border-white/10 shadow-xl space-y-3 font-sans">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          
          {/* 7 Map Filters: All, Attractions, Hotels, Hostels, Restaurants, Car Rental, Bike Rental */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 lg:pb-0 scrollbar-none text-xs font-mono">
            {[
              { id: 'all', label: 'All', icon: Layers },
              { id: 'attractions', label: 'Attractions', icon: Landmark },
              { id: 'hotels', label: 'Hotels', icon: HotelIcon },
              { id: 'hostels', label: 'Hostels', icon: Bed },
              { id: 'restaurants', label: 'Restaurants', icon: Utensils },
              { id: 'car_rental', label: 'Car Rental', icon: Car },
              { id: 'bike_rental', label: 'Bike Rental', icon: Bike },
            ].map((f) => {
              const IconComp = f.icon;
              const isSelected = activeFilter === f.id;
              return (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setActiveFilter(f.id as any)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap border ${
                    isSelected
                      ? 'bg-amber-400 text-black border-amber-400 shadow-md shadow-amber-400/20'
                      : 'bg-black/40 border-white/10 text-zinc-400 hover:text-white hover:border-white/20'
                  }`}
                >
                  <IconComp className="w-3.5 h-3.5" />
                  <span>{f.label}</span>
                </button>
              );
            })}
          </div>

          {/* City / Destination Focus Dropdown */}
          <div className="flex items-center gap-2 shrink-0">
            <span className="text-[11px] font-mono text-zinc-400 uppercase hidden sm:inline">Focus City:</span>
            <select
              value={selectedCityFilter}
              onChange={(e) => {
                const val = e.target.value;
                setSelectedCityFilter(val);
                if (val !== 'all') {
                  const found = destinations.find(d => d.id === val);
                  if (found) {
                    if (leafletMapInstanceRef.current) {
                      leafletMapInstanceRef.current.setView([found.coordinates.lat, found.coordinates.lng], 12);
                    }
                  }
                } else {
                  if (leafletMapInstanceRef.current) {
                    leafletMapInstanceRef.current.setView([20.5937, 78.9629], 5);
                  }
                }
              }}
              className="px-3 py-1.5 rounded-xl bg-black/50 border border-white/15 text-xs font-mono text-white focus:outline-none focus:border-amber-400 cursor-pointer"
            >
              <option value="all">📍 All Destinations in India ({destinations.length})</option>
              {destinations.map(d => (
                <option key={d.id} value={d.id}>
                  {d.name}, {d.state}
                </option>
              ))}
            </select>
          </div>

        </div>
      </div>

      {/* Main Routes Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column Part 1: Route Configuration Panel (~35-40% desktop, top on mobile) */}
        <div className="order-1 lg:col-span-5 xl:col-span-4 lg:row-start-1 bg-[#14141A] p-5 sm:p-6 rounded-3xl border border-white/10 shadow-xl space-y-4 font-sans">
          
          {/* Travel Mode Selector */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[11px] font-mono uppercase text-zinc-400 font-bold mr-1">
              Travel Mode:
            </span>
            {[
              { id: 'DRIVE', label: 'Driving', icon: Car },
              { id: 'TRANSIT', label: 'Transit', icon: Train },
              { id: 'TWO_WHEELER', label: 'Two-Wheeler', icon: Bike },
              { id: 'WALK', label: 'Walking', icon: Footprints },
            ].map((m) => {
              const IconComponent = m.icon;
              const isSelected = travelMode === m.id;
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => {
                    setTravelMode(m.id as any);
                    if (activeRoute) {
                      handleCalculateRoute(m.id as any);
                    }
                  }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-mono font-bold uppercase tracking-wider transition-all cursor-pointer border ${
                    isSelected
                      ? 'bg-amber-400 text-black border-amber-400 shadow-md'
                      : 'bg-black/30 border-white/10 text-zinc-400 hover:text-white hover:border-white/25'
                  }`}
                >
                  <IconComponent className="w-3.5 h-3.5" />
                  <span>{m.label}</span>
                </button>
              );
            })}
          </div>

          {/* Origin & Destination Inputs */}
          <div className="space-y-4">
            
            {/* Origin Point (Current User Location) */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-mono uppercase tracking-wider text-zinc-400 font-bold flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block" />
                  <span>Origin Point (Your Location)</span>
                </label>
                <button
                  type="button"
                  onClick={detectUserLocation}
                  disabled={isDetectingLocation}
                  className="text-[11px] font-mono text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer"
                  title="Re-detect your current GPS location"
                >
                  <Locate className={`w-3 h-3 ${isDetectingLocation ? 'animate-spin' : ''}`} />
                  <span>Detect GPS</span>
                </button>
              </div>

              <div className="relative">
                <MapPin className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-400" />
                <input
                  type="text"
                  value={routeOrigin}
                  onChange={(e) => {
                    setRouteOrigin(e.target.value);
                    setOriginCoords(null);
                  }}
                  placeholder="Enter starting city or address..."
                  className="w-full pl-10 pr-4 py-2.5 bg-black/40 border border-white/15 focus:border-amber-400 rounded-xl text-xs font-mono text-white placeholder-zinc-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Destination Point (User Selected) */}
            <div className="space-y-1.5 relative">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-mono uppercase tracking-wider text-zinc-400 font-bold flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-amber-400 inline-block" />
                  <span>Destination Point</span>
                </label>
                {routeDestination && (
                  <button
                    type="button"
                    onClick={() => {
                      setRouteDestination('');
                      setDestCoords(null);
                      setActiveRoute(null);
                    }}
                    className="text-[11px] font-mono text-zinc-500 hover:text-white flex items-center gap-0.5 cursor-pointer"
                  >
                    <X className="w-3 h-3" />
                    <span>Clear</span>
                  </button>
                )}
              </div>

              <div className="relative">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-amber-400" />
                <input
                  type="text"
                  value={routeDestination}
                  onFocus={() => setDestinationSearchOpen(true)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      setDestinationSearchOpen(false);
                      handleCalculateRoute();
                    }
                  }}
                  onChange={(e) => {
                    setRouteDestination(e.target.value);
                    setDestinationQuery(e.target.value);
                    setDestCoords(null);
                    setDestinationSearchOpen(true);
                  }}
                  placeholder="Search or enter destination (e.g. Amber Palace, Taj Mahal)"
                  className="w-full pl-10 pr-4 py-2.5 bg-black/40 border border-white/15 focus:border-amber-400 rounded-xl text-xs font-mono text-white placeholder-zinc-500 focus:outline-none"
                />
              </div>

              {/* Suggestions Dropdown */}
              {destinationSearchOpen && destinationSuggestions.length > 0 && (
                <div className="absolute top-full left-0 right-0 z-50 mt-1.5 bg-[#121217] border border-white/20 rounded-2xl shadow-2xl max-h-60 overflow-y-auto p-1.5 space-y-1">
                  <div className="px-2.5 py-1 text-[10px] font-mono uppercase text-zinc-500 font-bold border-b border-white/5">
                    Select Destination:
                  </div>
                  {destinationSuggestions.map((item, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setRouteDestination(item.title);
                        setDestCoords(item.coords);
                        setDestinationSearchOpen(false);
                      }}
                      className="w-full text-left p-2 rounded-xl hover:bg-white/10 transition-colors flex items-center justify-between gap-2 cursor-pointer group"
                    >
                      <div className="space-y-0.5 min-w-0">
                        <span className="text-xs font-mono font-bold text-white group-hover:text-amber-300 block truncate">
                          {item.title}
                        </span>
                        <span className="text-[10px] font-mono text-zinc-500 block truncate">
                          {item.subtitle}
                        </span>
                      </div>
                      <span className="text-[10px] font-mono text-amber-400 shrink-0 uppercase">
                        Select ➔
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>

          </div>

          {/* Error Message Notice */}
          {(locationError || routeError) && (
            <div className="p-3.5 rounded-2xl bg-red-950/40 border border-red-500/30 text-xs font-mono text-red-300 flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <span>{routeError || locationError}</span>
                {locationPermissionDenied && (
                  <p className="text-[11px] text-zinc-400">
                    You can type your starting city or address manually into the Origin Point above.
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Primary Calculate Button */}
          <button
            type="button"
            onClick={() => {
              setDestinationSearchOpen(false);
              handleCalculateRoute();
            }}
            disabled={computingRoute || !routeDestination.trim()}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black font-mono font-bold text-xs uppercase tracking-wider transition-all duration-200 cursor-pointer flex items-center justify-center gap-2 shadow-lg shadow-amber-400/20 active:scale-98 disabled:opacity-50"
          >
            {computingRoute ? (
              <>
                <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                <span>Calculating Real Directions & Route...</span>
              </>
            ) : (
              <>
                <Navigation className="w-4 h-4 text-black" />
                <span>Calculate Directions & Route</span>
              </>
            )}
          </button>

        </div>

        {/* Right Column: Large Live Interactive Map (~60-65% desktop, middle on mobile) */}
        <div className="order-2 lg:col-span-7 xl:col-span-8 lg:row-start-1 lg:row-span-3 lg:sticky lg:top-24 space-y-4">
          
          {/* Map Container */}
          <div className="bg-[#121217] rounded-3xl border border-white/10 overflow-hidden shadow-2xl h-[520px] sm:h-[600px] lg:h-[720px] xl:h-[780px] relative">
            {mapEngine === 'google' ? (
              <GoogleMapRenderer
                apiKey={googleMapsApiKey}
                destinations={destinations}
                mapData={mapData}
                filterType={activeFilter}
                selectedDestinationId={selectedCityFilter}
                activeRoute={activeRoute}
                searchedPlaces={[]}
                geocodedLocation={null}
                userLocation={originCoords}
                destinationCoords={destCoords}
                destinationName={routeDestination}
                onSelectItem={(item, type) => {
                  setActiveItemDetails({ type, ...item });
                  if (type === 'hotel' || type === 'hostel') {
                    setSelectedHotelForModal(item);
                  } else {
                    setSelectedPlaceForModal({ type, ...item });
                  }
                }}
                onSelectRouteDestination={(item, type) => {
                  const title = item.name || item.displayName?.text || 'Selected Place';
                  setRouteDestination(title);
                  if (item.coordinates) {
                    setDestCoords(item.coordinates);
                    handleCalculateRoute('DRIVE');
                  }
                }}
                onSwitchToVector={() => setMapEngine('vector')}
              />
            ) : (
              <div ref={leafletMapContainerRef} className="w-full h-full" />
            )}

            {/* Map Status Badge Overlay */}
            <div className="absolute top-4 left-4 z-[400] bg-black/80 backdrop-blur-md px-3.5 py-1.5 rounded-xl border border-white/15 text-[11px] font-mono text-zinc-300 flex items-center gap-2 shadow-lg">
              <span className={`w-2 h-2 rounded-full ${activeRoute ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
              <span>{activeRoute ? `Route Active (${activeRoute.distanceText})` : 'Interactive Map'}</span>
            </div>
          </div>

        </div>

        {/* Left Column Part 2: Production Route Details & Step-by-Step Instructions */}
        <div className="order-3 lg:col-span-5 xl:col-span-4 lg:row-start-2 space-y-4">
          
          <div className="bg-[#14141A] p-5 sm:p-6 rounded-3xl border border-white/10 shadow-xl space-y-4">
            
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="font-cinzel text-lg font-bold text-white uppercase tracking-wide flex items-center gap-2">
                <RouteIcon className="w-4 h-4 text-amber-400" />
                <span>Route Summary</span>
              </h3>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase ${activeRoute ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-500/30' : 'bg-white/5 text-zinc-500'}`}>
                {activeRoute ? 'Calculated' : 'Pending'}
              </span>
            </div>

            {/* Metric Blocks: Distance & Travel Time */}
            <div className="grid grid-cols-2 gap-3 font-mono">
              <div className="p-3.5 rounded-2xl bg-black/40 border border-white/10 space-y-1">
                <span className="text-[10px] text-zinc-500 uppercase tracking-wider block">
                  Total Distance
                </span>
                <span className="text-lg font-bold text-white block">
                  {activeRoute ? activeRoute.distanceText : '-'}
                </span>
              </div>

              <div className="p-3.5 rounded-2xl bg-black/40 border border-white/10 space-y-1">
                <span className="text-[10px] text-zinc-500 uppercase tracking-wider block flex items-center gap-1">
                  <Clock className="w-3 h-3 text-amber-400" />
                  <span>Travel Time</span>
                </span>
                <span className="text-lg font-bold text-amber-400 block">
                  {activeRoute ? activeRoute.durationText : '-'}
                </span>
              </div>
            </div>

            {/* Route Status / Endpoints */}
            <div className="p-3.5 rounded-2xl bg-black/30 border border-white/5 space-y-2 text-xs font-mono">
              <div>
                <span className="text-[10px] text-zinc-500 uppercase block">Origin</span>
                <span className="text-zinc-300 font-semibold truncate block">
                  {routeOrigin || 'Detecting Location...'}
                </span>
              </div>
              <div className="border-t border-white/5 pt-1.5">
                <span className="text-[10px] text-zinc-500 uppercase block">Destination</span>
                <span className="text-amber-300 font-semibold truncate block">
                  {routeDestination || 'No destination selected'}
                </span>
              </div>
            </div>

            {/* Turn-by-Turn Instructions List */}
            <div className="space-y-2 pt-2 border-t border-white/10">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-mono uppercase tracking-wider text-zinc-400 font-bold">
                  Instructions:
                </span>
                {activeRoute && (
                  <span className="text-[10px] font-mono text-zinc-500">
                    {activeRoute.steps.length} steps
                  </span>
                )}
              </div>

              {activeRoute && activeRoute.steps.length > 0 ? (
                <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                  {activeRoute.steps.map((step, idx) => (
                    <div 
                      key={idx}
                      className="p-3 rounded-2xl bg-black/40 border border-white/5 text-xs font-mono space-y-1"
                    >
                      <div className="flex items-start gap-2">
                        <span className="w-4 h-4 rounded-full bg-amber-400/20 text-amber-400 flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                          {idx + 1}
                        </span>
                        <p className="text-zinc-200 text-[11px] leading-snug flex-1">
                          {step.instruction}
                        </p>
                      </div>
                      <div className="flex items-center gap-3 text-[10px] text-zinc-500 pl-6">
                        <span>{step.distanceKm} km</span>
                        <span>•</span>
                        <span>{step.durationMins} min</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-6 rounded-2xl bg-black/20 border border-dashed border-white/10 text-center text-xs font-mono text-zinc-500 space-y-1">
                  <p>-</p>
                  <p className="text-[11px] text-zinc-600">
                    Enter a destination and calculate directions to view route guidance.
                  </p>
                </div>
              )}
            </div>

          </div>

          {/* Marker Details Inspector (Displays exact information when user clicks any marker) */}
          {activeItemDetails ? (() => {
            const item = activeItemDetails;
            const type = item.type || (item.rentalType ? `${item.rentalType}_rental` : 'attraction');
            const name = item.name || item.displayName?.text || 'Selected Place';
            const category = 
              type === 'destination' ? 'Verified Destination' :
              type === 'attraction' ? (item.category || 'Historical Attraction') :
              type === 'hotel' ? (item.hotelCategory || 'Hotel & Stay') :
              type === 'hostel' ? 'Backpacker Hostel' :
              type === 'food' ? (item.cuisine ? `${item.cuisine} Cuisine` : 'Culinary Spot') :
              type === 'car_rental' ? 'Car Rental Hub' :
              type === 'bike_rental' ? 'Bike Rental' : (item.category || 'Place');

            const address = item.address || item.formattedAddress || `${item.destinationName || ''}, ${item.state || 'India'}`;
            const rating = item.rating || item.famousEstablishment?.rating;
            const reviewCount = item.reviewCount;

            let priceStr: string | null = null;
            if (type === 'attraction') {
              priceStr = item.entryFeeINR === 0 ? 'Free Entry (₹0)' : item.entryFeeINR ? `Entry: ₹${item.entryFeeINR} / person` : null;
            } else if (type === 'hotel' || type === 'hostel') {
              priceStr = item.pricePerNightINR ? `₹${item.pricePerNightINR.toLocaleString()} / night` : null;
            } else if (type === 'food') {
              priceStr = item.priceINR ? `₹${item.priceINR} / person` : item.famousEstablishment?.approxPriceForTwoINR ? `₹${item.famousEstablishment.approxPriceForTwoINR} for two` : null;
            } else if (type === 'car_rental' || type === 'bike_rental') {
              priceStr = item.priceText || (item.pricePerDayINR ? `₹${item.pricePerDayINR.toLocaleString()} / day` : null);
            }

            const openingHours = item.openingHours || item.famousEstablishment?.openingHours || (type === 'hotel' || type === 'hostel' ? 'Check-in: 02:00 PM | 24/7 Front Desk' : null);
            const details = item.description || item.localSignificance || (item.fleet ? `Fleet: ${item.fleet.join(', ')}` : null);

            return (
              <div className="bg-[#14141A] p-5 sm:p-6 rounded-3xl border border-white/10 shadow-xl space-y-4 font-sans">
                {/* Header & Badges */}
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-amber-400 text-black shadow">
                        {category}
                      </span>
                      {rating && (
                        <div className="flex items-center gap-1 text-xs text-amber-400 font-bold font-mono">
                          <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                          <span>{rating}</span>
                          {reviewCount && (
                            <span className="text-zinc-400 text-[10px] font-normal font-mono">
                              ({reviewCount.toLocaleString()})
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                    <h4 className="font-bold text-white text-base sm:text-lg leading-snug">
                      {name}
                    </h4>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveItemDetails(null)}
                    className="p-1 rounded-lg text-zinc-500 hover:text-white cursor-pointer shrink-0"
                    title="Close Details"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Address */}
                {address && (
                  <div className="flex items-start gap-1.5 text-xs text-zinc-300 font-mono">
                    <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <span>{address}</span>
                  </div>
                )}

                {/* Price & Hours Bar */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono">
                  {priceStr && (
                    <div className="p-2.5 rounded-xl bg-black/40 border border-white/10 space-y-0.5">
                      <span className="text-[10px] text-zinc-400 uppercase flex items-center gap-1">
                        <Tag className="w-3 h-3 text-emerald-400" />
                        <span>Price / Tariff</span>
                      </span>
                      <span className="font-bold text-emerald-400 text-xs truncate block">
                        {priceStr}
                      </span>
                    </div>
                  )}

                  {openingHours && (
                    <div className="p-2.5 rounded-xl bg-black/40 border border-white/10 space-y-0.5">
                      <span className="text-[10px] text-zinc-400 uppercase flex items-center gap-1">
                        <Clock className="w-3 h-3 text-amber-400" />
                        <span>Opening Hours</span>
                      </span>
                      <span className="font-semibold text-zinc-200 text-[11px] truncate block">
                        {openingHours}
                      </span>
                    </div>
                  )}
                </div>

                {/* Available Details */}
                {details && (
                  <div className="space-y-1 text-xs text-zinc-300">
                    <span className="text-[10px] font-mono text-zinc-400 uppercase font-bold block">
                      Available Details:
                    </span>
                    <p className="line-clamp-3 leading-relaxed font-light text-zinc-300 bg-black/30 p-2.5 rounded-xl border border-white/5">
                      {details}
                    </p>
                  </div>
                )}

                {/* Actions: View Details Button & Show Route Button */}
                <div className="flex items-center gap-2 pt-2 border-t border-white/10">
                  <button
                    type="button"
                    onClick={() => {
                      if (type === 'hotel' || type === 'hostel') {
                        setSelectedHotelForModal(item);
                      } else {
                        setSelectedPlaceForModal({ type, ...item });
                      }
                    }}
                    className="flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-mono text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer text-center flex items-center justify-center gap-1.5"
                  >
                    <Info className="w-3.5 h-3.5 text-amber-400" />
                    <span>View Details</span>
                  </button>

                  {item.coordinates && (
                    <button
                      type="button"
                      onClick={() => {
                        setRouteDestination(name);
                        setDestCoords(item.coordinates);
                        handleCalculateRoute('DRIVE');
                      }}
                      className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black font-mono text-xs font-bold uppercase tracking-wider transition-all cursor-pointer text-center flex items-center justify-center gap-1.5 shadow-md shadow-amber-400/20"
                    >
                      <Navigation className="w-3.5 h-3.5" />
                      <span>Show Route</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })() : (
            <div className="bg-[#14141A] p-5 rounded-3xl border border-dashed border-white/15 text-center space-y-2 font-mono">
              <div className="w-9 h-9 rounded-xl bg-amber-400/10 border border-amber-400/20 text-amber-400 mx-auto flex items-center justify-center">
                <MapPin className="w-4 h-4" />
              </div>
              <h4 className="text-white text-xs font-bold uppercase">Inspect Place Details</h4>
              <p className="text-[11px] text-zinc-400 font-sans">
                Click any marker on the map to view verified Name, Category, Address, Rating, Tariff, Hours & calculate turn-by-turn routes.
              </p>
            </div>
          )}

        </div>

      </div>

      {/* Full Place Details Modal */}
      {selectedPlaceForModal && (
        <PlaceDetailsModal
          isOpen={!!selectedPlaceForModal}
          onClose={() => setSelectedPlaceForModal(null)}
          place={selectedPlaceForModal}
          onSelectRouteDestination={(place) => {
            const title = place.name || place.displayName?.text || 'Selected Place';
            setRouteDestination(title);
            if (place.coordinates) {
              setDestCoords(place.coordinates);
              handleCalculateRoute('DRIVE');
            }
          }}
        />
      )}

      {/* Property Details Modal for Hotels & Hostels */}
      {selectedHotelForModal && (
        <PropertyDetailsModal
          hotel={selectedHotelForModal}
          isOpen={!!selectedHotelForModal}
          onClose={() => setSelectedHotelForModal(null)}
          bookingParams={{
            destinationName: selectedHotelForModal.destinationName || 'India',
            checkIn: new Date(Date.now() + 86400000).toISOString().split('T')[0],
            checkOut: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0],
            guests: 2,
          }}
          onBookHotel={onOpenBooking}
        />
      )}

    </div>
  );
};

export default InteractiveMapView;
