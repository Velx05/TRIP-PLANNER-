import { 
  TripPlan, 
  Attraction, 
  Hotel, 
  FoodItem, 
  AdaptiveScenario, 
  DisruptionCause, 
  AdaptivePlanResult, 
  PlanChangeItem, 
  BudgetOptimizationResult 
} from '../../types';

// Detect if an attraction is primarily an outdoor nature/viewpoint sight
export function isOutdoorAttraction(attractionName: string, category?: string, description?: string): boolean {
  const text = `${attractionName} ${category || ''} ${description || ''}`.toLowerCase();
  return /(?:beach|falls|waterfall|lake|peak|hill|viewpoint|dunes|safari|nature|trek|promenade|ghat|river|valley|caves|sanctuary|national park|gardens?|park)/i.test(text);
}

// Detect if an attraction is an indoor sheltered museum, palace interior, or gallery
export function isIndoorAttraction(attractionName: string, category?: string, description?: string): boolean {
  const text = `${attractionName} ${category || ''} ${description || ''}`.toLowerCase();
  return /(?:museum|gallery|palace|haveli|fort|memorial|temple|church|monastery|gurudwara|science centre|planetarium|indoor|heritage centre|library|stupa)/i.test(text);
}

/**
 * 1. AI WHAT-IF SIMULATOR ENGINE
 * Generates an adapted trip plan based on simulated conditions
 */
export function simulateWhatIf(
  originalPlan: TripPlan,
  scenario: AdaptiveScenario,
  customPrompt: string = '',
  availableAttractions: Attraction[] = [],
  availableHotels: Hotel[] = [],
  availableFood: FoodItem[] = []
): AdaptivePlanResult {
  const newDays = JSON.parse(JSON.stringify(originalPlan.days));
  const changes: PlanChangeItem[] = [];
  let explanation = '';
  let scenarioLabel = '';
  let costAdjustment = 0;
  let timeSavedMins = 0;

  // Clone recommended hotel
  let recommendedHotel = originalPlan.recommendedHotel 
    ? { ...originalPlan.recommendedHotel } 
    : availableHotels[0];

  const usedNames = new Set<string>();
  originalPlan.days.forEach(d => {
    usedNames.add(d.morning.attractionName.toLowerCase());
    usedNames.add(d.afternoon.attractionName.toLowerCase());
    usedNames.add(d.evening.attractionOrActivity.toLowerCase());
  });

  const getUnusedAttraction = (filterFn?: (a: Attraction) => boolean): Attraction | undefined => {
    return availableAttractions.find(a => !usedNames.has(a.name.toLowerCase()) && (!filterFn || filterFn(a))) 
      || availableAttractions.find(a => !filterFn || filterFn(a))
      || availableAttractions[0];
  };

  switch (scenario) {
    case 'BAD_WEATHER': {
      scenarioLabel = '🌧️ Bad Weather Protection';
      explanation = 'Outdoor activities and open vantage points were substituted with weather-proof indoor heritage palaces, museums, covered temples, and cozy dining trails.';

      newDays.forEach((day: any) => {
        // Morning
        if (isOutdoorAttraction(day.morning.attractionName)) {
          const replacement = getUnusedAttraction(a => isIndoorAttraction(a.name, a.category, a.description));
          if (replacement && replacement.name !== day.morning.attractionName) {
            changes.push({
              timeSlot: 'Morning',
              dayNumber: day.day,
              originalItem: day.morning.attractionName,
              newItem: replacement.name,
              changeReason: 'Protected from rain/extreme heat; indoor museum & gallery experience.',
              costDiffINR: (replacement.entryFeeINR || 0) - 50,
              travelTimeText: '25 mins sheltered transit'
            });
            usedNames.add(replacement.name.toLowerCase());
            day.morning.attractionName = replacement.name;
            day.morning.description = replacement.description || `Sheltered indoor exploration at ${replacement.name}.`;
            day.morning.practicalTip = `Weather-safe indoor timing: ${replacement.openingHours || '09:00 AM - 05:30 PM'}.`;
          }
        }

        // Afternoon
        if (isOutdoorAttraction(day.afternoon.attractionName)) {
          const replacement = getUnusedAttraction(a => isIndoorAttraction(a.name, a.category, a.description));
          if (replacement && replacement.name !== day.afternoon.attractionName) {
            changes.push({
              timeSlot: 'Afternoon',
              dayNumber: day.day,
              originalItem: day.afternoon.attractionName,
              newItem: replacement.name,
              changeReason: 'Indoor architectural monument with weather protection and guided tour.',
              costDiffINR: (replacement.entryFeeINR || 0) - 50,
              travelTimeText: '20 mins transit'
            });
            usedNames.add(replacement.name.toLowerCase());
            day.afternoon.attractionName = replacement.name;
            day.afternoon.description = replacement.description || `Indoor cultural gallery and royal court halls at ${replacement.name}.`;
            day.afternoon.practicalTip = `Rain-safe visit with verified hours: ${replacement.openingHours || '10:00 AM - 05:00 PM'}.`;
          }
        }

        // Evening
        if (isOutdoorAttraction(day.evening.attractionOrActivity)) {
          const indoorCulture = getUnusedAttraction(a => /temple|hall|haveli|theatre|bazaar|market/i.test(a.name + ' ' + (a.category || '')));
          if (indoorCulture) {
            changes.push({
              timeSlot: 'Evening',
              dayNumber: day.day,
              originalItem: day.evening.attractionOrActivity,
              newItem: indoorCulture.name,
              changeReason: 'Swapped open outdoor walk for covered cultural experience and evening musical ambiance.',
              costDiffINR: 0,
              travelTimeText: '15 mins transit'
            });
            usedNames.add(indoorCulture.name.toLowerCase());
            day.evening.attractionOrActivity = indoorCulture.name;
            day.evening.description = `Cozy covered evening cultural visit at ${indoorCulture.name}.`;
          }
        }
      });
      break;
    }

    case 'BUDGET_DECREASED': {
      scenarioLabel = '💰 Budget Decreased / Cost Reduction';
      explanation = 'Substituted premium admission venues with zero-rupee free heritage landmarks, public ghats, and affordable certified food gems.';

      // Switch to cheaper hotel
      const budgetHotels = availableHotels
        .filter(h => h.priceCategory === 'Budget' || (h.pricePerNightINR && h.pricePerNightINR <= 2500))
        .sort((a, b) => (a.pricePerNightINR || 1200) - (b.pricePerNightINR || 1200));

      if (budgetHotels.length > 0 && originalPlan.recommendedHotel && budgetHotels[0].id !== originalPlan.recommendedHotel.id) {
        const originalHotelPrice = originalPlan.recommendedHotel.pricePerNightINR || 3500;
        const newHotelPrice = budgetHotels[0].pricePerNightINR || 1400;
        const hotelDiff = (newHotelPrice - originalHotelPrice) * originalPlan.durationDays;
        costAdjustment += hotelDiff;

        changes.push({
          timeSlot: 'Hotel',
          dayNumber: 1,
          originalItem: originalPlan.recommendedHotel.name,
          newItem: budgetHotels[0].name,
          changeReason: `Swapped to high-rated verified budget stay (Save ₹${Math.abs(hotelDiff).toLocaleString()} total).`,
          costDiffINR: hotelDiff,
          travelTimeText: 'Central location'
        });
        recommendedHotel = budgetHotels[0];
      }

      // Replace fee attractions with free ones
      const freeAttractions = availableAttractions.filter(a => a.entryFeeINR === 0);
      let freeIdx = 0;

      newDays.forEach((day: any) => {
        if (freeAttractions[freeIdx] && day.morning.attractionName !== freeAttractions[freeIdx].name) {
          const replacement = freeAttractions[freeIdx];
          changes.push({
            timeSlot: 'Morning',
            dayNumber: day.day,
            originalItem: day.morning.attractionName,
            newItem: replacement.name,
            changeReason: 'Free entry verified heritage site (₹0 admission).',
            costDiffINR: -100,
            travelTimeText: '15 mins'
          });
          costAdjustment -= 100;
          day.morning.attractionName = replacement.name;
          day.morning.description = replacement.description;
          freeIdx = (freeIdx + 1) % freeAttractions.length;
        }
      });
      break;
    }

    case 'RUNNING_LATE': {
      scenarioLabel = '⏰ Running Late / Express Fast-Track';
      explanation = 'Condensed schedule into a relaxed, express route: eliminated long cross-city travel times and prioritized marquee highlights.';
      timeSavedMins = 90;

      newDays.forEach((day: any) => {
        // Morning shifted to 10:30 AM
        day.morning.time = '10:30 AM – 12:45 PM (Express Start)';
        day.afternoon.time = '01:30 PM – 04:30 PM (Direct Core Tour)';
        day.evening.time = '05:30 PM – 07:30 PM (Sunset & Relaxed Dinner)';
        
        changes.push({
          timeSlot: 'Morning',
          dayNumber: day.day,
          originalItem: `${day.morning.attractionName} (Early 08:30 AM Slot)`,
          newItem: `${day.morning.attractionName} (Fast-Track 10:30 AM)`,
          changeReason: 'Adjusted arrival slot to bypass morning rush without missing ticket windows.',
          costDiffINR: 0,
          travelTimeText: 'Saved 45 mins commute'
        });
      });
      break;
    }

    case 'HOTEL_UNAVAILABLE': {
      scenarioLabel = '🏨 Hotel Unavailable / Relocation Rescue';
      explanation = 'Instantly re-routed to an immediate available verified sister accommodation with guaranteed room reservation in the same locality.';

      const altHotels = availableHotels.filter(h => !originalPlan.recommendedHotel || h.id !== originalPlan.recommendedHotel.id);
      if (altHotels.length > 0) {
        const alt = altHotels[0];
        const costDiff = ((alt.pricePerNightINR || 2200) - (originalPlan.recommendedHotel?.pricePerNightINR || 2200)) * originalPlan.durationDays;
        costAdjustment += costDiff;

        changes.push({
          timeSlot: 'Hotel',
          dayNumber: 1,
          originalItem: originalPlan.recommendedHotel?.name || 'Original Stay',
          newItem: alt.name,
          changeReason: `Confirmed alternative room match with ${alt.rating}★ rating, ${alt.hotelCategory}, verified on-spot check-in.`,
          costDiffINR: costDiff,
          travelTimeText: '2.5 km from central hub'
        });
        recommendedHotel = alt;
      }
      break;
    }

    case 'ATTRACTION_CLOSED': {
      scenarioLabel = '📍 Attraction Closed Emergency';
      explanation = 'Identified scheduled closure / maintenance and pivoted directly to the closest open monument with matching historical pedigree.';

      if (newDays.length > 0) {
        const targetDay = newDays[0];
        const alternative = getUnusedAttraction(a => a.name !== targetDay.morning.attractionName);
        if (alternative) {
          changes.push({
            timeSlot: 'Morning',
            dayNumber: targetDay.day,
            originalItem: `${targetDay.morning.attractionName} (Reported Closed)`,
            newItem: alternative.name,
            changeReason: `Direct pivot to ${alternative.name} (${alternative.category}) with confirmed open hours (${alternative.openingHours || 'Daily'}).`,
            costDiffINR: (alternative.entryFeeINR || 0) - 50,
            travelTimeText: '12 mins nearby'
          });
          targetDay.morning.attractionName = alternative.name;
          targetDay.morning.description = alternative.description;
          targetDay.morning.practicalTip = `Open daily: ${alternative.openingHours || '09:00 AM - 05:30 PM'}.`;
        }
      }
      break;
    }

    case 'MORE_PEOPLE': {
      scenarioLabel = '👥 More People Joined (Group Dynamic)';
      explanation = 'Re-engineered itinerary for group comfort: upgraded dining to spacious heritage banquets and optimized group ticketing rates.';
      
      const groupMultiplier = 1.35;
      costAdjustment = Math.round(originalPlan.estimatedTotalCostINR * 0.35);

      newDays.forEach((day: any) => {
        day.afternoon.lunchSpot = `${day.afternoon.lunchSpot} (Spacious Family Courtyard Seating)`;
        day.evening.dinnerSpot = `${day.evening.dinnerSpot} (Group Heritage Dining)`;
        day.afternoon.practicalTip = 'Advance group table reserved; family style thali service recommended.';
      });

      changes.push({
        timeSlot: 'Transport',
        dayNumber: 1,
        originalItem: 'Standard Auto / Taxi Rides',
        newItem: 'Innova / Tempo Traveler Shuttle',
        changeReason: 'Group transit consolidation to ensure everyone travels together comfortably.',
        costDiffINR: 1200,
        travelTimeText: 'Point-to-point group vehicle'
      });
      break;
    }

    case 'TRANSPORT_PROBLEM': {
      scenarioLabel = '🚗 Transport Disruption / Walkable Route';
      explanation = 'Eliminated long highway and across-city drives. Reorganized attractions into a high-density, scenic walking / e-rickshaw cluster.';
      timeSavedMins = 60;

      newDays.forEach((day: any) => {
        day.transportRecommendations = [
          'Pedestrian heritage corridor & electric e-rickshaws only (Zero cab dependency).',
          'All sights clustered within a 1.5 km walkable perimeter.'
        ];
        changes.push({
          timeSlot: 'Transport',
          dayNumber: day.day,
          originalItem: 'Cross-Town Taxi Hailing',
          newItem: 'Pedestrian Heritage Corridor & E-Rickshaws',
          changeReason: 'Bypassed road congestion & transit breakdown; all venues clustered walking distance.',
          costDiffINR: -400,
          travelTimeText: 'Walkable 5–10 mins between sights'
        });
        costAdjustment -= 400;
      });
      break;
    }

    case 'CUSTOM':
    default: {
      scenarioLabel = customPrompt ? `✏️ Custom: "${customPrompt.slice(0, 30)}..."` : '✏️ Custom Adaptive Update';
      explanation = customPrompt 
        ? `Itinerary dynamically re-tailored to incorporate user request: "${customPrompt}".`
        : 'Adjusted schedule to balance pace, cultural depth, and local ease.';

      // Light adjustment on day 1
      if (newDays.length > 0) {
        const targetDay = newDays[0];
        changes.push({
          timeSlot: 'Morning',
          dayNumber: targetDay.day,
          originalItem: targetDay.morning.attractionName,
          newItem: `${targetDay.morning.attractionName} (Tailored Window)`,
          changeReason: `Paced according to custom note: "${customPrompt || 'Enhanced comfort'}"`,
          costDiffINR: 0,
          travelTimeText: 'Optimized transit'
        });
      }
      break;
    }
  }

  // Calculate costs
  const originalCost = originalPlan.estimatedTotalCostINR || 6500;
  const newCost = Math.max(1200, originalCost + costAdjustment);
  const costDiff = newCost - originalCost;
  const budgetLimit = originalPlan.budgetLevel === 'Luxury' 
    ? 25000 
    : originalPlan.budgetLevel === 'Mid-Range' 
    ? 9000 
    : 4500;

  const isOverBudget = newCost > budgetLimit;
  const overBudgetAmount = isOverBudget ? newCost - budgetLimit : 0;

  // Build adapted plan
  const adaptedPlan: TripPlan = {
    ...originalPlan,
    id: `plan-adapted-${Date.now()}`,
    title: `${originalPlan.title} (${scenarioLabel.split(' ')[1] || 'Adapted'})`,
    summary: `${originalPlan.summary} • Adapted for: ${explanation}`,
    recommendedHotel,
    days: newDays,
    estimatedTotalCostINR: newCost,
  };

  return {
    scenario,
    scenarioLabel,
    explanation,
    changes,
    adaptedPlan,
    originalCostINR: originalCost,
    newCostINR: newCost,
    costDifferenceINR: costDiff,
    budgetLimitINR: budgetLimit,
    isOverBudget,
    overBudgetAmountINR: overBudgetAmount,
    travelTimeSavedMins: timeSavedMins > 0 ? timeSavedMins : undefined
  };
}

/**
 * 2. AI TRIP RECOVERY ENGINE
 * Instant real-time rescue when an activity or stay is actively disrupted
 */
export function recoverDisruption(
  originalPlan: TripPlan,
  cause: DisruptionCause,
  disruptedItem: string = '',
  availableAttractions: Attraction[] = [],
  availableHotels: Hotel[] = [],
  availableFood: FoodItem[] = []
): {
  disruptedItem: string;
  causeLabel: string;
  recommendations: Array<{
    name: string;
    category: string;
    description: string;
    additionalCostINR: number;
    travelTime: string;
    distance: string;
    reason: string;
    actionLabel: string;
    replacementSlot: 'morning' | 'afternoon' | 'evening' | 'hotel';
    itemObject: Attraction | Hotel | FoodItem;
  }>;
  suggestedPlan: TripPlan;
} {
  const causeLabels: Record<DisruptionCause, string> = {
    VEHICLE_PROBLEM: '🚗 Vehicle Problem',
    BAD_WEATHER: '🌧️ Bad Weather',
    RUNNING_LATE: '⏰ Running Late',
    STAY_UNAVAILABLE: '🏨 Stay / Hotel Unavailable',
    ATTRACTION_CLOSED: '📍 Attraction Closed',
    BUDGET_PROBLEM: '💰 Budget Emergency',
    OTHER: '✏️ Trip Disruption'
  };

  const causeLabel = causeLabels[cause] || 'Trip Disruption';
  const targetDisrupted = disruptedItem || originalPlan.days[0]?.morning?.attractionName || 'Current Activity';

  const recommendations: Array<any> = [];

  // Pick 3 high-quality alternatives from existing verified database
  if (cause === 'STAY_UNAVAILABLE') {
    const alternativeStays = availableHotels
      .filter(h => !originalPlan.recommendedHotel || h.id !== originalPlan.recommendedHotel.id)
      .slice(0, 3);

    alternativeStays.forEach((hotel, idx) => {
      const priceDiff = (hotel.pricePerNightINR || 2200) - (originalPlan.recommendedHotel?.pricePerNightINR || 2200);
      recommendations.push({
        name: hotel.name,
        category: hotel.hotelCategory || 'Verified Hotel',
        description: `Instant check-in available. ${hotel.rating}★ rating with ${hotel.amenities.slice(0, 3).join(', ')}.`,
        additionalCostINR: priceDiff,
        travelTime: `${10 + idx * 5} mins`,
        distance: `${1.5 + idx * 0.8} km away`,
        reason: idx === 0 ? 'Closest high-rated accommodation with instant reservation' : 'Verified budget-friendly alternate property',
        actionLabel: 'Select This Hotel',
        replacementSlot: 'hotel',
        itemObject: hotel
      });
    });
  } else {
    // Sights / Activity disruption
    const candidates = availableAttractions
      .filter(a => a.name.toLowerCase() !== targetDisrupted.toLowerCase())
      .slice(0, 3);

    const reasons = [
      'Immediate turn-key entry with zero waiting line and scenic open courtyard.',
      'Authentic cultural landmark just a quick auto-rickshaw ride away.',
      'Beloved local experience offering panoramic viewpoints and traditional refreshments.'
    ];

    candidates.forEach((attr, idx) => {
      recommendations.push({
        name: attr.name,
        category: attr.category || 'Historic Monument',
        description: attr.description,
        additionalCostINR: attr.entryFeeINR || 0,
        travelTime: `${8 + idx * 6} mins`,
        distance: `${0.8 + idx * 0.7} km`,
        reason: reasons[idx % reasons.length],
        actionLabel: 'Pivoting to this sight',
        replacementSlot: idx === 0 ? 'morning' : idx === 1 ? 'afternoon' : 'evening',
        itemObject: attr
      });
    });
  }

  // Create recovered plan with top recommendation
  const recoveredDays = JSON.parse(JSON.stringify(originalPlan.days));
  if (recommendations.length > 0 && recoveredDays[0]) {
    if (recommendations[0].replacementSlot === 'morning') {
      recoveredDays[0].morning.attractionName = recommendations[0].name;
      recoveredDays[0].morning.description = recommendations[0].description;
      recoveredDays[0].morning.practicalTip = `Recovered substitute: ${recommendations[0].reason}`;
    }
  }

  const suggestedPlan: TripPlan = {
    ...originalPlan,
    id: `plan-recovered-${Date.now()}`,
    title: `${originalPlan.title} (Recovered)`,
    days: recoveredDays
  };

  return {
    disruptedItem: targetDisrupted,
    causeLabel,
    recommendations,
    suggestedPlan
  };
}

/**
 * 3. BUDGET RESCUE OPTIMIZER ENGINE
 * Intelligently suggests budget trimming to bring over-budget plans back into safe territory
 */
export function optimizeBudgetPlan(
  currentPlan: TripPlan,
  targetBudgetINR?: number,
  availableHotels: Hotel[] = [],
  availableAttractions: Attraction[] = [],
  availableFood: FoodItem[] = []
): BudgetOptimizationResult {
  const currentCost = currentPlan.estimatedTotalCostINR || 8000;
  const target = targetBudgetINR || Math.round(currentCost * 0.85);

  let newCost = currentCost;
  const daysCount = currentPlan.durationDays || 3;

  // 1. Hotel Optimization
  let hotelSaving = {
    originalName: currentPlan.recommendedHotel?.name || 'Current Hotel',
    originalCost: (currentPlan.recommendedHotel?.pricePerNightINR || 3000) * daysCount,
    newName: currentPlan.recommendedHotel?.name || 'Current Hotel',
    newCost: (currentPlan.recommendedHotel?.pricePerNightINR || 3000) * daysCount,
    diff: 0
  };

  const cheaperHotels = availableHotels
    .filter(h => (h.pricePerNightINR || 3000) < (currentPlan.recommendedHotel?.pricePerNightINR || 3500))
    .sort((a, b) => (a.pricePerNightINR || 1200) - (b.pricePerNightINR || 1200));

  let optimizedHotel = currentPlan.recommendedHotel;

  if (cheaperHotels.length > 0) {
    const cheap = cheaperHotels[0];
    const origTotal = (currentPlan.recommendedHotel?.pricePerNightINR || 3200) * daysCount;
    const newTotal = (cheap.pricePerNightINR || 1800) * daysCount;
    const diff = origTotal - newTotal;

    if (diff > 0) {
      hotelSaving = {
        originalName: currentPlan.recommendedHotel?.name || 'Current Stay',
        originalCost: origTotal,
        newName: cheap.name,
        newCost: newTotal,
        diff
      };
      newCost -= diff;
      optimizedHotel = cheap;
    }
  }

  // 2. Activities Optimization (swap premium sights with free heritage sites)
  const activityReplacements: Array<{ original: string; replacement: string; saved: number }> = [];
  const freeSights = availableAttractions.filter(a => a.entryFeeINR === 0);
  let actSaved = 0;

  const newDays = JSON.parse(JSON.stringify(currentPlan.days));
  newDays.forEach((day: any, idx: number) => {
    if (freeSights[idx] && day.morning.attractionName !== freeSights[idx].name) {
      const origName = day.morning.attractionName;
      const freeSight = freeSights[idx];
      const saved = 150;
      actSaved += saved;
      activityReplacements.push({
        original: origName,
        replacement: freeSight.name,
        saved
      });
      day.morning.attractionName = freeSight.name;
      day.morning.description = freeSight.description;
      day.morning.practicalTip = 'Budget-optimized free heritage sight.';
    }
  });

  newCost -= actSaved;

  // 3. Food Optimization (suggest heritage local joints)
  const foodSaved = Math.min(600, Math.round(daysCount * 250));
  newCost -= foodSaved;

  const optimizedPlan: TripPlan = {
    ...currentPlan,
    id: `plan-budget-rescue-${Date.now()}`,
    title: `${currentPlan.title} (Budget Rescued)`,
    recommendedHotel: optimizedHotel,
    days: newDays,
    estimatedTotalCostINR: Math.max(1500, newCost)
  };

  const totalSavings = currentCost - newCost;

  return {
    originalEstimatedCostINR: currentCost,
    targetBudgetINR: target,
    optimizedCostINR: Math.max(1500, newCost),
    savingsINR: totalSavings,
    isWithinBudget: newCost <= target,
    breakdown: {
      hotelSaving,
      activitiesSaving: {
        originalTotal: Math.round(currentCost * 0.25),
        newTotal: Math.round(currentCost * 0.25) - actSaved,
        diff: actSaved,
        replacements: activityReplacements
      },
      foodSaving: {
        originalTotal: Math.round(currentCost * 0.35),
        newTotal: Math.round(currentCost * 0.35) - foodSaved,
        diff: foodSaved,
        recommendations: [
          'Enjoy iconic centuries-old thali centers and authentic street kiosks over hotel buffets.',
          'Savor local morning breakfast joints (poha, idli, chai) for under ₹100/person.'
        ]
      }
    },
    optimizedPlan
  };
}
