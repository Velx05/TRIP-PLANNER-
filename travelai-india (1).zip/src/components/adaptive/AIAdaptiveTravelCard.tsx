import React from 'react';
import { 
  BrainCircuit, 
  Sparkles, 
  Compass, 
  AlertTriangle, 
  Coins, 
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  Zap
} from 'lucide-react';
import { TripPlan } from '../../types';

interface AIAdaptiveTravelCardProps {
  currentPlan: TripPlan;
  onOpenWhatIf: () => void;
  onOpenTripRecovery: () => void;
  onOpenBudgetRescue?: () => void;
}

export const AIAdaptiveTravelCard: React.FC<AIAdaptiveTravelCardProps> = ({
  currentPlan,
  onOpenWhatIf,
  onOpenTripRecovery,
  onOpenBudgetRescue
}) => {
  return (
    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#121217] via-[#161622] to-[#121217] border border-amber-500/30 p-6 sm:p-7 shadow-2xl space-y-5 group">
      
      {/* Background Ambient Glow */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/5 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
      <div className="absolute bottom-0 left-0 w-60 h-60 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none -ml-20 -mb-20" />

      {/* Top Banner & Tagline */}
      <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
        
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono uppercase bg-amber-400/15 border border-amber-400/30 text-amber-300 font-bold flex items-center gap-1.5">
              <BrainCircuit className="w-3 h-3 text-amber-400" />
              <span>AI ADAPTIVE TRAVEL ENGINE</span>
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-emerald-950/80 border border-emerald-500/30 text-emerald-400 font-medium hidden md:inline-flex items-center gap-1">
              <Zap className="w-2.5 h-2.5" />
              <span>Real-Time Adaptation</span>
            </span>
          </div>

          <h3 className="font-cinzel text-xl sm:text-2xl font-bold text-white tracking-wide flex items-center gap-2">
            <span>🧠 AI ADAPTIVE TRAVEL</span>
          </h3>

          <p className="text-xs sm:text-sm text-[#A1A1AA] italic font-light">
            “Plans can change. Let AI adapt your trip.”
          </p>
        </div>

        {/* USP Micro Badge */}
        <div className="hidden lg:flex flex-col items-end text-right">
          <span className="text-[11px] font-mono text-zinc-400">Adaptive Safety Net</span>
          <span className="text-xs font-mono text-amber-400 font-semibold flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            Zero-Loss Trip Recovery
          </span>
        </div>

      </div>

      {/* Action Buttons & Value Strip */}
      <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
        
        <div className="text-xs text-[#D4D4D8] leading-relaxed max-w-xl">
          Simulate weather shifts, reduced budgets, delays, or hotel shortages. AI re-balances your schedule in seconds without overwriting your original itinerary until you approve.
        </div>

        {/* Action CTA Buttons */}
        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          
          {/* Button 1: What-If Simulator */}
          <button
            type="button"
            onClick={onOpenWhatIf}
            className="px-4 sm:px-5 py-2.5 sm:py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black text-xs font-mono font-bold uppercase tracking-wider transition-all duration-200 cursor-pointer flex items-center gap-2 shadow-lg shadow-amber-400/20 active:scale-98"
          >
            <BrainCircuit className="w-4 h-4 text-black" />
            <span>What-If Simulator</span>
          </button>

          {/* Button 2: Trip Recovery */}
          <button
            type="button"
            onClick={onOpenTripRecovery}
            className="px-4 sm:px-5 py-2.5 sm:py-3 rounded-xl bg-[#14141A] hover:bg-[#1E1E26] text-white hover:text-amber-300 text-xs font-mono font-bold uppercase tracking-wider transition-all duration-200 cursor-pointer flex items-center gap-2 border border-white/15 hover:border-amber-400/40 active:scale-98 shadow-md"
          >
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <span>Trip Recovery</span>
          </button>

          {/* Button 2b: Trip Changed? shortcut */}
          <button
            type="button"
            onClick={onOpenTripRecovery}
            className="px-4 sm:px-5 py-2.5 sm:py-3 rounded-xl bg-red-950/40 hover:bg-red-900/40 text-red-300 hover:text-red-200 text-xs font-mono font-bold uppercase tracking-wider transition-all duration-200 cursor-pointer flex items-center gap-2 border border-red-500/30 hover:border-red-400/50 active:scale-98 shadow-md"
            title="Instant recovery for cancelled flights, delayed cabs, closed sights"
          >
            <span>🚨 Trip Changed?</span>
          </button>

          {/* Button 3: Budget Rescue (if available) */}
          {onOpenBudgetRescue && (
            <button
              type="button"
              onClick={onOpenBudgetRescue}
              className="px-3.5 py-2.5 sm:py-3 rounded-xl bg-emerald-950/40 hover:bg-emerald-900/40 text-emerald-300 text-xs font-mono font-semibold uppercase tracking-wider transition-all duration-200 cursor-pointer flex items-center gap-1.5 border border-emerald-500/30 active:scale-98"
              title="Optimize expenses to stay within trip budget"
            >
              <Coins className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">Budget Rescue</span>
            </button>
          )}

        </div>

      </div>

    </div>
  );
};
