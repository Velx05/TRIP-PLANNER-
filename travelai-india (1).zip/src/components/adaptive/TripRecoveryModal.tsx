import React, { useState, useMemo } from 'react';
import { 
  X, 
  AlertTriangle, 
  Car, 
  CloudRain, 
  Clock, 
  Hotel as HotelIcon, 
  MapPin, 
  Coins, 
  Edit3, 
  CheckCircle2, 
  ArrowRight, 
  ShieldCheck, 
  Navigation, 
  Tag, 
  Sparkles,
  Layers
} from 'lucide-react';
import { 
  TripPlan, 
  Attraction, 
  Hotel, 
  FoodItem, 
  DisruptionCause 
} from '../../types';
import { recoverDisruption } from './adaptiveEngine';

interface TripRecoveryModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentPlan: TripPlan;
  availableAttractions: Attraction[];
  availableHotels: Hotel[];
  availableFood: FoodItem[];
  onApplyRecovery: (newPlan: TripPlan, disruptionSummary: string) => void;
}

const DISRUPTIONS: Array<{
  id: DisruptionCause;
  label: string;
  icon: string;
  description: string;
}> = [
  { id: 'VEHICLE_PROBLEM', label: 'Vehicle Problem', icon: '🚗', description: 'Breakdown, cab cancel, road block' },
  { id: 'BAD_WEATHER', label: 'Bad Weather', icon: '🌧️', description: 'Sudden rainstorm, extreme midday heat' },
  { id: 'RUNNING_LATE', label: 'Running Late', icon: '⏰', description: 'Overslept or stuck in transit traffic' },
  { id: 'STAY_UNAVAILABLE', label: 'Stay Unavailable', icon: '🏨', description: 'Check-in issue, property overbooked' },
  { id: 'ATTRACTION_CLOSED', label: 'Attraction Closed', icon: '📍', description: 'Weekly off, maintenance, VIP closure' },
  { id: 'BUDGET_PROBLEM', label: 'Budget Problem', icon: '💰', description: 'Unexpected expense, need cheap options' },
  { id: 'OTHER', label: 'Other Issue', icon: '✏️', description: 'Emergency or spontaneous detour' },
];

export const TripRecoveryModal: React.FC<TripRecoveryModalProps> = ({
  isOpen,
  onClose,
  currentPlan,
  availableAttractions,
  availableHotels,
  availableFood,
  onApplyRecovery
}) => {
  const [selectedCause, setSelectedCause] = useState<DisruptionCause>('ATTRACTION_CLOSED');
  const [selectedDisruptedItem, setSelectedDisruptedItem] = useState<string>('');
  const [selectedAlternativeIndex, setSelectedAlternativeIndex] = useState<number>(0);

  // Collect current activities list to let user pick what got disrupted
  const activityChoices = useMemo(() => {
    const list: string[] = [];
    currentPlan.days.forEach(d => {
      if (d.morning?.attractionName) list.push(d.morning.attractionName);
      if (d.afternoon?.attractionName) list.push(d.afternoon.attractionName);
      if (d.evening?.attractionOrActivity) list.push(d.evening.attractionOrActivity);
    });
    if (currentPlan.recommendedHotel) {
      list.push(`Hotel: ${currentPlan.recommendedHotel.name}`);
    }
    return Array.from(new Set(list));
  }, [currentPlan]);

  // Set default disrupted item
  const activeDisrupted = selectedDisruptedItem || activityChoices[0] || 'Scheduled Activity';

  // Run recovery engine
  const recoveryResult = useMemo(() => {
    return recoverDisruption(
      currentPlan,
      selectedCause,
      activeDisrupted,
      availableAttractions,
      availableHotels,
      availableFood
    );
  }, [currentPlan, selectedCause, activeDisrupted, availableAttractions, availableHotels, availableFood]);

  if (!isOpen) return null;

  const handleApply = () => {
    const chosen = recoveryResult.recommendations[selectedAlternativeIndex] || recoveryResult.recommendations[0];
    const updatedPlan: TripPlan = JSON.parse(JSON.stringify(recoveryResult.suggestedPlan));

    if (chosen && updatedPlan.days[0]) {
      if (chosen.replacementSlot === 'hotel' && 'hotelCategory' in chosen.itemObject) {
        updatedPlan.recommendedHotel = chosen.itemObject as Hotel;
      } else {
        updatedPlan.days[0].morning.attractionName = chosen.name;
        updatedPlan.days[0].morning.description = chosen.description;
        updatedPlan.days[0].morning.practicalTip = `Recovered: ${chosen.reason}`;
      }
    }

    onApplyRecovery(updatedPlan, `🚨 Trip Recovery Applied (${recoveryResult.causeLabel})`);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div 
        className="relative w-full max-w-3xl bg-[#0D0D11] border border-amber-500/30 rounded-3xl shadow-2xl overflow-hidden my-auto text-white flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-white/10 flex items-center justify-between gap-4 bg-[#14141A]">
          <div className="space-y-1">
            <span className="text-[10px] font-mono tracking-widest uppercase text-amber-400 flex items-center gap-1.5 font-bold">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
              AI REAL-TIME TRIP RECOVERY
            </span>
            <h2 className="font-cinzel text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
              <span>🚨 Trip Changed? “What happened?”</span>
            </h2>
            <p className="text-xs text-[#A1A1AA]">
              Instant real-time alternatives using verified attractions & hotels in <span className="text-amber-300 font-semibold">{currentPlan.destinationName}</span>. Your original itinerary is safe until you confirm.
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2.5 rounded-full bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer border border-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 space-y-6 overflow-y-auto font-sans">
          
          {/* 1. What Happened? (Disruption Type Selector) */}
          <div className="space-y-2.5">
            <label className="text-xs font-mono uppercase tracking-wider text-[#A1A1AA] block">
              1. What Disrupted Your Plan?
            </label>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {DISRUPTIONS.map((item) => {
                const isSelected = selectedCause === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setSelectedCause(item.id)}
                    className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-1 ${
                      isSelected
                        ? 'bg-amber-400/20 border-amber-400 text-white shadow-md'
                        : 'bg-[#14141A] border-white/10 text-zinc-400 hover:text-white hover:border-white/20'
                    }`}
                  >
                    <div className="text-base">{item.icon}</div>
                    <div>
                      <div className={`text-xs font-mono font-bold ${isSelected ? 'text-amber-300' : 'text-zinc-200'}`}>
                        {item.label}
                      </div>
                      <div className="text-[10px] text-zinc-500 line-clamp-1">
                        {item.description}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. Which Activity / Stay was Affected? */}
          <div className="space-y-2">
            <label className="text-xs font-mono uppercase tracking-wider text-[#A1A1AA] flex items-center justify-between">
              <span>2. Which Item Was Disrupted?</span>
              <span className="text-[10px] text-zinc-500">From Your Current Plan</span>
            </label>

            <select
              value={activeDisrupted}
              onChange={(e) => setSelectedDisruptedItem(e.target.value)}
              className="w-full px-4 py-3 bg-[#14141A] border border-white/15 focus:border-amber-400 rounded-xl text-xs font-mono text-white focus:outline-none cursor-pointer"
            >
              {activityChoices.map((act, i) => (
                <option key={i} value={act} className="bg-[#14141A] text-white">
                  {act}
                </option>
              ))}
            </select>
          </div>

          {/* 3. Disruption vs AI Recovery Presentation */}
          <div className="p-4 rounded-2xl bg-[#14141A] border border-white/10 space-y-3">
            
            {/* Disrupted Header */}
            <div className="flex items-center justify-between pb-3 border-b border-white/5">
              <div className="text-xs font-mono">
                <span className="text-zinc-400">Current Activity: </span>
                <span className="text-red-400 font-bold line-through">
                  ❌ {activeDisrupted} — unavailable
                </span>
              </div>
              <span className="px-2.5 py-0.5 rounded-full bg-red-950/80 border border-red-500/30 text-red-400 text-[10px] font-mono font-bold uppercase">
                Disrupted
              </span>
            </div>

            {/* AI Recovery Alternatives Header */}
            <div className="text-xs font-mono uppercase text-amber-400 font-bold flex items-center gap-1.5 pt-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>AI Recovery Recommendations ({recoveryResult.recommendations.length} Verified Options):</span>
            </div>

            {/* List of 3 Verified AI Recovery Recommendations */}
            <div className="space-y-3">
              {recoveryResult.recommendations.map((rec, idx) => {
                const isChosen = selectedAlternativeIndex === idx;
                return (
                  <div
                    key={idx}
                    onClick={() => setSelectedAlternativeIndex(idx)}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer space-y-2.5 ${
                      isChosen
                        ? 'bg-gradient-to-r from-amber-950/30 via-[#161622] to-[#14141A] border-amber-400 shadow-xl'
                        : 'bg-black/30 border-white/10 hover:border-white/25'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="text-emerald-400 font-bold text-sm">
                            ✅ {rec.name}
                          </span>
                          <span className="px-2 py-0.5 rounded-md bg-white/10 text-zinc-300 text-[10px] font-mono">
                            {rec.category}
                          </span>
                        </div>
                        <p className="text-xs text-[#A1A1AA] line-clamp-2 leading-relaxed">
                          {rec.description}
                        </p>
                      </div>

                      <div className="shrink-0 flex items-center">
                        <input
                          type="radio"
                          name="recovery-choice"
                          checked={isChosen}
                          onChange={() => setSelectedAlternativeIndex(idx)}
                          className="w-4 h-4 accent-amber-400 cursor-pointer"
                        />
                      </div>
                    </div>

                    {/* Metadata Strip: Additional Cost, Travel Time, Distance, Reason */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-white/5 font-mono text-[11px]">
                      
                      <div className="space-y-0.5">
                        <span className="text-zinc-500 uppercase text-[9px] block">Additional Cost</span>
                        <span className={rec.additionalCostINR <= 0 ? 'text-emerald-400 font-bold' : 'text-amber-300 font-bold'}>
                          {rec.additionalCostINR <= 0 ? '₹0 (Included)' : `+₹${rec.additionalCostINR}`}
                        </span>
                      </div>

                      <div className="space-y-0.5">
                        <span className="text-zinc-500 uppercase text-[9px] block">Travel Time</span>
                        <span className="text-white flex items-center gap-1">
                          <Clock className="w-3 h-3 text-amber-400" />
                          {rec.travelTime}
                        </span>
                      </div>

                      <div className="space-y-0.5">
                        <span className="text-zinc-500 uppercase text-[9px] block">Distance</span>
                        <span className="text-white flex items-center gap-1">
                          <Navigation className="w-3 h-3 text-amber-400" />
                          {rec.distance}
                        </span>
                      </div>

                      <div className="space-y-0.5 col-span-2 sm:col-span-1">
                        <span className="text-zinc-500 uppercase text-[9px] block">Why AI Selected</span>
                        <span className="text-zinc-300 truncate block" title={rec.reason}>
                          {rec.reason}
                        </span>
                      </div>

                    </div>

                  </div>
                );
              })}
            </div>

          </div>

        </div>

        {/* Footer */}
        <div className="p-5 sm:p-6 border-t border-white/10 bg-[#14141A] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          
          <div className="text-[11px] font-mono text-[#A1A1AA] flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Never automatically overwrites your itinerary.</span>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-mono text-xs uppercase tracking-wider cursor-pointer border border-white/10 transition-colors"
            >
              Cancel
            </button>

            <button
              type="button"
              onClick={handleApply}
              className="flex-1 sm:flex-none px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black font-mono font-bold text-xs uppercase tracking-wider cursor-pointer shadow-lg shadow-amber-400/20 active:scale-98 transition-all flex items-center justify-center gap-1.5"
            >
              <CheckCircle2 className="w-4 h-4 text-black" />
              <span>Apply Recovery</span>
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
