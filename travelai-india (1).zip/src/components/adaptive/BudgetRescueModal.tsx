import React, { useMemo } from 'react';
import { 
  X, 
  Coins, 
  AlertTriangle, 
  CheckCircle2, 
  ArrowRight, 
  Hotel as HotelIcon, 
  Landmark, 
  Utensils, 
  ShieldCheck, 
  Sparkles,
  TrendingDown
} from 'lucide-react';
import { TripPlan, Hotel, Attraction, FoodItem, BudgetOptimizationResult } from '../../types';
import { optimizeBudgetPlan } from './adaptiveEngine';

interface BudgetRescueModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentPlan: TripPlan;
  availableHotels: Hotel[];
  availableAttractions: Attraction[];
  availableFood: FoodItem[];
  targetBudgetINR?: number;
  onApplyOptimizedPlan: (optimizedPlan: TripPlan, savingsSummary: string) => void;
}

export const BudgetRescueModal: React.FC<BudgetRescueModalProps> = ({
  isOpen,
  onClose,
  currentPlan,
  availableHotels,
  availableAttractions,
  availableFood,
  targetBudgetINR,
  onApplyOptimizedPlan
}) => {
  const optimizationResult: BudgetOptimizationResult = useMemo(() => {
    return optimizeBudgetPlan(
      currentPlan,
      targetBudgetINR,
      availableHotels,
      availableAttractions,
      availableFood
    );
  }, [currentPlan, targetBudgetINR, availableHotels, availableAttractions, availableFood]);

  if (!isOpen) return null;

  const currentCost = currentPlan.estimatedTotalCostINR || 8000;
  const budgetCap = targetBudgetINR || (currentPlan.budgetLevel === 'Luxury' ? 20000 : currentPlan.budgetLevel === 'Budget' ? 4000 : 8000);
  const isOver = currentCost > budgetCap;
  const overAmount = isOver ? currentCost - budgetCap : 0;

  const handleApply = () => {
    onApplyOptimizedPlan(
      optimizationResult.optimizedPlan,
      `💰 Budget Rescued: Saved ₹${optimizationResult.savingsINR.toLocaleString()} total!`
    );
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div 
        className="relative w-full max-w-2xl bg-[#0D0D11] border border-emerald-500/30 rounded-3xl shadow-2xl overflow-hidden my-auto text-white flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-white/10 flex items-center justify-between gap-4 bg-[#14141A]">
          <div className="space-y-1">
            <span className="text-[10px] font-mono tracking-widest uppercase text-emerald-400 flex items-center gap-1.5 font-bold">
              <Coins className="w-3.5 h-3.5 text-emerald-400" />
              AI BUDGET RESCUE OPTIMIZER
            </span>
            <h2 className="font-cinzel text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
              <span>💰 AI Budget Rescue</span>
            </h2>
            <p className="text-xs text-[#A1A1AA]">
              Intelligently trims expenses with verified cheaper stays, free heritage landmarks, and affordable food without sacrificing your trip experience.
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2.5 rounded-full bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer border border-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 space-y-6 overflow-y-auto font-sans">
          
          {/* 1. Over Budget Warning Banner */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-red-950/40 via-[#181824] to-black/50 border border-red-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="font-mono font-bold text-red-400 flex items-center gap-2 text-sm">
                <AlertTriangle className="w-4 h-4 text-red-400" />
                <span>⚠️ ₹{overAmount.toLocaleString()} Over Budget</span>
              </div>
              <div className="text-xs text-zinc-300 font-mono">
                Current Estimated Plan: <span className="text-white font-bold">₹{currentCost.toLocaleString()}</span> • Target Budget: <span className="text-amber-300">₹{budgetCap.toLocaleString()}</span>
              </div>
            </div>

            <div className="px-3.5 py-1.5 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 font-mono text-xs font-bold shrink-0 flex items-center gap-1.5">
              <TrendingDown className="w-3.5 h-3.5 text-emerald-400" />
              <span>Potential Savings: ₹{optimizationResult.savingsINR.toLocaleString()}</span>
            </div>
          </div>

          {/* 2. Three-Tier AI Optimization Breakdown (Hotel, Activity, Food) */}
          <div className="space-y-3">
            <span className="text-xs font-mono uppercase tracking-wider text-[#A1A1AA] block">
              AI Cheaper Alternatives & Trimming Breakdown:
            </span>

            {/* Item 1: Hotel Optimization */}
            <div className="p-4 rounded-2xl bg-[#14141A] border border-white/10 space-y-2 text-xs">
              <div className="flex items-center justify-between font-mono">
                <span className="text-amber-400 font-bold flex items-center gap-1.5 uppercase">
                  <HotelIcon className="w-3.5 h-3.5" />
                  Hotel / Accommodation Optimization
                </span>
                <span className="text-emerald-400 font-bold">
                  Save ₹{optimizationResult.breakdown.hotelSaving.diff.toLocaleString()}
                </span>
              </div>

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 font-mono text-xs bg-black/30 p-2.5 rounded-xl border border-white/5">
                <div className="text-zinc-400 line-through truncate flex-1">
                  {optimizationResult.breakdown.hotelSaving.originalName} (₹{optimizationResult.breakdown.hotelSaving.originalCost.toLocaleString()})
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-zinc-500 hidden sm:block shrink-0" />
                <div className="text-emerald-400 font-bold truncate flex-1">
                  {optimizationResult.breakdown.hotelSaving.newName} (₹{optimizationResult.breakdown.hotelSaving.newCost.toLocaleString()})
                </div>
              </div>
              <div className="text-[11px] text-[#A1A1AA] font-light">
                Verified high-rated sister stay in the same locality with zero prepayment required.
              </div>
            </div>

            {/* Item 2: Activity Optimization */}
            <div className="p-4 rounded-2xl bg-[#14141A] border border-white/10 space-y-2 text-xs">
              <div className="flex items-center justify-between font-mono">
                <span className="text-amber-400 font-bold flex items-center gap-1.5 uppercase">
                  <Landmark className="w-3.5 h-3.5" />
                  Activity & Sightseeing Optimization
                </span>
                <span className="text-emerald-400 font-bold">
                  Save ₹{optimizationResult.breakdown.activitiesSaving.diff.toLocaleString()}
                </span>
              </div>

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 font-mono text-xs bg-black/30 p-2.5 rounded-xl border border-white/5">
                <div className="text-zinc-400 line-through truncate flex-1">
                  Ticketed Attractions (₹{optimizationResult.breakdown.activitiesSaving.originalTotal.toLocaleString()})
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-zinc-500 hidden sm:block shrink-0" />
                <div className="text-emerald-400 font-bold truncate flex-1">
                  Free Heritage Sights (₹{optimizationResult.breakdown.activitiesSaving.newTotal.toLocaleString()})
                </div>
              </div>
              <div className="text-[11px] text-[#A1A1AA] font-light">
                Replaced paid tickets with verified ₹0 admission UNESCO ghats, open temples, and public viewpoints.
              </div>
            </div>

            {/* Item 3: Food Optimization */}
            <div className="p-4 rounded-2xl bg-[#14141A] border border-white/10 space-y-2 text-xs">
              <div className="flex items-center justify-between font-mono">
                <span className="text-amber-400 font-bold flex items-center gap-1.5 uppercase">
                  <Utensils className="w-3.5 h-3.5" />
                  Dining & Food Budgeting
                </span>
                <span className="text-emerald-400 font-bold">
                  Save ₹{optimizationResult.breakdown.foodSaving.diff.toLocaleString()}
                </span>
              </div>

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 font-mono text-xs bg-black/30 p-2.5 rounded-xl border border-white/5">
                <div className="text-zinc-400 line-through truncate flex-1">
                  Buffets & Room Dining (₹{optimizationResult.breakdown.foodSaving.originalTotal.toLocaleString()})
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-zinc-500 hidden sm:block shrink-0" />
                <div className="text-emerald-400 font-bold truncate flex-1">
                  Centuries-Old Eateries (₹{optimizationResult.breakdown.foodSaving.newTotal.toLocaleString()})
                </div>
              </div>
              <div className="text-[11px] text-[#A1A1AA] font-light">
                {optimizationResult.breakdown.foodSaving.recommendations[0]}
              </div>
            </div>

          </div>

          {/* 3. New Estimate Result Banner */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/40 via-emerald-900/20 to-black/60 border border-emerald-500/40 flex items-center justify-between gap-4 font-mono">
            <div>
              <span className="text-[10px] text-zinc-400 uppercase tracking-widest block">
                NEW ESTIMATE WITH SAVINGS
              </span>
              <div className="text-xl sm:text-2xl font-bold text-emerald-400">
                ₹{optimizationResult.optimizedCostINR.toLocaleString()}
              </div>
            </div>

            <div className="px-3.5 py-1.5 rounded-xl bg-emerald-500 text-black font-bold text-xs uppercase flex items-center gap-1.5 shadow-md">
              <CheckCircle2 className="w-4 h-4 text-black" />
              <span>Within Budget</span>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="p-5 sm:p-6 border-t border-white/10 bg-[#14141A] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          
          <div className="text-[11px] font-mono text-[#A1A1AA] flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Original budget preference is never modified.</span>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-mono text-xs uppercase tracking-wider cursor-pointer border border-white/10 transition-colors"
            >
              Dismiss
            </button>

            <button
              type="button"
              onClick={handleApply}
              className="flex-1 sm:flex-none px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-400 to-emerald-500 hover:from-emerald-300 hover:to-emerald-400 text-black font-mono font-bold text-xs uppercase tracking-wider cursor-pointer shadow-lg shadow-emerald-500/20 active:scale-98 transition-all flex items-center justify-center gap-1.5"
            >
              <CheckCircle2 className="w-4 h-4 text-black" />
              <span>Apply Optimized Budget</span>
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
