import React, { useState, useMemo } from 'react';
import { 
  X, 
  BrainCircuit, 
  CloudRain, 
  DollarSign, 
  Clock, 
  Hotel as HotelIcon, 
  MapPin, 
  Users, 
  Car, 
  Edit3, 
  ArrowDown, 
  ArrowRight, 
  CheckCircle2, 
  AlertTriangle, 
  Sparkles, 
  ShieldCheck, 
  Coins, 
  RotateCcw,
  Tag,
  Navigation
} from 'lucide-react';
import { 
  TripPlan, 
  Attraction, 
  Hotel, 
  FoodItem, 
  AdaptiveScenario, 
  AdaptivePlanResult 
} from '../../types';
import { simulateWhatIf } from './adaptiveEngine';

interface WhatIfSimulatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentPlan: TripPlan;
  availableAttractions: Attraction[];
  availableHotels: Hotel[];
  availableFood: FoodItem[];
  onApplyPlan: (newPlan: TripPlan, scenarioLabel: string) => void;
  onOpenBudgetRescueModal?: (plan: TripPlan) => void;
}

const SCENARIOS: Array<{
  id: AdaptiveScenario;
  label: string;
  icon: string;
  description: string;
}> = [
  { id: 'BAD_WEATHER', label: 'Bad Weather', icon: '🌧️', description: 'Swap outdoor rain/heat spots with sheltered heritage museums & galleries' },
  { id: 'BUDGET_DECREASED', label: 'Budget Decreased', icon: '💰', description: 'Re-align expenses to save funds with verified ₹0 free heritage landmarks' },
  { id: 'RUNNING_LATE', label: 'Running Late', icon: '⏰', description: 'Fast-track schedule, eliminate long transit, and prioritize core highlights' },
  { id: 'HOTEL_UNAVAILABLE', label: 'Hotel Unavailable', icon: '🏨', description: 'Instantly find available verified alternative accommodation in same area' },
  { id: 'ATTRACTION_CLOSED', label: 'Attraction Closed', icon: '📍', description: 'Pivot immediately to the closest open monument with matching culture' },
  { id: 'MORE_PEOPLE', label: 'More People Join', icon: '👥', description: 'Upgrade dining to family courtyards and group shuttle transit' },
  { id: 'TRANSPORT_PROBLEM', label: 'Transport Problem', icon: '🚗', description: 'Eliminate cabs; cluster sights into a high-density walkable corridor' },
  { id: 'CUSTOM', label: 'Custom Change', icon: '✏️', description: 'Type your specific condition or trip priority' },
];

export const WhatIfSimulatorModal: React.FC<WhatIfSimulatorModalProps> = ({
  isOpen,
  onClose,
  currentPlan,
  availableAttractions,
  availableHotels,
  availableFood,
  onApplyPlan,
  onOpenBudgetRescueModal
}) => {
  const [selectedScenario, setSelectedScenario] = useState<AdaptiveScenario>('BAD_WEATHER');
  const [customPrompt, setCustomPrompt] = useState<string>('');
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  // Calculate adaptation
  const simulationResult: AdaptivePlanResult = useMemo(() => {
    return simulateWhatIf(
      currentPlan,
      selectedScenario,
      customPrompt,
      availableAttractions,
      availableHotels,
      availableFood
    );
  }, [currentPlan, selectedScenario, customPrompt, availableAttractions, availableHotels, availableFood]);

  if (!isOpen) return null;

  const handleSelectScenario = (id: AdaptiveScenario) => {
    setIsSimulating(true);
    setSelectedScenario(id);
    setTimeout(() => setIsSimulating(false), 250);
  };

  const handleApply = () => {
    onApplyPlan(simulationResult.adaptedPlan, simulationResult.scenarioLabel);
    onClose();
  };

  // Original highlights sequence for visual diff
  const originalHighlights = currentPlan.days.slice(0, 2).flatMap(d => [
    d.morning.attractionName,
    d.afternoon.attractionName,
    d.evening.attractionOrActivity
  ]).slice(0, 4);

  // Adapted highlights sequence
  const adaptedHighlights = simulationResult.adaptedPlan.days.slice(0, 2).flatMap(d => [
    d.morning.attractionName,
    d.afternoon.attractionName,
    d.evening.attractionOrActivity
  ]).slice(0, 4);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div 
        className="relative w-full max-w-3xl bg-[#0D0D11] border border-white/20 rounded-3xl shadow-2xl overflow-hidden my-auto text-white flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-white/10 flex items-center justify-between gap-4 bg-[#14141A]/80">
          <div className="space-y-1">
            <span className="text-[10px] font-mono tracking-widest uppercase text-amber-400 flex items-center gap-1.5 font-bold">
              <BrainCircuit className="w-3.5 h-3.5 text-amber-400" />
              AI WHAT-IF SCENARIO SIMULATOR
            </span>
            <h2 className="font-cinzel text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
              <span>🧠 What happens if your plans change?</span>
            </h2>
            <p className="text-xs text-[#A1A1AA]">
              Simulate disruptions against your real <span className="text-amber-300 font-semibold">{currentPlan.destinationName}</span> itinerary. Original schedule stays untouched until you explicitly apply.
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2.5 rounded-full bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer border border-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-5 sm:p-6 space-y-6 overflow-y-auto font-sans">
          
          {/* 1. Scenario Selection Grid */}
          <div className="space-y-2.5">
            <label className="text-xs font-mono uppercase tracking-wider text-[#A1A1AA] flex items-center justify-between">
              <span>Select What Changed:</span>
              <span className="text-[10px] text-amber-400">8 Adaptive Models</span>
            </label>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {SCENARIOS.map((item) => {
                const isSelected = selectedScenario === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleSelectScenario(item.id)}
                    className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-1.5 group ${
                      isSelected
                        ? 'bg-amber-400/15 border-amber-400 text-white shadow-lg shadow-amber-400/10'
                        : 'bg-[#14141A] border-white/10 text-zinc-400 hover:border-white/20 hover:text-white'
                    }`}
                  >
                    <div className="text-lg">{item.icon}</div>
                    <div className="space-y-0.5">
                      <div className={`text-xs font-mono font-bold leading-tight ${isSelected ? 'text-amber-300' : 'text-zinc-200'}`}>
                        {item.label}
                      </div>
                      <div className="text-[10px] text-zinc-500 line-clamp-2 leading-tight font-light">
                        {item.description}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Custom Change Input Field (Shown if CUSTOM selected) */}
            {selectedScenario === 'CUSTOM' && (
              <div className="pt-2 animate-in fade-in duration-150">
                <input
                  type="text"
                  value={customPrompt}
                  onChange={(e) => setCustomPrompt(e.target.value)}
                  placeholder="e.g. Traveling with senior citizens, avoid steep stairs; want vegetarian food only"
                  className="w-full px-4 py-3 bg-[#14141A] border border-amber-400/40 rounded-xl text-xs font-mono text-white placeholder-zinc-500 focus:outline-none focus:border-amber-400"
                />
              </div>
            )}
          </div>

          {/* 2. Visual Adaptation Flow: CURRENT PLAN ↓ AI ADAPTATION ↓ NEW SUGGESTED PLAN */}
          <div className="p-5 rounded-2xl bg-[#14141A] border border-white/10 space-y-4">
            
            <div className="text-[11px] font-mono tracking-wider uppercase text-zinc-400 flex items-center justify-between border-b border-white/5 pb-2">
              <span className="font-bold text-amber-400">PLAN COMPARISON ENGINE</span>
              <span className="text-emerald-400">Deterministic Real-World Data</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
              
              {/* Box 1: CURRENT PLAN */}
              <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-2">
                <span className="text-[10px] font-mono uppercase tracking-wider text-zinc-400 block font-bold">
                  1. CURRENT PLAN
                </span>
                <div className="text-xs font-semibold text-white truncate">
                  {currentPlan.title}
                </div>
                <div className="space-y-1 text-[11px] font-mono text-zinc-400">
                  {originalHighlights.map((name, i) => (
                    <div key={i} className="truncate flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-zinc-500 shrink-0" />
                      <span className="truncate">{name}</span>
                    </div>
                  ))}
                </div>
                <div className="text-[11px] font-mono text-zinc-400 pt-1 border-t border-white/5">
                  Cost: <span className="text-white font-bold">₹{simulationResult.originalCostINR.toLocaleString()}</span>
                </div>
              </div>

              {/* Box 2: AI ADAPTATION (Arrow / Middle Column) */}
              <div className="flex flex-col items-center justify-center p-3 text-center space-y-2">
                <span className="px-2.5 py-1 rounded-full bg-amber-400 text-black font-mono font-bold text-[10px] uppercase shadow-md flex items-center gap-1">
                  <BrainCircuit className="w-3 h-3" />
                  AI ADAPTATION
                </span>
                <ArrowDown className="w-4 h-4 text-amber-400 animate-bounce md:hidden" />
                <ArrowRight className="w-4 h-4 text-amber-400 hidden md:block" />
                <span className="text-[11px] text-amber-300/90 font-mono italic max-w-[200px] leading-tight">
                  {simulationResult.scenarioLabel}
                </span>
              </div>

              {/* Box 3: NEW SUGGESTED PLAN */}
              <div className="p-4 rounded-xl bg-gradient-to-br from-amber-950/20 to-black/60 border border-amber-500/30 space-y-2">
                <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 block font-bold">
                  2. NEW SUGGESTED PLAN
                </span>
                <div className="text-xs font-semibold text-white truncate">
                  {simulationResult.adaptedPlan.title}
                </div>
                <div className="space-y-1 text-[11px] font-mono text-amber-200/90">
                  {adaptedHighlights.map((name, i) => (
                    <div key={i} className="truncate flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
                      <span className="truncate">{name}</span>
                    </div>
                  ))}
                </div>
                <div className="text-[11px] font-mono text-zinc-400 pt-1 border-t border-white/5 flex items-center justify-between">
                  <span>New Est:</span>
                  <span className="text-amber-400 font-bold">₹{simulationResult.newCostINR.toLocaleString()}</span>
                </div>
              </div>

            </div>

            {/* AI Explanation Banner */}
            <div className="p-3.5 rounded-xl bg-amber-950/30 border border-amber-500/20 text-xs text-amber-200/90 leading-relaxed font-light">
              <span className="font-mono font-bold text-amber-400 uppercase tracking-wide block mb-1">
                AI Adaptation Rationale:
              </span>
              “{simulationResult.explanation}”
            </div>

          </div>

          {/* 3. Detailed Change Log Breakdown */}
          {simulationResult.changes.length > 0 && (
            <div className="space-y-3">
              <span className="text-xs font-mono uppercase tracking-wider text-[#A1A1AA] block">
                Changed Items & Modifications ({simulationResult.changes.length}):
              </span>

              <div className="space-y-2.5">
                {simulationResult.changes.map((item, idx) => (
                  <div 
                    key={idx}
                    className="p-3.5 rounded-2xl bg-[#14141A] border border-white/10 space-y-2 text-xs"
                  >
                    <div className="flex items-center justify-between font-mono text-[11px]">
                      <span className="px-2 py-0.5 rounded-md bg-white/10 text-white font-bold uppercase">
                        Day {item.dayNumber} • {item.timeSlot}
                      </span>
                      {item.travelTimeText && (
                        <span className="text-zinc-400 flex items-center gap-1">
                          <Navigation className="w-3 h-3 text-amber-400" />
                          {item.travelTimeText}
                        </span>
                      )}
                    </div>

                    <div className="flex flex-col sm:flex-row sm:items-center gap-2 font-mono">
                      <div className="text-red-400/90 line-through truncate flex-1">
                        ❌ {item.originalItem}
                      </div>
                      <ArrowRight className="w-3.5 h-3.5 text-zinc-500 hidden sm:block shrink-0" />
                      <div className="text-emerald-400 font-bold truncate flex-1">
                        ✅ {item.newItem}
                      </div>
                    </div>

                    <div className="text-[11px] text-[#A1A1AA] font-light leading-relaxed">
                      <strong className="text-zinc-300">Reason:</strong> {item.changeReason}
                    </div>

                    {item.costDiffINR !== 0 && (
                      <div className="text-[10px] font-mono text-zinc-400">
                        Cost Impact: <span className={item.costDiffINR < 0 ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}>
                          {item.costDiffINR < 0 ? `-₹${Math.abs(item.costDiffINR)} (Saved)` : `+₹${item.costDiffINR}`}
                        </span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 4. Budget & Cost Summary Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
            
            <div className="p-3 rounded-xl bg-[#14141A] border border-white/10 space-y-1">
              <span className="text-[10px] text-zinc-400 uppercase">Original Cost</span>
              <div className="font-bold text-white text-sm">₹{simulationResult.originalCostINR.toLocaleString()}</div>
            </div>

            <div className="p-3 rounded-xl bg-[#14141A] border border-white/10 space-y-1">
              <span className="text-[10px] text-zinc-400 uppercase">Adapted Cost</span>
              <div className="font-bold text-amber-400 text-sm">₹{simulationResult.newCostINR.toLocaleString()}</div>
            </div>

            <div className="p-3 rounded-xl bg-[#14141A] border border-white/10 space-y-1">
              <span className="text-[10px] text-zinc-400 uppercase">Budget Cap</span>
              <div className="font-bold text-zinc-200 text-sm">₹{simulationResult.budgetLimitINR.toLocaleString()}</div>
            </div>

            <div className="p-3 rounded-xl bg-[#14141A] border border-white/10 space-y-1">
              <span className="text-[10px] text-zinc-400 uppercase">Budget Status</span>
              <div className={`font-bold text-xs ${simulationResult.isOverBudget ? 'text-red-400' : 'text-emerald-400'}`}>
                {simulationResult.isOverBudget 
                  ? `⚠️ Over by ₹${simulationResult.overBudgetAmountINR.toLocaleString()}` 
                  : '✅ Within Safe Budget'}
              </div>
            </div>

          </div>

          {/* Budget Alert & Optimization Trigger */}
          {simulationResult.isOverBudget && (
            <div className="p-4 rounded-2xl bg-red-950/40 border border-red-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div className="space-y-0.5">
                <div className="font-mono font-bold text-red-400 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-red-400" />
                  <span>⚠️ ₹{simulationResult.overBudgetAmountINR.toLocaleString()} Over Budget</span>
                </div>
                <div className="text-[11px] text-zinc-300">
                  This adaptation exceeds the default {currentPlan.budgetLevel} cap. Run AI Budget Rescue to trim stay and activity fees.
                </div>
              </div>

              {onOpenBudgetRescueModal && (
                <button
                  type="button"
                  onClick={() => onOpenBudgetRescueModal(simulationResult.adaptedPlan)}
                  className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-mono font-bold text-xs uppercase tracking-wider shrink-0 cursor-pointer flex items-center gap-1.5 shadow-md"
                >
                  <Coins className="w-3.5 h-3.5 text-black" />
                  <span>💰 Optimize Budget</span>
                </button>
              )}
            </div>
          )}

        </div>

        {/* Modal Footer with Actions */}
        <div className="p-5 sm:p-6 border-t border-white/10 bg-[#14141A]/95 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          
          <div className="text-[11px] font-mono text-[#A1A1AA] flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Original itinerary remains intact unless applied.</span>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-mono text-xs uppercase tracking-wider cursor-pointer border border-white/10 transition-colors"
            >
              Keep Original Plan
            </button>

            <button
              type="button"
              onClick={handleApply}
              className="flex-1 sm:flex-none px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black font-mono font-bold text-xs uppercase tracking-wider cursor-pointer shadow-lg shadow-amber-400/20 active:scale-98 transition-all flex items-center justify-center gap-1.5"
            >
              <CheckCircle2 className="w-4 h-4 text-black" />
              <span>Apply New Plan</span>
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
