import React from 'react';
import { TripRecoveryModal } from './adaptive/TripRecoveryModal';
import { TripPlan, Attraction, Hotel, FoodItem } from '../types';

export interface TripRecoveryProps {
  isOpen: boolean;
  onClose: () => void;
  currentPlan: TripPlan;
  availableAttractions: Attraction[];
  availableHotels: Hotel[];
  availableFood: FoodItem[];
  onApplyRecovery: (newPlan: TripPlan, disruptionSummary: string) => void;
}

export const TripRecovery: React.FC<TripRecoveryProps> = (props) => {
  return <TripRecoveryModal {...props} />;
};

export default TripRecovery;
