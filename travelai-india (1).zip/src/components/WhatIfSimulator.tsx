import React from 'react';
import { WhatIfSimulatorModal } from './adaptive/WhatIfSimulatorModal';
import { TripPlan, Attraction, Hotel, FoodItem } from '../types';

export interface WhatIfSimulatorProps {
  isOpen: boolean;
  onClose: () => void;
  currentPlan: TripPlan;
  availableAttractions: Attraction[];
  availableHotels: Hotel[];
  availableFood: FoodItem[];
  onApplyPlan: (newPlan: TripPlan, scenarioLabel: string) => void;
  onOpenBudgetRescueModal?: (plan: TripPlan) => void;
}

export const WhatIfSimulator: React.FC<WhatIfSimulatorProps> = (props) => {
  return <WhatIfSimulatorModal {...props} />;
};

export default WhatIfSimulator;
