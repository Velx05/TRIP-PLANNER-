import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { TripPlan, ItineraryDay, DirectionsRoute, Coordinates } from '../types';
import { 
  Route as RouteIcon, 
  Car, 
  Footprints, 
  MapPin, 
  Clock, 
  ArrowRight, 
  Navigation, 
  X, 
  Compass, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle,
  ExternalLink,
  Layers
} from 'lucide-react';
import { GoogleMapRenderer } from './GoogleMapRenderer';

interface ItineraryRouteModalProps {
  isOpen: boolean;
  onClose: () => void;
  plan: TripPlan;
  initialDay?: ItineraryDay | null;
  apiKey?: string;
}

export const ItineraryRouteModal: React.FC<ItineraryRouteModalProps> = ({
  isOpen,
  onClose,
  plan,
  initialDay,
  apiKey = ''
}) => {
  // Leaflet map refs
  const leafletContainerRef = useRef<HTMLDivElement>(null);
  const leafletMapRef = useRef<any>(null);
  const leafletMarkersGroupRef = useRef<any>(null);
  const leafletPolylineRef = useRef<any>(null);

  // Available itinerary places
  const allItineraryPlaces = React.useMemo(() => {
    const list: Array<{ label: string; name: string; type: string; day?: number }> = [];
    
    if (plan.recommendedHotel) {
      list.push({
        label: `Stay: ${plan.recommendedHotel.name}`,
        name: `${plan.recommendedHotel.name}, ${plan.destinationName}`,
        type: 'Hotel'
      });
    }

    plan.days.forEach((d) => {
      if (d.morning?.attractionName) {
        list.push({
          label: `Day ${d.day} Morning: ${d.morning.attractionName}`,
          name: `${d.morning.attractionName}, ${plan.destinationName}`,
          type: 'Attraction',
          day: d.day
        });
      }
      if (d.afternoon?.lunchSpot) {
        list.push({
          label: `Day ${d.day} Lunch: ${d.afternoon.lunchSpot}`,
          name: `${d.afternoon.lunchSpot}, ${plan.destinationName}`,
          type: 'Restaurant',
          day: d.day
        });
      }
      if (d.afternoon?.attractionName) {
        list.push({
          label: `Day ${d.day} Afternoon: ${d.afternoon.attractionName}`,
          name: `${d.afternoon.attractionName}, ${plan.destinationName}`,
          type: 'Attraction',
          day: d.day
        });
      }
      if (d.evening?.attractionOrActivity) {
        list.push({
          label: `Day ${d.day} Evening: ${d.evening.attractionOrActivity}`,
          name: `${d.evening.attractionOrActivity}, ${plan.destinationName}`,
          type: 'Attraction',
          day: d.day
        });
      }
      if (d.evening?.dinnerSpot) {
        list.push({
          label: `Day ${d.day} Dinner: ${d.evening.dinnerSpot}`,
          name: `${d.evening.dinnerSpot}, ${plan.destinationName}`,
          type: 'Restaurant',
          day: d.day
        });
      }
    });

    return list;
  }, [plan]);

  // Selected Origin & Destination from Itinerary
  const [selectedOriginName, setSelectedOriginName] = useState<string>('');
  const [selectedDestName, setSelectedDestName] = useState<string>('');
  const [travelMode, setTravelMode] = useState<'DRIVE' | 'WALK'>('DRIVE');

  // Route State
  const [route, setRoute] = useState<DirectionsRoute | null>(null);
  const [loadingRoute, setLoadingRoute] = useState<boolean>(false);
  const [routeError, setRouteError] = useState<string | null>(null);
  const [mapEngine, setMapEngine] = useState<'google' | 'vector'>('vector');

  // Initialize selected places when modal opens or initialDay changes
  useEffect(() => {
    if (!isOpen) return;

    if (initialDay) {
      const morning = initialDay.morning?.attractionName 
        ? `${initialDay.morning.attractionName}, ${plan.destinationName}`
        : '';
      const afternoon = initialDay.afternoon?.attractionName 
        ? `${initialDay.afternoon.attractionName}, ${plan.destinationName}`
        : initialDay.evening?.attractionOrActivity 
        ? `${initialDay.evening.attractionOrActivity}, ${plan.destinationName}`
        : '';

      setSelectedOriginName(morning || (allItineraryPlaces[0]?.name || ''));
      setSelectedDestName(afternoon || (allItineraryPlaces[1]?.name || ''));
    } else {
      setSelectedOriginName(allItineraryPlaces[0]?.name || '');
      setSelectedDestName(allItineraryPlaces[1]?.name || '');
    }

    if (apiKey && apiKey.startsWith('AIza')) {
      setMapEngine('google');
    } else {
      setMapEngine('vector');
    }
  }, [isOpen, initialDay, allItineraryPlaces, plan.destinationName, apiKey]);

  // Calculate Route function
  const calculateRoute = async (
    orig: string = selectedOriginName,
    dest: string = selectedDestName,
    mode: 'DRIVE' | 'WALK' = travelMode
  ) => {
    if (!orig || !dest || orig === dest) {
      setRouteError('Please select two distinct places from your itinerary.');
      return;
    }

    setLoadingRoute(true);
    setRouteError(null);

    try {
      const res = await fetch('/api/maps/directions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          origin: orig,
          destination: dest,
          originName: orig,
          destinationName: dest,
          mode: mode === 'WALK' ? 'WALK' : 'DRIVE'
        })
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || 'Failed to calculate directions between sights.');
      }

      const routeData: DirectionsRoute = await res.json();
      setRoute(routeData);

      // Render Leaflet route if vector engine
      if (mapEngine === 'vector' && leafletMapRef.current && routeData.polylinePoints.length > 0) {
        renderLeafletRoute(routeData);
      }
    } catch (err: any) {
      console.error('Route calculation error:', err);
      setRouteError(err.message || 'Route calculation failed. Please try another place pair.');
    } finally {
      setLoadingRoute(false);
    }
  };

  // Auto-calculate on initial open
  useEffect(() => {
    if (isOpen && selectedOriginName && selectedDestName && selectedOriginName !== selectedDestName) {
      calculateRoute(selectedOriginName, selectedDestName, travelMode);
    }
  }, [isOpen, selectedOriginName, selectedDestName]);

  // Leaflet initialization and polyline rendering
  const renderLeafletRoute = (routeData: DirectionsRoute) => {
    const map = leafletMapRef.current;
    if (!map) return;

    // Clear old polyline & markers
    if (leafletPolylineRef.current) {
      leafletPolylineRef.current.remove();
      leafletPolylineRef.current = null;
    }
    if (leafletMarkersGroupRef.current) {
      leafletMarkersGroupRef.current.clearLayers();
    }

    import('leaflet').then((L) => {
      const group = leafletMarkersGroupRef.current || L.layerGroup().addTo(map);
      leafletMarkersGroupRef.current = group;

      // Draw polyline
      const latLngs: [number, number][] = routeData.polylinePoints.map(p => [p.lat, p.lng]);
      const polyline = L.polyline(latLngs, {
        color: '#F59E0B',
        weight: 5,
        opacity: 0.9,
        dashArray: travelMode === 'WALK' ? '8, 8' : undefined
      }).addTo(map);
      leafletPolylineRef.current = polyline;

      // Origin Pin (Green)
      const originIcon = L.divIcon({
        className: 'custom-origin-icon',
        html: `<div style="background: #10B981; color: white; border: 2px solid white; border-radius: 50%; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 13px; box-shadow: 0 4px 10px rgba(0,0,0,0.5);">A</div>`,
        iconSize: [28, 28],
        iconAnchor: [14, 14]
      });
      const originMarker = L.marker([routeData.originCoords.lat, routeData.originCoords.lng], { icon: originIcon })
        .bindPopup(`<strong>START:</strong> ${routeData.originName}`);
      group.addLayer(originMarker);

      // Destination Pin (Amber)
      const destIcon = L.divIcon({
        className: 'custom-dest-icon',
        html: `<div style="background: #F59E0B; color: black; border: 2px solid white; border-radius: 50%; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 13px; box-shadow: 0 4px 10px rgba(0,0,0,0.5);">B</div>`,
        iconSize: [28, 28],
        iconAnchor: [14, 14]
      });
      const destMarker = L.marker([routeData.destinationCoords.lat, routeData.destinationCoords.lng], { icon: destIcon })
        .bindPopup(`<strong>END:</strong> ${routeData.destinationName}`);
      group.addLayer(destMarker);

      // Fit bounds
      map.fitBounds(polyline.getBounds(), { padding: [40, 40] });
    });
  };

  // Initialize Leaflet map
  useEffect(() => {
    if (!isOpen || mapEngine !== 'vector') return;

    let isMounted = true;
    import('leaflet').then((L) => {
      if (!isMounted || !leafletContainerRef.current) return;

      if (!leafletMapRef.current) {
        const centerLat = plan.recommendedHotel?.latitude || 26.9124;
        const centerLng = plan.recommendedHotel?.longitude || 75.7873;

        const map = L.map(leafletContainerRef.current, {
          center: [centerLat, centerLng],
          zoom: 13,
          attributionControl: false
        });

        L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
          maxZoom: 19
        }).addTo(map);

        const markersGroup = L.layerGroup().addTo(map);
        leafletMapRef.current = map;
        leafletMarkersGroupRef.current = markersGroup;

        setTimeout(() => {
          if (map) map.invalidateSize();
        }, 200);
      }
    });

    return () => {
      isMounted = false;
      if (leafletMapRef.current) {
        leafletMapRef.current.remove();
        leafletMapRef.current = null;
      }
    };
  }, [isOpen, mapEngine, plan]);

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto bg-black/80 backdrop-blur-md">
        
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ duration: 0.25 }}
          className="relative w-full max-w-5xl bg-[#0D0D12] border border-white/15 rounded-3xl shadow-2xl overflow-hidden my-auto text-white flex flex-col max-h-[92vh]"
        >
          {/* Header */}
          <div className="p-5 sm:p-6 border-b border-white/10 flex items-center justify-between bg-gradient-to-r from-[#14141E] via-[#0E0E14] to-[#12121A]">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-amber-400 font-mono text-xs uppercase tracking-widest font-bold">
                <RouteIcon className="w-4 h-4 text-amber-400" />
                <span>ITINERARY ROUTE & NAVIGATION</span>
                <span className="text-white/30">•</span>
                <span className="text-emerald-400 text-[11px]">Real-Time Roads</span>
              </div>
              <h2 className="font-cinzel text-xl sm:text-2xl font-bold text-white uppercase tracking-tight">
                Route Between Itinerary Places
              </h2>
              <p className="text-xs text-[#A1A1AA] font-light">
                Calculate turn-by-turn driving or walking directions between any two sights on your {plan.destinationName} expedition.
              </p>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-[#A1A1AA] hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Controls Bar: Select Places & Mode */}
          <div className="p-4 sm:p-6 border-b border-white/10 bg-[#121218] space-y-4">
            
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
              
              {/* Origin Selector */}
              <div className="sm:col-span-5 space-y-1.5">
                <label className="text-[10px] font-mono uppercase tracking-wider text-emerald-400 font-bold flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  <span>Starting Sight / Hotel:</span>
                </label>
                <select
                  value={selectedOriginName}
                  onChange={(e) => setSelectedOriginName(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-[#09090D] border border-white/15 text-xs font-mono text-white focus:outline-none focus:border-amber-400 cursor-pointer"
                >
                  {allItineraryPlaces.map((p, idx) => (
                    <option key={`orig-${idx}`} value={p.name}>
                      {p.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* Arrow Indicator */}
              <div className="hidden sm:flex sm:col-span-1 items-center justify-center pb-2 text-amber-400">
                <ArrowRight className="w-5 h-5" />
              </div>

              {/* Destination Selector */}
              <div className="sm:col-span-5 space-y-1.5">
                <label className="text-[10px] font-mono uppercase tracking-wider text-amber-400 font-bold flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-400" />
                  <span>Target Destination / Sight:</span>
                </label>
                <select
                  value={selectedDestName}
                  onChange={(e) => setSelectedDestName(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-[#09090D] border border-white/15 text-xs font-mono text-white focus:outline-none focus:border-amber-400 cursor-pointer"
                >
                  {allItineraryPlaces.map((p, idx) => (
                    <option key={`dest-${idx}`} value={p.name}>
                      {p.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* Recalculate CTA */}
              <div className="sm:col-span-1 flex items-end">
                <button
                  type="button"
                  onClick={() => calculateRoute(selectedOriginName, selectedDestName, travelMode)}
                  disabled={loadingRoute}
                  className="w-full py-2.5 px-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-bold text-xs font-mono uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center disabled:opacity-50"
                  title="Recalculate route"
                >
                  {loadingRoute ? '...' : 'Go'}
                </button>
              </div>

            </div>

            {/* Travel Mode Selector: Driving vs Walking */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-white/5">
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-mono text-[#A1A1AA] uppercase">Travel Mode:</span>
                
                <button
                  type="button"
                  onClick={() => {
                    setTravelMode('DRIVE');
                    calculateRoute(selectedOriginName, selectedDestName, 'DRIVE');
                  }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-mono uppercase font-bold transition-all cursor-pointer ${
                    travelMode === 'DRIVE'
                      ? 'bg-amber-400 text-black shadow-md'
                      : 'bg-white/5 text-[#A1A1AA] hover:text-white border border-white/10'
                  }`}
                >
                  <Car className="w-3.5 h-3.5" />
                  <span>🚗 Driving</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setTravelMode('WALK');
                    calculateRoute(selectedOriginName, selectedDestName, 'WALK');
                  }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-mono uppercase font-bold transition-all cursor-pointer ${
                    travelMode === 'WALK'
                      ? 'bg-amber-400 text-black shadow-md'
                      : 'bg-white/5 text-[#A1A1AA] hover:text-white border border-white/10'
                  }`}
                >
                  <Footprints className="w-3.5 h-3.5" />
                  <span>🚶 Walking</span>
                </button>
              </div>

              {/* Metrics Badge if route is calculated */}
              {route && (
                <div className="flex items-center gap-3 font-mono text-xs text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-3 py-1 rounded-xl">
                  <span><strong>{route.distanceText}</strong> distance</span>
                  <span>•</span>
                  <span><strong>{route.durationText}</strong> travel time</span>
                </div>
              )}
            </div>

            {routeError && (
              <div className="p-3 rounded-xl bg-red-500/15 border border-red-500/30 text-xs font-mono text-red-300 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{routeError}</span>
              </div>
            )}

          </div>

          {/* Interactive Map & Route Summary Body */}
          <div className="flex-1 min-h-[380px] sm:min-h-[460px] relative overflow-hidden bg-[#0A0A0E] grid grid-cols-1 lg:grid-cols-12">
            
            {/* Map Canvas (8 cols on desktop) */}
            <div className="lg:col-span-8 h-[340px] sm:h-[440px] lg:h-full relative">
              {mapEngine === 'google' && apiKey && apiKey.startsWith('AIza') ? (
                <GoogleMapRenderer
                  apiKey={apiKey}
                  destinations={[]}
                  mapData={{ hotels: [], attractions: [], food: [] }}
                  filterType="all"
                  selectedDestinationId="all"
                  activeRoute={route}
                  searchedPlaces={[]}
                  geocodedLocation={null}
                  destinationName={selectedDestName}
                  onSelectItem={() => {}}
                  onSwitchToVector={() => setMapEngine('vector')}
                />
              ) : (
                <div ref={leafletContainerRef} className="w-full h-full" />
              )}

              {/* Floating Map Status Overlay */}
              <div className="absolute top-3 left-3 z-[400] bg-black/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/15 text-[11px] font-mono text-[#D4D4D8] flex items-center gap-1.5 shadow-lg">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>{route ? `Route Active (${route.distanceText})` : 'Calculating route...'}</span>
              </div>
            </div>

            {/* Turn-by-Turn Steps Sidebar (4 cols on desktop) */}
            <div className="lg:col-span-4 p-4 sm:p-5 border-t lg:border-t-0 lg:border-l border-white/10 bg-[#0E0E14] overflow-y-auto max-h-[320px] lg:max-h-full space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                  <Navigation className="w-3.5 h-3.5 text-amber-400" />
                  <span>STEP-BY-STEP DIRECTIONS</span>
                </span>
                <span className="text-[10px] text-[#A1A1AA]">
                  {route?.steps.length || 0} Turns
                </span>
              </div>

              {route && route.steps && route.steps.length > 0 ? (
                <div className="space-y-2">
                  {route.steps.map((st, i) => (
                    <div key={i} className="p-2.5 rounded-xl bg-white/5 border border-white/5 space-y-1">
                      <div className="flex items-center justify-between text-[10px] text-[#A1A1AA]">
                        <span className="text-amber-300 font-bold">Step 0{i + 1}</span>
                        <span>{st.distanceKm} km • {st.durationMins}m</span>
                      </div>
                      <p className="text-white text-xs font-sans leading-relaxed">
                        {st.instruction}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-12 text-center text-[#71717A] space-y-2">
                  <Compass className="w-8 h-8 mx-auto text-[#71717A] animate-pulse" />
                  <p className="text-xs">Select two places above to view road instructions.</p>
                </div>
              )}

              {/* Direct external navigation backup link */}
              {selectedOriginName && selectedDestName && (
                <div className="pt-3 border-t border-white/10">
                  <a
                    href={`https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(selectedOriginName)}&destination=${encodeURIComponent(selectedDestName)}&travelmode=${travelMode === 'WALK' ? 'walking' : 'driving'}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-amber-300 hover:text-amber-200 text-xs font-mono flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <span>Open in Google Maps App</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              )}
            </div>

          </div>

        </motion.div>

      </div>
    </AnimatePresence>
  );
};
