import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Attraction } from '../types';
import { 
  MapPin, 
  Navigation, 
  Clock, 
  Sun, 
  Search, 
  ExternalLink, 
  ShieldCheck, 
  Landmark, 
  Layers, 
  Map as MapIcon, 
  Star, 
  X,
  Compass,
  Tag,
  CheckCircle2,
  Calendar,
  Sparkles
} from 'lucide-react';

interface DestinationAttractionsTabProps {
  destinationId: string;
  destinationName: string;
  attractions: Attraction[];
  destinationCoordinates?: { lat: number; lng: number };
}

export const DestinationAttractionsTab: React.FC<DestinationAttractionsTabProps> = ({
  destinationId,
  destinationName,
  attractions,
  destinationCoordinates
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'rating' | 'priceAsc' | 'priceDesc' | 'duration'>('rating');
  const [viewMode, setViewMode] = useState<'cards' | 'map'>('cards');
  const [selectedAttraction, setSelectedAttraction] = useState<Attraction | null>(null);

  // Map refs
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const markersGroupRef = useRef<any>(null);

  // Derive categories from attractions
  const categories = useMemo(() => {
    const cats = new Set<string>();
    attractions.forEach(a => {
      if (a.category) cats.add(a.category);
    });
    return Array.from(cats);
  }, [attractions]);

  // Filter and sort attractions
  const filteredAttractions = useMemo(() => {
    return attractions
      .filter(item => {
        // Search filter
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matchName = item.name.toLowerCase().includes(q);
          const matchDesc = item.description?.toLowerCase().includes(q);
          const matchCat = item.category?.toLowerCase().includes(q);
          const matchAddr = item.address?.toLowerCase().includes(q);
          if (!matchName && !matchDesc && !matchCat && !matchAddr) return false;
        }

        // Category filter
        if (selectedCategory === 'free') {
          return item.entryFeeINR === 0;
        }
        if (selectedCategory !== 'all') {
          return item.category?.toLowerCase() === selectedCategory.toLowerCase();
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'priceAsc') {
          return (a.entryFeeINR ?? 0) - (b.entryFeeINR ?? 0);
        }
        if (sortBy === 'priceDesc') {
          return (b.entryFeeINR ?? 0) - (a.entryFeeINR ?? 0);
        }
        if (sortBy === 'duration') {
          return (b.estimatedVisitDurationHours ?? 2) - (a.estimatedVisitDurationHours ?? 2);
        }
        // default: rating / reviewCount
        return (b.rating ?? 4.5) - (a.rating ?? 4.5);
      });
  }, [attractions, searchQuery, selectedCategory, sortBy]);

  // Leaflet map initialization
  useEffect(() => {
    let isMounted = true;

    async function initMap() {
      if (!mapContainerRef.current) return;
      const L = await import('leaflet');
      if (!isMounted) return;

      const defaultCenter = destinationCoordinates || 
        (attractions[0]?.latitude && attractions[0]?.longitude
          ? { lat: attractions[0].latitude, lng: attractions[0].longitude }
          : { lat: 24.5854, lng: 73.7125 });

      if (!mapInstanceRef.current) {
        const map = L.map(mapContainerRef.current, {
          center: [defaultCenter.lat, defaultCenter.lng],
          zoom: 13,
          zoomControl: true,
        });

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          maxZoom: 19,
          attribution: '&copy; OpenStreetMap | Verified Tourist Attractions',
        }).addTo(map);

        const markersGroup = L.layerGroup().addTo(map);
        mapInstanceRef.current = map;
        markersGroupRef.current = markersGroup;
      }

      // Populate markers
      if (markersGroupRef.current && mapInstanceRef.current) {
        markersGroupRef.current.clearLayers();

        const bounds = L.latLngBounds([]);

        filteredAttractions.forEach((attraction, idx) => {
          const lat = attraction.latitude || attraction.coordinates?.lat;
          const lng = attraction.longitude || attraction.coordinates?.lng;

          if (lat && lng) {
            bounds.extend([lat, lng]);

            const isSelected = selectedAttraction?.id === attraction.id;
            const markerBg = isSelected ? '#EF4444' : '#F59E0B';

            const customIcon = L.divIcon({
              className: 'custom-attraction-pin',
              html: `
                <div style="background-color: ${markerBg}; color: #000; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 11px; border: 2px solid #FFFFFF; box-shadow: 0 4px 10px rgba(0,0,0,0.5); cursor: pointer;">
                  ${idx + 1}
                </div>
              `,
              iconSize: [28, 28],
              iconAnchor: [14, 14],
              popupAnchor: [0, -14],
            });

            const feeLabel = attraction.entryFeeINR === 0 ? 'Free Entry' : `₹${attraction.entryFeeINR}`;
            const marker = L.marker([lat, lng], { icon: customIcon });

            marker.bindPopup(`
              <div style="font-family: system-ui, -apple-system, sans-serif; color: #111; max-width: 240px; font-size: 12px; line-height: 1.4;">
                <div style="font-weight: 700; margin-bottom: 3px; font-size: 13px; color: #09090B;">${attraction.name}</div>
                <div style="color: #6B7280; font-size: 11px; margin-bottom: 6px;">${attraction.category}</div>
                <div style="background: #F3F4F6; padding: 6px 8px; border-radius: 6px; margin-bottom: 8px;">
                  <div style="font-size: 11px; color: #374151;"><strong>Timing:</strong> ${attraction.openingHours || 'Daily'}</div>
                  <div style="font-size: 11px; color: #059669; font-weight: bold; margin-top: 2px;"><strong>Ticket Price:</strong> ${feeLabel}</div>
                  <div style="font-size: 10px; color: #4B5563; margin-top: 2px;"><strong>Best Time:</strong> ${attraction.bestTimeToVisitTimeOfDay || 'Morning / Golden Hour'}</div>
                </div>
                <a href="https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(attraction.name + ', ' + (attraction.address || (destinationName + ', India')))}" target="_blank" rel="noopener noreferrer" style="display: block; text-align: center; background: #000000; color: #F59E0B; padding: 6px 10px; border-radius: 6px; text-decoration: none; font-weight: 700; font-size: 11px; border: 1px solid #F59E0B;">
                  Get Directions in Google Maps ↗
                </a>
              </div>
            `);

            marker.on('click', () => {
              setSelectedAttraction(attraction);
            });

            markersGroupRef.current.addLayer(marker);
          }
        });

        if (bounds.isValid() && filteredAttractions.length > 0) {
          mapInstanceRef.current.fitBounds(bounds, { padding: [40, 40], maxZoom: 15 });
        }
      }
    }

    if (viewMode === 'map') {
      setTimeout(() => {
        initMap();
        if (mapInstanceRef.current) {
          mapInstanceRef.current.invalidateSize();
        }
      }, 150);
    }

    return () => {
      isMounted = false;
    };
  }, [viewMode, filteredAttractions, destinationCoordinates, selectedAttraction]);

  // Center on attraction when requested
  const handleFocusOnMap = (attraction: Attraction) => {
    setSelectedAttraction(attraction);
    setViewMode('map');
    const lat = attraction.latitude || attraction.coordinates?.lat;
    const lng = attraction.longitude || attraction.coordinates?.lng;
    if (lat && lng && mapInstanceRef.current) {
      mapInstanceRef.current.setView([lat, lng], 15);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* 1. Header & Controls Card */}
      <div className="p-6 sm:p-8 rounded-3xl bg-[#0D0D11] border border-white/10 space-y-6">
        
        {/* Title & View Switcher */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
          <div className="space-y-1">
            <span className="text-xs font-mono text-amber-400 uppercase tracking-widest flex items-center gap-2">
              <Landmark className="w-3.5 h-3.5 text-amber-400" />
              AUTHENTIC SIGHTS & MONUMENTS IN {destinationName.toUpperCase()}
            </span>
            <h3 className="font-cinzel text-xl sm:text-2xl font-bold text-white uppercase tracking-wide">
              PLACES TO VISIT ({attractions.length})
            </h3>
            <p className="text-xs text-[#A1A1AA] max-w-2xl leading-relaxed">
              Verified heritage monuments, scenic viewpoints, and sacred temples. Complete with exact ticket prices in INR, official opening hours, optimal visit windows, and direct turn-by-turn map directions.
            </p>
          </div>

          {/* View Mode Toggle: Cards vs Interactive Map */}
          <div className="flex items-center gap-2 bg-[#14141A] p-1.5 rounded-2xl border border-white/10">
            <button
              onClick={() => setViewMode('cards')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-mono font-medium uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
                viewMode === 'cards'
                  ? 'bg-amber-400 text-black font-bold shadow-md'
                  : 'text-[#A1A1AA] hover:text-white'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Cards Grid</span>
            </button>
            <button
              onClick={() => setViewMode('map')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-mono font-medium uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
                viewMode === 'map'
                  ? 'bg-amber-400 text-black font-bold shadow-md'
                  : 'text-[#A1A1AA] hover:text-white'
              }`}
            >
              <MapIcon className="w-3.5 h-3.5" />
              <span>Interactive Map</span>
            </button>
          </div>
        </div>

        {/* Filter Controls Bar */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          
          {/* Search Input */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search place name, monument, temple, lake..."
              className="w-full pl-9 pr-8 py-2.5 bg-[#14141A] border border-white/10 rounded-xl text-xs font-mono text-white placeholder-zinc-500 focus:outline-none focus:border-amber-400"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white text-xs font-mono cursor-pointer"
              >
                ✕
              </button>
            )}
          </div>

          {/* Sort By Dropdown */}
          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="text-[#A1A1AA] shrink-0">SORT BY:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="px-3 py-2 bg-[#14141A] border border-white/10 rounded-xl text-xs font-mono text-white focus:outline-none focus:border-amber-400 cursor-pointer"
            >
              <option value="rating">Top Rated & Popularity</option>
              <option value="priceAsc">Price: Free / Lowest to Highest</option>
              <option value="priceDesc">Price: Highest to Lowest</option>
              <option value="duration">Visit Duration</option>
            </select>
          </div>

        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-white/5">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1.5 rounded-full text-xs font-mono uppercase transition-all cursor-pointer ${
              selectedCategory === 'all'
                ? 'bg-amber-400 text-black font-bold shadow-md'
                : 'bg-[#14141A] text-[#A1A1AA] hover:text-white border border-white/10'
            }`}
          >
            All Places ({attractions.length})
          </button>

          <button
            onClick={() => setSelectedCategory('free')}
            className={`px-3 py-1.5 rounded-full text-xs font-mono uppercase transition-all cursor-pointer ${
              selectedCategory === 'free'
                ? 'bg-emerald-500 text-black font-bold shadow-md'
                : 'bg-[#14141A] text-emerald-400 hover:text-white border border-emerald-500/20'
            }`}
          >
            🎟️ Free Entry ({attractions.filter(a => a.entryFeeINR === 0).length})
          </button>

          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-full text-xs font-mono uppercase transition-all cursor-pointer ${
                selectedCategory.toLowerCase() === cat.toLowerCase()
                  ? 'bg-amber-400 text-black font-bold shadow-md'
                  : 'bg-[#14141A] text-[#A1A1AA] hover:text-white border border-white/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

      </div>

      {/* 2. Interactive Map View */}
      {viewMode === 'map' && (
        <div className="p-4 sm:p-6 rounded-3xl bg-[#0D0D11] border border-white/10 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono text-[#A1A1AA]">
            <span className="flex items-center gap-2 text-amber-300 font-bold">
              <Compass className="w-4 h-4 text-amber-400" />
              <span>Interactive Map: Click any marker to view entry fee, timings, and directions</span>
            </span>
            <span>Showing {filteredAttractions.length} pins for {destinationName}</span>
          </div>

          <div className="relative w-full h-[550px] rounded-2xl overflow-hidden border border-white/10 shadow-2xl bg-[#14141A]">
            <div ref={mapContainerRef} className="w-full h-full z-0" />
          </div>
        </div>
      )}

      {/* 3. Cards Grid View */}
      {filteredAttractions.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-4 gap-6">
          {filteredAttractions.map((attraction, idx) => {
            const lat = attraction.latitude || attraction.coordinates?.lat;
            const lng = attraction.longitude || attraction.coordinates?.lng;
            const isFree = attraction.entryFeeINR === 0;

            return (
              <div
                key={attraction.id || attraction.name}
                className="rounded-3xl overflow-hidden bg-[#0D0D11] border border-white/10 hover:border-amber-400/40 transition-all duration-300 flex flex-col justify-between group shadow-xl hover:shadow-2xl"
              >
                <div>
                  
                  {/* Photo & Overlays */}
                  <div className="relative h-52 sm:h-56 w-full overflow-hidden bg-[#14141A]">
                    <img
                      src={attraction.imageUrl || 'https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=800&q=80'}
                      alt={attraction.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D11] via-black/25 to-black/60" />

                    {/* Top Badges */}
                    <div className="absolute top-3 left-3 right-3 flex items-center justify-between gap-2">
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-mono uppercase bg-black/80 backdrop-blur-md border border-white/20 text-amber-300 font-bold">
                        {attraction.category || 'Sight'}
                      </span>

                      <span className="px-2.5 py-1 rounded-full text-[10px] font-mono bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 uppercase font-bold backdrop-blur-md flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                        <span>Verified Sight</span>
                      </span>
                    </div>

                    {/* Bottom Pin Badge on Photo */}
                    <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
                      <span className="w-6 h-6 rounded-full bg-amber-400 text-black font-mono font-bold text-xs flex items-center justify-center shadow-md">
                        {idx + 1}
                      </span>
                      {lat && lng && (
                        <span className="px-2 py-0.5 rounded-md bg-black/75 backdrop-blur-md border border-white/10 text-[10px] font-mono text-zinc-300">
                          {lat.toFixed(3)}°N, {lng.toFixed(3)}°E
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-5 sm:p-6 space-y-4">
                    
                    {/* Title & Rating */}
                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <h4 
                          onClick={() => setSelectedAttraction(attraction)}
                          className="font-cinzel text-lg sm:text-xl font-bold text-white group-hover:text-amber-400 transition-colors cursor-pointer line-clamp-1"
                        >
                          {attraction.name}
                        </h4>
                      </div>

                      <div className="flex items-center gap-2 text-xs font-mono">
                        <div className="flex items-center text-amber-400 font-bold">
                          <Star className="w-3.5 h-3.5 fill-amber-400 mr-1" />
                          <span>{attraction.rating || 4.7}</span>
                        </div>
                        <span className="text-zinc-500">•</span>
                        <span className="text-zinc-400">({attraction.reviewCount ? `${attraction.reviewCount.toLocaleString()} reviews` : 'Verified ASI Record'})</span>
                      </div>
                    </div>

                    {/* Description */}
                    <p className="text-xs text-[#A1A1AA] line-clamp-2 leading-relaxed">
                      {attraction.description}
                    </p>

                    {/* Detailed Specifications Box: Prices, Timing, Address */}
                    <div className="p-3.5 rounded-2xl bg-[#14141A] border border-white/5 space-y-2 text-xs font-mono">
                      
                      {/* Price / Entry Fee */}
                      <div className="flex items-center justify-between">
                        <span className="text-zinc-400 flex items-center gap-1.5">
                          <Tag className="w-3.5 h-3.5 text-amber-400" />
                          <span>Entry Ticket:</span>
                        </span>
                        <span className={`font-bold ${isFree ? 'text-emerald-400' : 'text-amber-400'}`}>
                          {isFree ? 'FREE ENTRY (₹0)' : `₹${attraction.entryFeeINR} / person`}
                        </span>
                      </div>

                      {attraction.entryFeeForeignerINR !== undefined && attraction.entryFeeForeignerINR > 0 && (
                        <div className="flex items-center justify-between text-[11px] text-zinc-400">
                          <span>Foreigner Ticket:</span>
                          <span className="text-zinc-200">₹{attraction.entryFeeForeignerINR}</span>
                        </div>
                      )}

                      {/* Opening Hours */}
                      <div className="flex items-start justify-between gap-2 pt-1 border-t border-white/5">
                        <span className="text-zinc-400 flex items-center gap-1.5 shrink-0">
                          <Clock className="w-3.5 h-3.5 text-amber-400" />
                          <span>Timings:</span>
                        </span>
                        <span className="text-white text-right font-medium">
                          {attraction.openingHours || '09:00 AM - 05:30 PM (Daily)'}
                        </span>
                      </div>

                      {/* Best Time to Visit */}
                      {attraction.bestTimeToVisitTimeOfDay && (
                        <div className="flex items-center justify-between gap-2 text-[11px]">
                          <span className="text-zinc-400 flex items-center gap-1.5 shrink-0">
                            <Sun className="w-3.5 h-3.5 text-amber-400" />
                            <span>Optimal Visit:</span>
                          </span>
                          <span className="text-amber-300/90 truncate text-right">
                            {attraction.bestTimeToVisitTimeOfDay}
                          </span>
                        </div>
                      )}

                      {/* Duration */}
                      <div className="flex items-center justify-between gap-2 text-[11px] text-zinc-400 pt-1 border-t border-white/5">
                        <span>Duration:</span>
                        <span className="text-zinc-200 font-medium">
                          {attraction.estimatedVisitDurationHours ? `${attraction.estimatedVisitDurationHours} Hours` : '1.5 - 2 Hours'}
                        </span>
                      </div>

                      {/* Address */}
                      {attraction.address && (
                        <div className="flex items-start gap-1.5 text-[10px] text-zinc-400 pt-1 border-t border-white/5">
                          <MapPin className="w-3 h-3 text-amber-400 shrink-0 mt-0.5" />
                          <span className="line-clamp-1">{attraction.address}</span>
                        </div>
                      )}

                    </div>

                  </div>
                </div>

                {/* Card Action Buttons: [ View on Map ] [ Get Directions ↗ ] */}
                <div className="p-5 pt-0 space-y-2 border-t border-white/5 mt-2">
                  <div className="flex items-center gap-2 pt-3">
                    
                    {/* Focus on Map */}
                    <button
                      type="button"
                      onClick={() => handleFocusOnMap(attraction)}
                      className="flex-1 py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-mono uppercase tracking-wider transition-colors cursor-pointer flex items-center justify-center gap-1.5 border border-white/10"
                    >
                      <MapPin className="w-3.5 h-3.5 text-amber-400" />
                      <span>Map View</span>
                    </button>

                    {/* Google Maps Directions Button */}
                    <a
                      href={`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(attraction.name + ', ' + (attraction.address || (destinationName + ', India')))}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black text-xs font-mono font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-lg shadow-amber-400/20 active:scale-98"
                      title={`Get turn-by-turn map directions to ${attraction.name}`}
                    >
                      <Navigation className="w-3.5 h-3.5 text-black" />
                      <span>Directions ↗</span>
                    </a>

                  </div>

                  {/* Authority Source Line */}
                  <div className="flex items-center justify-between text-[10px] font-mono text-[#71717A] pt-1">
                    <span className="flex items-center gap-1 truncate text-emerald-400/90">
                      <ShieldCheck className="w-3 h-3 text-emerald-400 shrink-0" />
                      <span className="truncate">{attraction.source || 'Incredible India'}</span>
                    </span>
                    {attraction.officialWebsite && (
                      <a
                        href={attraction.officialWebsite}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-amber-400 hover:underline flex items-center gap-1 shrink-0"
                      >
                        <span>Official Portal</span>
                        <ExternalLink className="w-2.5 h-2.5" />
                      </a>
                    )}
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      ) : (
        <div className="p-12 rounded-3xl bg-[#0D0D11] border border-white/10 text-center space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 text-zinc-400 flex items-center justify-center mx-auto">
            <Landmark className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <h4 className="font-cinzel text-lg font-bold text-white">No places match your search</h4>
            <p className="text-xs text-[#A1A1AA] font-mono">
              Try clearing your filter or search query to see all verified sights in {destinationName}.
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('all');
            }}
            className="px-5 py-2.5 rounded-xl bg-amber-400 text-black font-mono font-bold text-xs uppercase cursor-pointer"
          >
            Show All Places
          </button>
        </div>
      )}

      {/* 4. Selected Attraction Inspection Modal */}
      {selectedAttraction && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-[#0D0D11] border border-white/20 rounded-3xl shadow-2xl overflow-hidden my-auto text-white flex flex-col max-h-[90vh]">
            
            {/* Modal Image Header */}
            <div className="relative h-64 sm:h-72 w-full overflow-hidden bg-black shrink-0">
              <img
                src={selectedAttraction.imageUrl || 'https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=1200&q=80'}
                alt={selectedAttraction.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D11] via-transparent to-black/60" />

              <button
                onClick={() => setSelectedAttraction(null)}
                className="absolute top-4 right-4 p-2 rounded-full bg-black/60 hover:bg-black text-white cursor-pointer transition-colors border border-white/20"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="absolute bottom-4 left-6 right-6">
                <span className="px-2.5 py-1 rounded-md text-[10px] font-mono uppercase bg-amber-400 text-black font-bold mb-2 inline-block">
                  {selectedAttraction.category}
                </span>
                <h3 className="font-cinzel text-2xl font-bold text-white leading-tight">
                  {selectedAttraction.name}
                </h3>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-6 overflow-y-auto">
              
              {/* Description */}
              <div className="space-y-1">
                <span className="text-xs font-mono text-zinc-400 uppercase tracking-wider block">Overview & Heritage</span>
                <p className="text-xs sm:text-sm text-[#D4D4D8] leading-relaxed font-light">
                  {selectedAttraction.description}
                </p>
              </div>

              {/* Exact Prices & Timing Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-mono text-xs">
                
                <div className="p-4 rounded-2xl bg-[#14141A] border border-white/10 space-y-2">
                  <span className="text-[11px] text-amber-400 uppercase font-bold flex items-center gap-1.5">
                    <Tag className="w-4 h-4" /> Entry Ticket & Prices
                  </span>
                  <div className="text-white font-bold text-sm">
                    {selectedAttraction.entryFeeINR === 0 ? 'FREE ENTRY (₹0)' : `₹${selectedAttraction.entryFeeINR} (Indian Citizen)`}
                  </div>
                  {selectedAttraction.entryFeeForeignerINR !== undefined && (
                    <div className="text-zinc-400 text-[11px]">
                      Foreign National: ₹{selectedAttraction.entryFeeForeignerINR}
                    </div>
                  )}
                  <div className="text-[10px] text-zinc-500">
                    Official ticket counters open 15 mins before gate entry.
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-[#14141A] border border-white/10 space-y-2">
                  <span className="text-[11px] text-amber-400 uppercase font-bold flex items-center gap-1.5">
                    <Clock className="w-4 h-4" /> Operating Timings
                  </span>
                  <div className="text-white font-bold text-sm">
                    {selectedAttraction.openingHours || '09:00 AM - 05:30 PM (Daily)'}
                  </div>
                  <div className="text-amber-300 text-[11px]">
                    Best Time: {selectedAttraction.bestTimeToVisitTimeOfDay || 'Morning (09:30 AM - 12:00 PM)'}
                  </div>
                  <div className="text-[10px] text-zinc-500">
                    Suggested visit: {selectedAttraction.estimatedVisitDurationHours || 2} hours.
                  </div>
                </div>

              </div>

              {/* Location & Navigation Section */}
              <div className="p-4 rounded-2xl bg-[#14141A] border border-white/10 space-y-3 font-mono text-xs">
                <span className="text-[11px] text-amber-400 uppercase font-bold flex items-center gap-1.5">
                  <Compass className="w-4 h-4" /> Location & Navigation
                </span>
                <p className="text-zinc-300 text-xs">
                  {selectedAttraction.address || `${destinationName}, India`}
                </p>
                {selectedAttraction.latitude && selectedAttraction.longitude && (
                  <p className="text-zinc-500 text-[11px]">
                    Exact GPS Coordinates: {selectedAttraction.latitude}° N, {selectedAttraction.longitude}° E
                  </p>
                )}
              </div>

            </div>

            {/* Modal Footer CTA */}
            <div className="p-4 sm:p-6 bg-[#09090C] border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
              <button
                type="button"
                onClick={() => setSelectedAttraction(null)}
                className="w-full sm:w-auto px-5 py-3 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-mono uppercase tracking-wider cursor-pointer"
              >
                Close
              </button>

              <a
                href={`https://www.google.com/maps/dir/?api=1&destination=${selectedAttraction.latitude || selectedAttraction.coordinates?.lat},${selectedAttraction.longitude || selectedAttraction.coordinates?.lng}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:flex-1 py-3 px-6 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black font-mono font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-xl shadow-amber-400/25 active:scale-98 text-center"
              >
                <Navigation className="w-4 h-4" />
                <span>OPEN TURN-BY-TURN DIRECTIONS (GOOGLE MAPS)</span>
              </a>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
