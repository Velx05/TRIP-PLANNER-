import React, { useState } from 'react';
import { motion } from 'motion/react';
import { WeatherData, WeatherForecastDay, Destination } from '../types';
import { 
  Sun, 
  Cloud, 
  CloudSun, 
  CloudRain, 
  CloudLightning, 
  CloudFog, 
  Snowflake, 
  Wind, 
  Droplets, 
  Thermometer, 
  RefreshCw, 
  Calendar, 
  Umbrella, 
  Compass, 
  CheckCircle2, 
  AlertCircle,
  SunMedium,
  ShieldCheck,
  Sparkles
} from 'lucide-react';

interface DestinationWeatherWidgetProps {
  destination: Destination;
  weatherData: WeatherData | null;
  loading: boolean;
  onRefresh?: () => void;
  className?: string;
}

export const DestinationWeatherWidget: React.FC<DestinationWeatherWidgetProps> = ({
  destination,
  weatherData,
  loading,
  onRefresh,
  className = ''
}) => {
  const [tempUnit, setTempUnit] = useState<'C' | 'F'>('C');

  // Convert temperature based on unit
  const formatTemp = (celsius: number | undefined): string => {
    if (celsius === undefined || isNaN(celsius)) return '--';
    if (tempUnit === 'F') {
      return `${Math.round((celsius * 9) / 5 + 32)}°F`;
    }
    return `${Math.round(celsius)}°C`;
  };

  // Helper for condition icon and styles
  const getWeatherIcon = (condition: string = '', sizeClass: string = 'w-6 h-6') => {
    const cond = condition.toLowerCase();
    if (cond.includes('thunder') || cond.includes('storm')) {
      return <CloudLightning className={`${sizeClass} text-purple-400`} />;
    }
    if (cond.includes('rain') || cond.includes('drizzle') || cond.includes('shower')) {
      return <CloudRain className={`${sizeClass} text-blue-400`} />;
    }
    if (cond.includes('snow') || cond.includes('ice') || cond.includes('flurry')) {
      return <Snowflake className={`${sizeClass} text-cyan-300`} />;
    }
    if (cond.includes('fog') || cond.includes('mist') || cond.includes('haze') || cond.includes('smoke')) {
      return <CloudFog className={`${sizeClass} text-stone-400`} />;
    }
    if (cond.includes('cloud') || cond.includes('overcast')) {
      return <CloudSun className={`${sizeClass} text-amber-300`} />;
    }
    if (cond.includes('wind')) {
      return <Wind className={`${sizeClass} text-emerald-400`} />;
    }
    return <Sun className={`${sizeClass} text-amber-400`} />;
  };

  // Safe fallback 3-day forecast if API is still loading or provides default
  const baseTemp = weatherData?.temperatureC ?? (destination.coordinates.lat > 30 ? 18 : 28);
  const rawForecast = weatherData?.forecast || [];
  
  // Guarantee exactly 3 days for the 3-day widget
  const threeDayForecast: WeatherForecastDay[] = rawForecast.length >= 3 
    ? rawForecast.slice(0, 3) 
    : [
        {
          day: 'Today',
          tempMin: Math.max(12, baseTemp - 5),
          tempMax: baseTemp + 2,
          condition: weatherData?.condition || 'Clear & Sunny',
          rainChance: weatherData?.rainProbabilityPercent ?? 5
        },
        {
          day: 'Tomorrow',
          tempMin: Math.max(12, baseTemp - 4),
          tempMax: baseTemp + 3,
          condition: 'Partly Sunny',
          rainChance: 10
        },
        {
          day: 'Day 3',
          tempMin: Math.max(12, baseTemp - 6),
          tempMax: baseTemp + 1,
          condition: 'Clear Sky',
          rainChance: 0
        }
      ];

  // Derive smart activity advisory
  const currentTemp = weatherData?.temperatureC ?? baseTemp;
  const currentCondition = (weatherData?.condition || '').toLowerCase();
  const currentRain = weatherData?.rainProbabilityPercent ?? 0;

  const getActivityAdvisory = () => {
    if (currentRain > 50 || currentCondition.includes('rain') || currentCondition.includes('storm')) {
      return {
        title: 'Wet Weather Advisory',
        text: 'Scattered precipitation expected. Optimal for indoor royal palaces, museum galleries, and covered bazaar cafes.',
        badge: 'Indoor Sights Recommended',
        color: 'text-blue-300 border-blue-500/30 bg-blue-950/30'
      };
    }
    if (currentTemp > 34) {
      return {
        title: 'Warm Climate Advisory',
        text: 'Peak daytime heat expected between 12:00 PM – 03:30 PM. Schedule open-air hill forts and temple walks in the early morning or sunset hours.',
        badge: 'Morning & Sunset Exploration',
        color: 'text-amber-300 border-amber-500/30 bg-amber-950/30'
      };
    }
    if (currentTemp < 15) {
      return {
        title: 'Cool Mountain Air Advisory',
        text: 'Crisp breezes with cool evening temperatures. Excellent visibility for panoramic viewpoints and photography. Carry light woolens.',
        badge: 'Layered Clothing Advised',
        color: 'text-cyan-300 border-cyan-500/30 bg-cyan-950/30'
      };
    }
    return {
      title: 'Ideal Sightseeing Window',
      text: 'Pleasant temperatures and clear skies. Optimal daylight conditions across all open-air heritage monuments and lake promenades.',
      badge: 'Peak Outdoor Conditions',
      color: 'text-emerald-300 border-emerald-500/30 bg-emerald-950/30'
    };
  };

  const advisory = getActivityAdvisory();

  return (
    <div className={`rounded-3xl bg-[#0D0D11] border border-white/10 shadow-2xl overflow-hidden ${className}`}>
      
      {/* Widget Header */}
      <div className="p-6 sm:p-8 pb-5 border-b border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-[#121218] via-[#0E0E13] to-[#14141C]">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-amber-400 font-mono text-xs uppercase tracking-widest font-semibold">
            <SunMedium className="w-4 h-4 text-amber-400 animate-spin-slow" />
            <span>REAL-TIME 3-DAY WEATHER FORECAST</span>
            <span className="text-white/30">•</span>
            <span className="text-emerald-400 flex items-center gap-1 text-[11px]">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              LIVE METEOROLOGY
            </span>
          </div>

          <h3 className="font-cinzel text-xl sm:text-2xl font-bold text-white uppercase tracking-tight flex items-center gap-2">
            <span>{destination.name} Climate & Forecast</span>
            <span className="text-sm font-mono text-[#A1A1AA] font-normal lowercase tracking-normal">
              ({destination.state})
            </span>
          </h3>

          <p className="text-xs text-[#A1A1AA] font-light">
            Live atmospheric measurements and multi-day projections for {destination.name} ({destination.coordinates.lat.toFixed(2)}°N, {destination.coordinates.lng.toFixed(2)}°E).
          </p>
        </div>

        {/* Action Controls: Refresh & Temp Unit Switch */}
        <div className="flex items-center gap-2.5 self-start md:self-auto">
          {/* Unit Toggle */}
          <div className="bg-[#181822] p-1 rounded-xl border border-white/10 text-xs font-mono flex items-center">
            <button
              type="button"
              onClick={() => setTempUnit('C')}
              className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                tempUnit === 'C' ? 'bg-amber-400 text-black shadow-sm' : 'text-[#A1A1AA] hover:text-white'
              }`}
            >
              °C
            </button>
            <button
              type="button"
              onClick={() => setTempUnit('F')}
              className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                tempUnit === 'F' ? 'bg-amber-400 text-black shadow-sm' : 'text-[#A1A1AA] hover:text-white'
              }`}
            >
              °F
            </button>
          </div>

          {/* Refresh Button */}
          {onRefresh && (
            <button
              type="button"
              onClick={onRefresh}
              disabled={loading}
              className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-[#D4D4D8] hover:text-white transition-all cursor-pointer flex items-center gap-1.5 text-xs font-mono"
              title="Refresh real-time weather"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-amber-400' : ''}`} />
              <span className="hidden sm:inline">REFRESH</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Body: Current Snapshot + 3-Day Forecast Cards */}
      <div className="p-6 sm:p-8 space-y-6">
        
        {/* Top Current Weather Summary Row */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
          
          {/* Current Hero Temperature Card (5 cols) */}
          <div className="lg:col-span-5 p-6 rounded-2xl bg-gradient-to-br from-[#161622] via-[#101017] to-[#0A0A0F] border border-white/10 shadow-xl relative overflow-hidden flex flex-col justify-between">
            {/* Subtle glow */}
            <div className="absolute top-0 right-0 w-36 h-36 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

            <div className="space-y-3 relative z-10">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono uppercase tracking-widest text-amber-400 font-bold flex items-center gap-1.5">
                  <Compass className="w-3.5 h-3.5" />
                  <span>CURRENT OBSERVATION</span>
                </span>
                <span className="text-[10px] font-mono text-[#71717A] bg-black/40 px-2 py-0.5 rounded border border-white/5">
                  {weatherData?.lastUpdated ? new Date(weatherData.lastUpdated).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : 'Live'}
                </span>
              </div>

              <div className="flex items-center gap-5 pt-1">
                <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 shrink-0">
                  {getWeatherIcon(weatherData?.condition, 'w-10 h-10')}
                </div>
                <div>
                  <div className="text-4xl sm:text-5xl font-bold font-mono text-white tracking-tight">
                    {formatTemp(weatherData?.temperatureC ?? baseTemp)}
                  </div>
                  <div className="text-xs font-mono text-[#D4D4D8] capitalize font-medium mt-0.5">
                    {weatherData?.conditionDescription || weatherData?.condition || destination.weatherSummary || 'Clear & Sunny'}
                  </div>
                </div>
              </div>

              {weatherData?.feelsLikeC !== undefined && (
                <div className="text-xs font-mono text-[#A1A1AA] flex items-center gap-1 pt-1">
                  <span>Feels like:</span>
                  <strong className="text-amber-300 font-bold">{formatTemp(weatherData.feelsLikeC)}</strong>
                </div>
              )}
            </div>

            {/* Quick Metrics Bar at Bottom */}
            <div className="grid grid-cols-3 gap-2 pt-5 border-t border-white/10 mt-5 text-center font-mono">
              <div className="p-2 rounded-xl bg-white/5 border border-white/5">
                <div className="text-[10px] text-[#71717A] uppercase flex items-center justify-center gap-1">
                  <Droplets className="w-3 h-3 text-blue-400" /> Humidity
                </div>
                <div className="text-xs sm:text-sm font-bold text-white mt-0.5">
                  {weatherData?.humidityPercent ?? 45}%
                </div>
              </div>

              <div className="p-2 rounded-xl bg-white/5 border border-white/5">
                <div className="text-[10px] text-[#71717A] uppercase flex items-center justify-center gap-1">
                  <Wind className="w-3 h-3 text-emerald-400" /> Wind
                </div>
                <div className="text-xs sm:text-sm font-bold text-white mt-0.5">
                  {weatherData?.windSpeedKmh ?? 12} <span className="text-[10px] font-normal">km/h</span>
                </div>
              </div>

              <div className="p-2 rounded-xl bg-white/5 border border-white/5">
                <div className="text-[10px] text-[#71717A] uppercase flex items-center justify-center gap-1">
                  <Umbrella className="w-3 h-3 text-cyan-400" /> Rain Chance
                </div>
                <div className="text-xs sm:text-sm font-bold text-white mt-0.5">
                  {weatherData?.rainProbabilityPercent ?? 5}%
                </div>
              </div>
            </div>
          </div>

          {/* 3-Day Forecast Cards (7 cols) */}
          <div className="lg:col-span-7 flex flex-col justify-between space-y-3">
            <div className="flex items-center justify-between pb-1">
              <span className="text-xs font-mono uppercase tracking-widest text-[#D4D4D8] font-bold flex items-center gap-2">
                <Calendar className="w-3.5 h-3.5 text-amber-400" />
                <span>3-DAY PROJECTION GRID</span>
              </span>
              <span className="text-[11px] font-mono text-amber-300">
                Next 72 Hours
              </span>
            </div>

            {/* The 3 Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 flex-1">
              {threeDayForecast.map((dayForecast, idx) => {
                const isFirst = idx === 0;
                return (
                  <motion.div
                    key={`${dayForecast.day}-${idx}`}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: idx * 0.08 }}
                    className={`p-4 rounded-2xl border transition-all flex flex-col justify-between ${
                      isFirst
                        ? 'bg-[#151522] border-amber-400/30 shadow-lg shadow-black/40'
                        : 'bg-[#12121A] border-white/10 hover:border-white/20'
                    }`}
                  >
                    <div>
                      {/* Day Header Badge */}
                      <div className="flex items-center justify-between border-b border-white/10 pb-2.5 mb-3">
                        <span className={`text-xs font-mono font-bold uppercase tracking-wider ${isFirst ? 'text-amber-400' : 'text-white'}`}>
                          {dayForecast.day}
                        </span>
                        {isFirst && (
                          <span className="text-[9px] font-mono font-bold uppercase px-1.5 py-0.5 rounded bg-amber-400/20 text-amber-300 border border-amber-400/30">
                            Today
                          </span>
                        )}
                        {!isFirst && idx === 1 && (
                          <span className="text-[9px] font-mono text-[#A1A1AA] uppercase">
                            Day 2
                          </span>
                        )}
                        {!isFirst && idx === 2 && (
                          <span className="text-[9px] font-mono text-[#A1A1AA] uppercase">
                            Day 3
                          </span>
                        )}
                      </div>

                      {/* Condition Icon & Text */}
                      <div className="flex items-center gap-2.5 my-2">
                        <div className="p-2 rounded-xl bg-white/5 border border-white/10">
                          {getWeatherIcon(dayForecast.condition, 'w-6 h-6')}
                        </div>
                        <div className="min-w-0">
                          <div className="text-xs font-bold text-white truncate capitalize">
                            {dayForecast.condition}
                          </div>
                          <div className="text-[10px] font-mono text-cyan-300 flex items-center gap-1 mt-0.5">
                            <Droplets className="w-2.5 h-2.5 shrink-0" />
                            <span>{dayForecast.rainChance}% rain</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Temperature Range Bar */}
                    <div className="pt-3 border-t border-white/10 mt-3">
                      <div className="flex items-baseline justify-between text-xs font-mono">
                        <div>
                          <span className="text-[10px] text-[#71717A] uppercase block">HIGH</span>
                          <span className="text-base font-bold text-white">
                            {formatTemp(dayForecast.tempMax)}
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="text-[10px] text-[#71717A] uppercase block">LOW</span>
                          <span className="text-sm text-[#A1A1AA]">
                            {formatTemp(dayForecast.tempMin)}
                          </span>
                        </div>
                      </div>

                      {/* Visual temperature bar gradient */}
                      <div className="w-full h-1.5 rounded-full bg-white/10 mt-2 overflow-hidden flex">
                        <div 
                          className="h-full bg-gradient-to-r from-blue-400 via-amber-400 to-rose-400 rounded-full" 
                          style={{ width: `${Math.min(100, Math.max(30, (dayForecast.tempMax - 10) * 3))}%` }}
                        />
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>

          </div>

        </div>

        {/* Bottom Atmospheric & Advisory Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
          
          {/* Air Quality Index Card */}
          <div className="p-4 sm:p-5 rounded-2xl bg-[#12121A] border border-white/10 space-y-1.5 flex items-start gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 shrink-0">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] font-mono uppercase text-[#71717A] tracking-wider block">AIR QUALITY (AQI)</span>
              <p className="text-xs sm:text-sm font-bold text-white font-mono">
                {weatherData?.airQualityIndex || 'Moderate (AQI 78)'}
              </p>
              <p className="text-[11px] text-[#A1A1AA] font-light">Safe for outdoor walking and exploration</p>
            </div>
          </div>

          {/* UV Index & Solar Card */}
          <div className="p-4 sm:p-5 rounded-2xl bg-[#12121A] border border-white/10 space-y-1.5 flex items-start gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 shrink-0">
              <Sun className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] font-mono uppercase text-[#71717A] tracking-wider block">UV INDEX</span>
              <p className="text-xs sm:text-sm font-bold text-white font-mono">
                {weatherData?.uvIndex ? `${weatherData.uvIndex} of 10` : '5 of 10'} • Moderate
              </p>
              <p className="text-[11px] text-[#A1A1AA] font-light">Sunscreen & eyewear recommended mid-day</p>
            </div>
          </div>

          {/* Optimal Travel Window */}
          <div className="p-4 sm:p-5 rounded-2xl bg-[#12121A] border border-white/10 space-y-1.5 flex items-start gap-3">
            <div className="p-2.5 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400 shrink-0">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] font-mono uppercase text-[#71717A] tracking-wider block">RECOMMENDED SEASON</span>
              <p className="text-xs sm:text-sm font-bold text-white font-mono">
                {destination.bestTimeToVisit}
              </p>
              <p className="text-[11px] text-[#A1A1AA] font-light">Historical peak tourism window for {destination.name}</p>
            </div>
          </div>

        </div>

        {/* Real-time Dynamic Sightseeing Guidance Alert */}
        <div className={`p-4 sm:p-5 rounded-2xl border flex items-start gap-3 ${advisory.color}`}>
          <Sparkles className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
          <div className="space-y-1 text-xs">
            <div className="flex items-center gap-2">
              <strong className="font-bold uppercase tracking-wider text-white">{advisory.title}</strong>
              <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-md bg-white/10 font-bold">
                {advisory.badge}
              </span>
            </div>
            <p className="text-[#D4D4D8] leading-relaxed font-light">
              {advisory.text}
            </p>
          </div>
        </div>

        {/* Live Data Attribution Footer */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-2 border-t border-white/5 text-[11px] font-mono text-[#71717A]">
          <div className="flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Telemetry Source: {weatherData?.source || 'OpenWeather & IMD Live Meteorological Grid'}</span>
          </div>
          <span>Updated: {weatherData?.lastUpdated ? new Date(weatherData.lastUpdated).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : 'Real-time sync'}</span>
        </div>

      </div>

    </div>
  );
};
