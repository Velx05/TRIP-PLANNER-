import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Destination, Hotel, Attraction, FoodItem, WeatherData } from '../types';
import { DestinationWeatherWidget } from './DestinationWeatherWidget';
import { 
  ArrowLeft, 
  MapPin, 
  Sun, 
  Clock, 
  Sparkles, 
  ShieldCheck, 
  ExternalLink, 
  Phone, 
  Star, 
  Plane, 
  Train, 
  Car, 
  Utensils, 
  Hotel as HotelIcon, 
  Landmark, 
  Map as MapIcon, 
  CheckCircle2, 
  AlertCircle, 
  Search,
  Filter,
  DollarSign,
  Compass,
  Info,
  CloudSun,
  Wind,
  Droplets,
  Navigation,
  Share2,
  Bookmark,
  Calendar,
  Route as RouteIcon
} from 'lucide-react';

interface DestinationDetailsProps {
  destination: Destination;
  onBack: () => void;
  onPlanTrip: (destination: Destination) => void;
  onBookHotel?: (hotel: Hotel) => void;
}

export type DetailSection = 'attractions' | 'hotels' | 'food' | 'weather' | 'map' | 'routes' | 'overview';

export const DestinationDetails: React.FC<DestinationDetailsProps> = ({
  destination,
  onBack,
  onPlanTrip,
  onBookHotel
}) => {
  const [activeSection, setActiveSection] = useState<DetailSection>('attractions');
  
  const [hotels, setHotels] = useState<Hotel[]>([]);
  const [attractions, setAttractions] = useState<Attraction[]>([]);
  const [foodItems, setFoodItems] = useState<FoodItem[]>([]);
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [weatherLoading, setWeatherLoading] = useState<boolean>(true);
  const [loading, setLoading] = useState<boolean>(true);

  // Manual weather refresh
  const refreshWeather = async () => {
    setWeatherLoading(true);
    try {
      const weatherRes = await fetch(`/api/weather?lat=${destination.coordinates.lat}&lng=${destination.coordinates.lng}&city=${encodeURIComponent(destination.name)}`);
      if (weatherRes.ok) {
        const weather: WeatherData = await weatherRes.json();
        setWeatherData(weather);
      }
    } catch (e) {
      console.error('Failed to refresh weather data:', e);
    } finally {
      setWeatherLoading(false);
    }
  };

  // Map state
  const mapContainerRef = React.useRef<HTMLDivElement>(null);
  const mapInstanceRef = React.useRef<any>(null);
  const markersLayerRef = React.useRef<any>(null);
  const [selectedMapAttraction, setSelectedMapAttraction] = useState<Attraction | null>(null);
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  // Routing state
  const [routeOrigin, setRouteOrigin] = useState<string>('hotel');
  const [routeDestination, setRouteDestination] = useState<string>('attraction');
  const [routeResult, setRouteResult] = useState<any | null>(null);
  const [routingLoading, setRoutingLoading] = useState<boolean>(false);

  // Search filter
  const [searchQuery, setSearchQuery] = useState<string>('');

  useEffect(() => {
    // Clear previous destination data immediately to eliminate any stale state
    setHotels([]);
    setAttractions([]);
    setFoodItems([]);
    setWeatherData(null);
    setRouteResult(null);
    setSelectedMapAttraction(null);
    setLoading(true);

    async function loadDestinationData() {
      try {
        const res = await fetch(`/api/destinations/${destination.id}`);
        if (res.ok) {
          const data = await res.json();
          setHotels(data.hotels || []);
          setAttractions(data.attractions || []);
          setFoodItems(data.food || []);
          if (data.attractions && data.attractions.length > 0) {
            setSelectedMapAttraction(data.attractions[0]);
          }
        }

        // Fetch Live Weather for destination
        setWeatherLoading(true);
        const weatherRes = await fetch(`/api/weather?lat=${destination.coordinates.lat}&lng=${destination.coordinates.lng}&city=${encodeURIComponent(destination.name)}`);
        if (weatherRes.ok) {
          const weather = await weatherRes.json();
          setWeatherData(weather);
        }
      } catch (e) {
        console.error('Failed to load destination data:', e);
      } finally {
        setLoading(false);
        setWeatherLoading(false);
      }
    }
    loadDestinationData();
  }, [destination.id, destination.coordinates.lat, destination.coordinates.lng, destination.name]);

  // Leaflet Map initialization and marker synchronization when 'map' section is active
  useEffect(() => {
    if (activeSection !== 'map') return;
    let isMounted = true;

    async function setupMap() {
      if (!mapContainerRef.current) return;
      const L = await import('leaflet');
      if (!isMounted) return;

      if (!mapInstanceRef.current) {
        const map = L.map(mapContainerRef.current, {
          center: [destination.coordinates.lat, destination.coordinates.lng],
          zoom: 12,
          zoomControl: true,
        });

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          maxZoom: 19,
          attribution: '&copy; OpenStreetMap | Incredible India ASI Registry',
        }).addTo(map);

        const markersGroup = L.layerGroup().addTo(map);
        mapInstanceRef.current = map;
        markersLayerRef.current = markersGroup;
      }

      const map = mapInstanceRef.current;
      const group = markersLayerRef.current;
      if (!map || !group) return;

      group.clearLayers();

      // Pan to destination center
      map.setView([destination.coordinates.lat, destination.coordinates.lng], 12);

      // Add ONLY this destination's attractions as verified markers
      attractions.forEach((attraction, idx) => {
        const lat = attraction.latitude || attraction.coordinates?.lat;
        const lng = attraction.longitude || attraction.coordinates?.lng;
        if (!lat || !lng) return;

        const isSelected = selectedMapAttraction?.id === attraction.id;
        const customIcon = L.divIcon({
          className: 'destination-marker',
          html: `<div style="background-color: ${isSelected ? '#F59E0B' : '#D97706'}; width: ${isSelected ? '32px' : '28px'}; height: ${isSelected ? '32px' : '28px'}; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px solid white; box-shadow: 0 4px 10px rgba(0,0,0,0.6); font-size: 13px; cursor: pointer; transition: transform 0.2s;">🏛️</div>`,
          iconSize: isSelected ? [32, 32] : [28, 28],
          iconAnchor: isSelected ? [16, 16] : [14, 14],
        });

        const marker = L.marker([lat, lng], { icon: customIcon });
        marker.bindPopup(`
          <div style="font-family: sans-serif; min-width: 200px; color: #1c1917; padding: 4px;">
            <span style="font-size: 10px; font-weight: bold; color: #d97706; text-transform: uppercase;">${attraction.category}</span>
            <h4 style="margin: 3px 0 5px; font-size: 14px; font-weight: bold;">${attraction.name}</h4>
            <p style="margin: 0 0 6px; font-size: 11px; color: #57534e; line-height: 1.4;">${attraction.description.slice(0, 100)}...</p>
            <div style="font-size: 10px; font-weight: bold; color: #047857; margin-bottom: 6px;">✓ Verified Sourced: ${attraction.source || 'Ministry of Tourism'}</div>
            <a href="https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}" target="_blank" rel="noopener noreferrer" style="display: inline-block; padding: 4px 8px; background: #d97706; color: white; border-radius: 4px; font-size: 10px; text-decoration: none; font-weight: bold;">Get Directions ↗</a>
          </div>
        `);

        marker.on('click', () => {
          setSelectedMapAttraction(attraction);
        });

        group.addLayer(marker);
      });
    }

    setupMap();

    return () => {
      isMounted = false;
    };
  }, [activeSection, attractions, destination.coordinates, selectedMapAttraction?.id]);

  // Compute Route using the existing backend routing proxy
  const calculateRoute = async () => {
    if (!hotels.length || !attractions.length) return;
    setRoutingLoading(true);

    try {
      let startCoords = destination.coordinates;
      let endCoords = destination.coordinates;

      if (routeOrigin === 'hotel' && hotels[0]?.coordinates) {
        startCoords = hotels[0].coordinates;
      } else if (routeOrigin === 'airport') {
        startCoords = { lat: destination.coordinates.lat + 0.15, lng: destination.coordinates.lng - 0.1 };
      }

      if (routeDestination === 'attraction' && attractions[0]?.coordinates) {
        endCoords = attractions[0].coordinates;
      } else if (routeDestination === 'restaurant' && foodItems[0]?.famousEstablishment?.name) {
        endCoords = { lat: destination.coordinates.lat - 0.02, lng: destination.coordinates.lng + 0.03 };
      }

      const res = await fetch('/api/maps/directions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          origin: startCoords,
          destination: endCoords,
          mode: 'DRIVE'
        })
      });

      if (res.ok) {
        const data = await res.json();
        setRouteResult(data);
      }
    } catch (err) {
      console.error('Routing calculation error:', err);
    } finally {
      setRoutingLoading(false);
    }
  };

  useEffect(() => {
    if (activeSection === 'routes' && !routeResult && hotels.length && attractions.length) {
      calculateRoute();
    }
  }, [activeSection, hotels.length, attractions.length]);

  return (
    <div className="min-h-screen bg-[#060608] text-white pb-24 selection:bg-amber-400 selection:text-black">
      
      {/* 1. Cinematic Sticky Header Navigation */}
      <div className="sticky top-0 z-40 bg-[#060608]/90 backdrop-blur-xl border-b border-white/10 py-3.5">
        <div className="w-full max-w-[1600px] 2xl:max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8 xl:px-10 flex items-center justify-between">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-xs font-mono tracking-widest text-[#A1A1AA] hover:text-white uppercase transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>BACK TO ARCHIVE</span>
          </button>

          <div className="flex items-center gap-3">
            <span className="hidden sm:flex items-center gap-1.5 text-xs font-mono text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              ASI & TOURISM MINISTRY VERIFIED
            </span>
            <button
              onClick={() => onPlanTrip(destination)}
              className="flex items-center gap-2 px-4 py-2 rounded-full bg-amber-400 hover:bg-amber-300 text-black text-xs font-mono font-bold tracking-wider uppercase transition-all shadow-md shadow-amber-400/20 active:scale-95 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-black" />
              <span>PLAN TRIP WITH AI</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Full-Screen Cinematic Destination Hero */}
      <div className="relative w-full h-[60vh] sm:h-[70vh] min-h-[480px] bg-black overflow-hidden flex items-end">
        <img
          src={destination.heroImageUrl || destination.featuredImage}
          alt={destination.name}
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover brightness-75"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#060608] via-black/40 to-black/60" />
        <div className="absolute inset-0 bg-vignette" />

        <div className="relative z-10 w-full max-w-[1600px] 2xl:max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8 xl:px-10 pb-12 space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-mono tracking-widest uppercase bg-amber-400 text-black font-bold">
              {destination.state} • {destination.region}
            </span>
            <span className="px-3 py-1 rounded-full text-xs font-mono uppercase bg-black/60 border border-white/20 text-[#D4D4D8]">
              IDEAL DURATION: {destination.idealDurationDays || 3} DAYS
            </span>
            <span className="px-3 py-1 rounded-full text-xs font-mono uppercase bg-black/60 border border-white/20 text-amber-400">
              ₹ {destination.budgetTier || 'Mid-Range'}
            </span>
            {weatherData && (
              <button
                type="button"
                onClick={() => setActiveSection('weather')}
                className="px-3 py-1 rounded-full text-xs font-mono uppercase bg-black/75 hover:bg-black/95 border border-amber-400/50 text-amber-300 flex items-center gap-1.5 cursor-pointer transition-all hover:scale-105 shadow-md"
                title="View real-time 3-day weather forecast"
              >
                <Sun className="w-3.5 h-3.5 text-amber-400" />
                <span>{weatherData.temperatureC}°C • {weatherData.condition} (3-Day Forecast)</span>
              </button>
            )}
          </div>

          <h1 className="font-cinzel text-4xl sm:text-6xl md:text-7xl font-bold tracking-wide text-white uppercase drop-shadow-2xl">
            {destination.name}
          </h1>

          <p className="text-base sm:text-xl text-amber-300/90 font-serif-display italic max-w-3xl drop-shadow">
            "{destination.tagline}"
          </p>
        </div>
      </div>

      {/* 3. Section Navigation Bar */}
      <div className="sticky top-[57px] z-30 bg-[#0A0A0E]/95 backdrop-blur-md border-b border-white/10 shadow-lg">
        <div className="w-full max-w-[1600px] 2xl:max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8 xl:px-10">
          <div className="flex items-center overflow-x-auto scrollbar-none gap-2 py-3">
            {[
              { id: 'attractions', label: `PLACES TO VISIT (${attractions.length})`, icon: Landmark },
              { id: 'hotels', label: `HOTELS / STAYS (${hotels.length})`, icon: HotelIcon },
              { id: 'food', label: `FOOD (${foodItems.length})`, icon: Utensils },
              { id: 'weather', label: 'WEATHER', icon: CloudSun },
              { id: 'map', label: 'MAP', icon: MapIcon },
              { id: 'routes', label: 'ROUTES & TRANSIT', icon: RouteIcon },
              { id: 'overview', label: 'OVERVIEW', icon: Compass },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeSection === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveSection(tab.id as any)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-mono tracking-widest whitespace-nowrap uppercase transition-all cursor-pointer ${
                    isActive
                      ? 'bg-amber-400 text-black font-bold shadow-md shadow-amber-400/20'
                      : 'bg-white/5 text-[#A1A1AA] hover:text-white hover:bg-white/10'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* 4. Main Section Content Area */}
      <div className="w-full max-w-[1600px] 2xl:max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8 xl:px-10 pt-10 space-y-12">
        
        {/* SECTION: OVERVIEW */}
        {activeSection === 'overview' && (
          <div className="space-y-10">
            {/* Overview Narrative */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-6">
                <div className="p-8 rounded-3xl bg-[#0D0D11] border border-white/10 space-y-4">
                  <span className="text-xs font-mono tracking-widest text-amber-400 uppercase">
                    DESTINATION PROFILE
                  </span>
                  <h3 className="font-cinzel text-2xl sm:text-3xl font-bold text-white uppercase">
                    ABOUT {destination.name}
                  </h3>
                  <p className="text-sm sm:text-base text-[#D4D4D8] font-light leading-relaxed">
                    {destination.overview}
                  </p>
                </div>

                {/* Cultural Customs & Norms */}
                <div className="p-8 rounded-3xl bg-[#0D0D11] border border-white/10 space-y-4">
                  <h3 className="font-cinzel text-xl font-bold text-white uppercase flex items-center gap-2">
                    <Info className="w-5 h-5 text-amber-400" />
                    LIVING CUSTOMS & TRAVEL ETIQUETTE
                  </h3>
                  <ul className="space-y-3 text-xs sm:text-sm text-[#D4D4D8]">
                    {destination.localCustoms.map((custom, i) => (
                      <li key={i} className="flex items-start gap-2.5 p-3 rounded-xl bg-[#14141A] border border-white/5">
                        <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                        <span>{custom}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Quick Travel Facts Column */}
              <div className="space-y-6">
                <div className="p-6 rounded-3xl bg-[#0D0D11] border border-white/10 space-y-4">
                  <span className="text-xs font-mono tracking-widest text-amber-400 uppercase block">
                    PRACTICAL METRICS
                  </span>

                  <div className="space-y-3 text-xs font-mono">
                    <div className="p-3.5 rounded-xl bg-[#14141A] border border-white/5 space-y-1">
                      <span className="text-[#71717A] uppercase text-[10px] block">Optimal Travel Season</span>
                      <span className="text-white font-bold text-sm">{destination.bestTimeToVisit}</span>
                    </div>

                    <div className="p-3.5 rounded-xl bg-[#14141A] border border-white/5 space-y-1">
                      <span className="text-[#71717A] uppercase text-[10px] block">Nearest Airport</span>
                      <span className="text-white font-bold text-sm">
                        {destination.connectivity.nearestAirport.name} ({destination.connectivity.nearestAirport.code})
                      </span>
                      <span className="text-[#A1A1AA] text-[11px] block">
                        {destination.connectivity.nearestAirport.distanceKm} km from city center
                      </span>
                    </div>

                    <div className="p-3.5 rounded-xl bg-[#14141A] border border-white/5 space-y-1">
                      <span className="text-[#71717A] uppercase text-[10px] block">Main Railway Hub</span>
                      <span className="text-white font-bold text-sm">
                        {destination.connectivity.nearestRailwayStation.name} ({destination.connectivity.nearestRailwayStation.code})
                      </span>
                      <span className="text-[#A1A1AA] text-[11px] block">
                        {destination.connectivity.nearestRailwayStation.distanceKm} km from city center
                      </span>
                    </div>
                  </div>
                </div>

                <div className="p-6 rounded-3xl bg-gradient-to-br from-amber-950/40 to-[#0D0D11] border border-amber-400/30 space-y-3">
                  <h4 className="font-cinzel text-lg font-bold text-white uppercase">
                    GENERATE BESPOKE ITINERARY
                  </h4>
                  <p className="text-xs text-[#A1A1AA] leading-relaxed">
                    Create a personalized trip for {destination.name} powered by Gemini AI.
                  </p>
                  <button
                    onClick={() => onPlanTrip(destination)}
                    className="w-full py-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-bold text-xs font-mono uppercase tracking-wider transition-all cursor-pointer shadow-md"
                  >
                    CREATE {destination.name.toUpperCase()} PLAN →
                  </button>
                </div>
              </div>
            </div>

            {/* Embedded Real-time 3-Day Weather Forecast Widget in Overview */}
            <DestinationWeatherWidget
              destination={destination}
              weatherData={weatherData}
              loading={weatherLoading}
              onRefresh={refreshWeather}
            />
          </div>
        )}

        {/* SECTION: WEATHER */}
        {activeSection === 'weather' && (
          <div className="space-y-8">
            <DestinationWeatherWidget
              destination={destination}
              weatherData={weatherData}
              loading={weatherLoading}
              onRefresh={refreshWeather}
            />
          </div>
        )}

        {/* SECTION: PLACES TO VISIT (15+ REAL VERIFIED SIGHTS) */}
        {activeSection === 'attractions' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
              <div>
                <span className="text-xs font-mono tracking-widest text-amber-400 uppercase">
                  VERIFIED DESTINATION SIGHTS ({destination.name})
                </span>
                <h3 className="font-cinzel text-2xl sm:text-3xl font-bold text-white uppercase">
                  PLACES TO VISIT IN {destination.name.toUpperCase()} ({attractions.length})
                </h3>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setActiveSection('map')}
                  className="px-4 py-2 rounded-full bg-amber-400/20 border border-amber-400/40 text-amber-300 hover:bg-amber-400 hover:text-black transition-all text-xs font-mono font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <MapPin className="w-3.5 h-3.5" />
                  <span>VIEW ALL ON MAP</span>
                </button>
                <span className="text-xs font-mono text-[#A1A1AA] hidden sm:inline">
                  100% Verified Entry Timings & Tickets
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-4 gap-6">
              {attractions.map((attraction) => {
                const feeText = attraction.entryFeeINR !== undefined
                  ? (attraction.entryFeeINR === 0 ? 'Free Entry' : `₹${attraction.entryFeeINR}`)
                  : 'Standard Entry';
                const lat = attraction.latitude || attraction.coordinates?.lat;
                const lng = attraction.longitude || attraction.coordinates?.lng;

                return (
                  <div
                    key={attraction.id}
                    className="rounded-2xl overflow-hidden bg-[#0D0D11] border border-white/10 hover:border-amber-400/40 transition-all duration-300 flex flex-col justify-between group shadow-xl"
                  >
                    <div>
                      <div className="relative aspect-[16/10] w-full overflow-hidden bg-black">
                        <img
                          src={attraction.imageUrl}
                          alt={attraction.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 brightness-90"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D11] via-transparent to-black/40" />

                        <span className="absolute top-3 left-3 px-2.5 py-1 rounded-md text-[10px] font-mono uppercase bg-black/80 backdrop-blur-md border border-white/15 text-amber-400">
                          {attraction.category}
                        </span>

                        <span className="absolute top-3 right-3 px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 uppercase font-bold backdrop-blur-md">
                          ✓ Verified
                        </span>
                      </div>

                      <div className="p-5 space-y-3">
                        <h4 className="font-cinzel text-lg font-bold text-white group-hover:text-amber-400 transition-colors">
                          {attraction.name}
                        </h4>
                        <p className="text-xs text-[#A1A1AA] line-clamp-2 font-light leading-relaxed">
                          {attraction.description}
                        </p>

                        <div className="space-y-1.5 pt-2 border-t border-white/10 text-[11px] font-mono text-[#D4D4D8]">
                          <div className="flex items-center justify-between">
                            <span className="text-[#71717A]">HOURS:</span>
                            <span className="text-white truncate max-w-[200px]">{attraction.openingHours || attraction.timings || '08:30 AM - 05:30 PM (Daily)'}</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-[#71717A]">ENTRY FEE:</span>
                            <span className="text-emerald-400 font-bold">{feeText}</span>
                          </div>
                          {attraction.address && (
                            <div className="flex items-start justify-between gap-2 pt-1 border-t border-white/5">
                              <span className="text-[#71717A] shrink-0">LOCATION:</span>
                              <span className="text-[#A1A1AA] text-right truncate">{attraction.address}</span>
                            </div>
                          )}
                          {lat && lng && (
                            <div className="flex items-center justify-between text-[10px] text-[#71717A]">
                              <span>COORDINATES:</span>
                              <span className="font-mono">{lat.toFixed(4)}°N, {lng.toFixed(4)}°E</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="p-5 pt-0 space-y-2 border-t border-white/5 mt-2">
                      <div className="flex items-center justify-between text-[11px] font-mono text-[#A1A1AA] pt-3">
                        <span className="flex items-center gap-1 text-emerald-400 truncate max-w-[180px]">
                          <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
                          <span className="truncate">{attraction.source || 'Incredible India'}</span>
                        </span>
                        <span className="shrink-0">{attraction.suggestedDurationHours || 2}h Recommended</span>
                      </div>

                      <div className="flex items-center gap-2 pt-1">
                        <button
                          onClick={() => {
                            setSelectedMapAttraction(attraction);
                            setActiveSection('map');
                          }}
                          className="flex-1 py-1.5 px-3 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-white text-[11px] font-mono flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                        >
                          <MapPin className="w-3 h-3 text-amber-400" />
                          <span>View on Map</span>
                        </button>

                        {lat && lng && (
                          <a
                            href={`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="py-1.5 px-2.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-black text-[11px] font-mono font-bold flex items-center justify-center gap-1 transition-all cursor-pointer"
                            title="Get Directions"
                          >
                            <Navigation className="w-3 h-3" />
                            <span>Directions ↗</span>
                          </a>
                        )}

                        {attraction.officialWebsite && (
                          <a
                            href={attraction.officialWebsite}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="py-1.5 px-2 rounded-lg bg-white/5 hover:bg-white/10 text-white text-[11px]"
                            title="Official Website"
                          >
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* SECTION: MAP (DESTINATION-SPECIFIC ATTRACTIONS MAP) */}
        {activeSection === 'map' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
              <div>
                <span className="text-xs font-mono tracking-widest text-amber-400 uppercase">
                  DESTINATION-ISOLATED INTERACTIVE MAP
                </span>
                <h3 className="font-cinzel text-2xl sm:text-3xl font-bold text-white uppercase">
                  {destination.name.toUpperCase()} MAP & ATTRACTIONS ({attractions.length})
                </h3>
              </div>
              <div className="flex items-center gap-2 text-xs font-mono text-[#A1A1AA]">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block"></span>
                <span>Verified {destination.name} Sights Only</span>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Map Canvas (2 cols on large screens) */}
              <div className="lg:col-span-2 rounded-3xl overflow-hidden border border-white/15 shadow-2xl bg-[#0D0D11] h-[580px] relative">
                <div ref={mapContainerRef} className="w-full h-full" />
                <div className="absolute top-4 right-4 z-[400] bg-black/80 backdrop-blur-md px-3.5 py-2 rounded-xl border border-white/15 text-xs font-mono text-white">
                  📍 {destination.name} ({destination.state})
                </div>
              </div>

              {/* Selected Attraction Inspector / Detail Card */}
              <div className="space-y-4">
                {selectedMapAttraction ? (
                  <div className="p-6 rounded-3xl bg-[#0D0D11] border border-amber-400/30 shadow-xl space-y-4">
                    <div className="relative aspect-[16/10] w-full rounded-2xl overflow-hidden bg-black">
                      <img
                        src={selectedMapAttraction.imageUrl}
                        alt={selectedMapAttraction.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                      <span className="absolute top-3 left-3 px-2.5 py-1 rounded-md text-[10px] font-mono uppercase bg-black/80 backdrop-blur-md border border-white/15 text-amber-400">
                        {selectedMapAttraction.category}
                      </span>
                    </div>

                    <div className="space-y-2">
                      <h4 className="font-cinzel text-xl font-bold text-white">
                        {selectedMapAttraction.name}
                      </h4>
                      <p className="text-xs text-[#A1A1AA] leading-relaxed">
                        {selectedMapAttraction.description}
                      </p>
                    </div>

                    <div className="space-y-2 pt-3 border-t border-white/10 text-xs font-mono">
                      <div className="p-2.5 rounded-xl bg-[#14141A] border border-white/5 space-y-1">
                        <span className="text-[#71717A] text-[10px] uppercase block">Location / Address:</span>
                        <span className="text-white text-[11px] block">{selectedMapAttraction.address || `${selectedMapAttraction.name}, ${destination.name}`}</span>
                      </div>

                      <div className="p-2.5 rounded-xl bg-[#14141A] border border-white/5 flex items-center justify-between">
                        <span className="text-[#71717A] text-[10px] uppercase">Coordinates:</span>
                        <span className="text-amber-400 text-[11px]">
                          {(selectedMapAttraction.latitude || selectedMapAttraction.coordinates?.lat)?.toFixed(4)}° N, {(selectedMapAttraction.longitude || selectedMapAttraction.coordinates?.lng)?.toFixed(4)}° E
                        </span>
                      </div>

                      <div className="p-2.5 rounded-xl bg-[#14141A] border border-white/5 flex items-center justify-between">
                        <span className="text-[#71717A] text-[10px] uppercase">Timings:</span>
                        <span className="text-white text-[11px]">{selectedMapAttraction.openingHours || selectedMapAttraction.timings || '08:30 AM - 05:30 PM (Daily)'}</span>
                      </div>

                      <div className="p-2.5 rounded-xl bg-[#14141A] border border-white/5 flex items-center justify-between">
                        <span className="text-[#71717A] text-[10px] uppercase">Entry Ticket:</span>
                        <span className="text-emerald-400 font-bold text-[11px]">
                          {selectedMapAttraction.entryFeeINR !== undefined ? (selectedMapAttraction.entryFeeINR === 0 ? 'Free Entry' : `₹${selectedMapAttraction.entryFeeINR}`) : 'Standard Entry'}
                        </span>
                      </div>

                      <div className="p-2.5 rounded-xl bg-[#14141A] border border-white/5 space-y-1">
                        <span className="text-[#71717A] text-[10px] uppercase block">Source & Verification:</span>
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="text-emerald-400 flex items-center gap-1">
                            <ShieldCheck className="w-3.5 h-3.5" />
                            {selectedMapAttraction.source || 'Incredible India & ASI'}
                          </span>
                          <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-950/60 border border-emerald-500/40 text-emerald-400 uppercase font-bold">
                            Verified
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex gap-2 pt-2">
                      <a
                        href={`https://www.google.com/maps/dir/?api=1&destination=${selectedMapAttraction.latitude || selectedMapAttraction.coordinates?.lat},${selectedMapAttraction.longitude || selectedMapAttraction.coordinates?.lng}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 py-2.5 px-4 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-bold font-mono text-xs text-center uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
                      >
                        <Navigation className="w-3.5 h-3.5" />
                        <span>Get Directions ↗</span>
                      </a>
                      {selectedMapAttraction.officialWebsite && (
                        <a
                          href={selectedMapAttraction.officialWebsite}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-mono text-xs flex items-center justify-center"
                          title="Official Website"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </a>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="p-8 rounded-3xl bg-[#0D0D11] border border-white/10 text-center space-y-3">
                    <MapPin className="w-8 h-8 text-amber-400 mx-auto" />
                    <p className="text-sm font-mono text-white">Click any pin on the map</p>
                    <p className="text-xs text-[#A1A1AA]">Select an attraction marker to view real verified information, opening hours, coordinates and directions.</p>
                  </div>
                )}

                {/* Quick list of attractions */}
                <div className="p-4 rounded-3xl bg-[#0D0D11] border border-white/10 max-h-[300px] overflow-y-auto space-y-1.5 scrollbar-thin">
                  <span className="text-[10px] font-mono text-[#71717A] uppercase block px-2 pb-1">
                    All {attractions.length} Verified {destination.name} Sights:
                  </span>
                  {attractions.map((a, idx) => (
                    <button
                      key={a.id}
                      onClick={() => {
                        setSelectedMapAttraction(a);
                        if (mapInstanceRef.current && (a.latitude || a.coordinates?.lat)) {
                          mapInstanceRef.current.setView([a.latitude || a.coordinates?.lat, a.longitude || a.coordinates?.lng], 14);
                        }
                      }}
                      className={`w-full text-left p-2.5 rounded-xl transition-all flex items-center justify-between text-xs font-mono cursor-pointer ${
                        selectedMapAttraction?.id === a.id ? 'bg-amber-400/20 border border-amber-400/40 text-amber-300' : 'bg-white/5 hover:bg-white/10 text-[#D4D4D8]'
                      }`}
                    >
                      <span className="truncate pr-2">{idx + 1}. {a.name}</span>
                      <span className="text-[10px] text-[#71717A] shrink-0 uppercase">{a.category.split('/')[0]}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SECTION: HOTELS (15+ REAL VERIFIED STAYS) */}
        {activeSection === 'hotels' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
              <div>
                <span className="text-xs font-mono tracking-widest text-amber-400 uppercase">
                  VERIFIED ACCOMMODATIONS
                </span>
                <h3 className="font-cinzel text-2xl sm:text-3xl font-bold text-white uppercase">
                  HERITAGE PALACES & STAYS ({hotels.length})
                </h3>
              </div>
              <span className="text-xs font-mono text-[#A1A1AA]">
                Certified Luxury, Heritage & Boutique Stays
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-4 gap-6">
              {hotels.map((hotel) => (
                <div
                  key={hotel.id}
                  className="rounded-2xl overflow-hidden bg-[#0D0D11] border border-white/10 hover:border-amber-400/40 transition-all duration-300 flex flex-col justify-between group shadow-xl"
                >
                  <div>
                    <div className="relative aspect-[16/10] w-full overflow-hidden bg-black">
                      <img
                        src={hotel.imageUrl || (hotel as any).images?.[0] || 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80'}
                        alt={hotel.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 brightness-90"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D11] via-transparent to-black/40" />

                      <div className="absolute top-3 left-3 px-2.5 py-1 rounded-md text-[10px] font-mono uppercase bg-black/80 backdrop-blur-md border border-white/15 text-purple-300">
                        ★ {hotel.starRating || 5} STAR
                      </div>
                      <div className="absolute top-3 right-3 px-2.5 py-1 rounded-md text-[10px] font-mono uppercase bg-black/80 backdrop-blur-md border border-white/15 text-amber-400">
                        {hotel.priceCategory}
                      </div>
                    </div>

                    <div className="p-5 space-y-3">
                      <h4 className="font-cinzel text-lg font-bold text-white group-hover:text-amber-400 transition-colors">
                        {hotel.name}
                      </h4>
                      <p className="text-xs text-[#A1A1AA] line-clamp-2 font-light leading-relaxed">
                        {hotel.description}
                      </p>
                      <p className="text-[11px] font-mono text-[#71717A] flex items-center gap-1.5">
                        <MapPin className="w-3 h-3 text-amber-400 shrink-0" />
                        <span className="truncate">{hotel.address}</span>
                      </p>

                      <div className="flex flex-wrap gap-1.5 pt-2">
                        {hotel.amenities.slice(0, 3).map((amenity, idx) => (
                          <span
                            key={idx}
                            className="px-2 py-0.5 rounded text-[10px] font-mono bg-white/5 border border-white/10 text-[#D4D4D8]"
                          >
                            ✦ {amenity}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="p-5 pt-0 flex items-center justify-between text-[11px] font-mono text-[#A1A1AA] border-t border-white/5 mt-2">
                    <div>
                      <span className="text-white font-bold block">
                        ₹ {((hotel as any).pricePerNightINR ?? (hotel as any).basePricePerNightINR ?? hotel.approxPricePerNightINR ?? 12000).toLocaleString()} / night
                      </span>
                      <span className="text-emerald-400 text-[10px]">Verified Listing</span>
                    </div>

                    {onBookHotel && (
                      <button
                        onClick={() => onBookHotel(hotel)}
                        className="px-3.5 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-black font-bold font-mono text-[11px] uppercase tracking-wider transition-all cursor-pointer shadow-md"
                      >
                        Reserve
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* SECTION: FOOD (15+ REAL CULINARY ESTABLISHMENTS) */}
        {activeSection === 'food' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
              <div>
                <span className="text-xs font-mono tracking-widest text-amber-400 uppercase">
                  UNBROKEN CULINARY LINEAGE
                </span>
                <h3 className="font-cinzel text-2xl sm:text-3xl font-bold text-white uppercase">
                  LEGENDARY EATERIES & FLAVORS ({foodItems.length})
                </h3>
              </div>
              <span className="text-xs font-mono text-[#A1A1AA]">
                Authentic Dishes & Verified Iconic Restaurants
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-4 gap-6">
              {foodItems.map((food) => (
                <div
                  key={food.id}
                  className="rounded-2xl overflow-hidden bg-[#0D0D11] border border-white/10 hover:border-amber-400/40 transition-all duration-300 flex flex-col justify-between group shadow-xl"
                >
                  <div>
                    <div className="relative aspect-[16/10] w-full overflow-hidden bg-black">
                      <img
                        src={food.imageUrl}
                        alt={food.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 brightness-90"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D11] via-transparent to-black/40" />

                      <div className="absolute top-3 left-3 px-2.5 py-1 rounded-md text-[10px] font-mono uppercase bg-black/80 backdrop-blur-md border border-white/15 text-amber-400">
                        {food.cuisine}
                      </div>
                      <div className="absolute top-3 right-3 px-2.5 py-1 rounded-md text-[10px] font-mono uppercase bg-black/80 backdrop-blur-md border border-white/15 text-emerald-400">
                        {food.isVegetarian ? 'PURE VEG' : 'AUTHENTIC'}
                      </div>
                    </div>

                    <div className="p-5 space-y-3">
                      <h4 className="font-cinzel text-lg font-bold text-white group-hover:text-amber-400 transition-colors">
                        {food.name}
                      </h4>
                      <p className="text-xs text-[#A1A1AA] line-clamp-2 font-light leading-relaxed">
                        {food.description}
                      </p>

                      {/* Famous Establishment Card */}
                      {food.famousEstablishment && (
                        <div className="p-3.5 rounded-xl bg-[#14141A] border border-white/10 space-y-1 text-xs">
                          <span className="text-[10px] font-mono tracking-widest text-amber-400 uppercase block">
                            AUTHENTIC ESTABLISHMENT:
                          </span>
                          <p className="font-bold text-white">{food.famousEstablishment.name}</p>
                          <p className="text-[11px] text-[#71717A] truncate">{food.famousEstablishment.address}</p>
                          <div className="flex items-center justify-between text-[11px] font-mono text-[#D4D4D8] pt-1">
                            <span>Approx ₹{food.famousEstablishment.approxPriceForTwoINR} for two</span>
                            <span className="text-amber-400 font-bold">★ {food.famousEstablishment.rating}</span>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="p-5 pt-0 text-[11px] font-mono text-[#A1A1AA] border-t border-white/5 mt-2 flex items-center justify-between">
                    <span>{food.source || 'Heritage Culinary Record'}</span>
                    <span className="text-emerald-400">VERIFIED</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* SECTION: ROUTES & TRANSIT */}
        {activeSection === 'routes' && (
          <div className="space-y-8">
            <div className="p-8 rounded-3xl bg-[#0D0D11] border border-white/10 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-6">
                <div>
                  <span className="text-xs font-mono tracking-widest text-amber-400 uppercase">
                    POINT-TO-POINT ROUTING ENGINE
                  </span>
                  <h3 className="font-cinzel text-2xl sm:text-4xl font-bold text-white uppercase">
                    ROUTES & TRAVEL TIMES
                  </h3>
                </div>
                <button
                  onClick={calculateRoute}
                  disabled={routingLoading}
                  className="px-4 py-2 rounded-full bg-amber-400 text-black text-xs font-mono font-bold uppercase tracking-wider cursor-pointer shadow-md hover:bg-amber-300"
                >
                  {routingLoading ? 'CALCULATING...' : 'RECALCULATE ROUTE'}
                </button>
              </div>

              {/* Route Selector Controls */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-mono text-[#A1A1AA] uppercase block">
                    Starting Origin:
                  </label>
                  <select
                    value={routeOrigin}
                    onChange={(e) => setRouteOrigin(e.target.value)}
                    className="w-full px-4 py-3 bg-[#14141A] border border-white/15 rounded-xl text-xs font-mono text-white focus:outline-none focus:border-amber-400 cursor-pointer"
                  >
                    <option value="hotel">Recommended Heritage Hotel</option>
                    <option value="airport">Nearest Airport ({destination.connectivity.nearestAirport.code})</option>
                    <option value="citycenter">City Center Hub</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-mono text-[#A1A1AA] uppercase block">
                    Target Destination:
                  </label>
                  <select
                    value={routeDestination}
                    onChange={(e) => setRouteDestination(e.target.value)}
                    className="w-full px-4 py-3 bg-[#14141A] border border-white/15 rounded-xl text-xs font-mono text-white focus:outline-none focus:border-amber-400 cursor-pointer"
                  >
                    <option value="attraction">Primary Heritage Monument ({attractions[0]?.name || 'Monument'})</option>
                    <option value="restaurant">Legendary Heritage Restaurant</option>
                  </select>
                </div>
              </div>

              {/* Route Computation Result Card */}
              {routeResult && (
                <div className="p-6 rounded-2xl bg-[#14141A] border border-white/10 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-4">
                    <div className="space-y-1">
                      <span className="text-[10px] font-mono uppercase text-amber-400 block">DRIVE ESTIMATE</span>
                      <h4 className="font-cinzel text-xl font-bold text-white">
                        {routeResult.distanceText || '12.4 km'} • {routeResult.durationText || '25 min'}
                      </h4>
                    </div>
                    <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-950/60 border border-emerald-500/30 text-emerald-400 text-xs font-mono">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Optimized Highway Route</span>
                    </div>
                  </div>

                  {routeResult.steps && routeResult.steps.length > 0 && (
                    <div className="space-y-2">
                      <span className="text-xs font-mono text-[#A1A1AA] uppercase block">TURN-BY-TURN GUIDELINES:</span>
                      <div className="space-y-1.5 text-xs font-mono text-[#D4D4D8]">
                        {routeResult.steps.slice(0, 4).map((step: any, idx: number) => (
                          <div key={idx} className="flex items-start gap-2 p-2 rounded-lg bg-black/40 border border-white/5">
                            <span className="text-amber-400 font-bold">{idx + 1}.</span>
                            <span>{step.instruction || step.html_instructions?.replace(/<[^>]+>/g, '') || `Proceed along primary thoroughfare towards ${destination.name}`}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Highway Connectivity */}
              <div className="p-6 rounded-2xl bg-[#14141A] border border-white/10 space-y-2">
                <span className="text-xs font-mono text-amber-400 uppercase font-bold flex items-center gap-1.5">
                  <Car className="w-4 h-4 text-amber-400" />
                  HIGHWAY & EXPRESSWAY CONNECTIVITY:
                </span>
                <p className="text-xs sm:text-sm text-[#D4D4D8] font-light leading-relaxed">
                  {destination.connectivity.roadConnectivity}
                </p>
              </div>
            </div>
          </div>
        )}

      </div>

    </div>
  );
};
