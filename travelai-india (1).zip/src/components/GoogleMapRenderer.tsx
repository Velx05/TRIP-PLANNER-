// Source: Google Maps Platform Code Assist
// Google Maps JavaScript API Integration with @vis.gl/react-google-maps
// Supports Advanced Markers, InfoWindows, and Directions Polyline Rendering

import React, { useEffect, useRef, useState } from 'react';
import {
  APIProvider,
  Map,
  AdvancedMarker,
  Pin,
  InfoWindow,
  useMap,
} from '@vis.gl/react-google-maps';
import { Coordinates, Destination, Hotel, Attraction, FoodItem, DirectionsRoute, PlaceResult, RentalLocation } from '../types';
import { isHostelProperty } from '../utils/bookingLinks';
import { Layers, Key, Sparkles, ExternalLink, ArrowRight, MapPin, Route, Navigation, Clock, Tag, Star } from 'lucide-react';

export type MapFilterType = 
  | 'all' 
  | 'attractions' 
  | 'hotels' 
  | 'hostels' 
  | 'restaurants' 
  | 'car_rental' 
  | 'bike_rental' 
  | 'food';

interface GoogleMapRendererProps {
  apiKey: string;
  destinations: Destination[];
  mapData: {
    hotels: Hotel[];
    attractions: Attraction[];
    food: FoodItem[];
    rentals?: RentalLocation[];
  };
  filterType: MapFilterType;
  selectedDestinationId: string;
  activeRoute: DirectionsRoute | null;
  searchedPlaces: PlaceResult[];
  geocodedLocation: { address: string; coordinates: Coordinates } | null;
  userLocation?: Coordinates | null;
  destinationCoords?: Coordinates | null;
  destinationName?: string;
  onSelectItem: (item: any, type: string) => void;
  onSelectRouteDestination?: (item: any, type: string) => void;
  onMapClick?: (coords: Coordinates) => void;
  onSwitchToVector?: () => void;
}

// Polyline Subcomponent to draw active route on Google Map
const RoutePolyline: React.FC<{ polylinePoints: Coordinates[] }> = ({ polylinePoints }) => {
  const map = useMap();
  const polylineRef = useRef<google.maps.Polyline | null>(null);

  useEffect(() => {
    if (!map || polylinePoints.length < 2) {
      if (polylineRef.current) {
        polylineRef.current.setMap(null);
        polylineRef.current = null;
      }
      return;
    }

    const path = polylinePoints.map((p) => ({ lat: p.lat, lng: p.lng }));

    if (!polylineRef.current) {
      polylineRef.current = new google.maps.Polyline({
        path,
        geodesic: true,
        strokeColor: '#F27D26',
        strokeOpacity: 0.9,
        strokeWeight: 5,
        map,
      });
    } else {
      polylineRef.current.setPath(path);
      polylineRef.current.setMap(map);
    }

    // Fit map bounds to encompass the route
    const bounds = new google.maps.LatLngBounds();
    path.forEach((pt) => bounds.extend(pt));
    map.fitBounds(bounds, { top: 60, right: 60, bottom: 60, left: 60 });

    return () => {
      if (polylineRef.current) {
        polylineRef.current.setMap(null);
        polylineRef.current = null;
      }
    };
  }, [map, polylinePoints]);

  return null;
};

// Camera updater for destination selection
const MapCameraController: React.FC<{
  center: Coordinates;
  zoom: number;
  selectedDestinationId: string;
}> = ({ center, zoom, selectedDestinationId }) => {
  const map = useMap();

  useEffect(() => {
    if (map) {
      map.panTo({ lat: center.lat, lng: center.lng });
      map.setZoom(zoom);
    }
  }, [map, center.lat, center.lng, zoom, selectedDestinationId]);

  return null;
};

export const GoogleMapRenderer: React.FC<GoogleMapRendererProps> = ({
  apiKey,
  destinations,
  mapData,
  filterType,
  selectedDestinationId,
  activeRoute,
  searchedPlaces,
  geocodedLocation,
  userLocation,
  destinationCoords,
  destinationName,
  onSelectItem,
  onSelectRouteDestination,
  onMapClick,
  onSwitchToVector,
}) => {
  const [selectedMarker, setSelectedMarker] = useState<{
    position: Coordinates;
    title: string;
    type: string;
    data: any;
  } | null>(null);

  // Validate that apiKey is a genuine Google Maps API Key (typically starts with AIza...)
  const isGoogleKeyValid = Boolean(apiKey && apiKey.trim().length > 20 && apiKey.startsWith('AIza'));

  // If no valid Google Maps API Key is configured, gracefully switch to vector or render clean status
  if (!isGoogleKeyValid) {
    if (onSwitchToVector) {
      onSwitchToVector();
      return null;
    }
    return (
      <div className="w-full h-full min-h-[520px] relative rounded-2xl overflow-hidden bg-[#121217] border border-white/10 flex flex-col items-center justify-center p-8 text-center space-y-3">
        <div className="w-12 h-12 rounded-xl bg-amber-400/10 border border-amber-400/20 flex items-center justify-center text-amber-400">
          <Key className="w-6 h-6" />
        </div>
        <p className="text-xs text-zinc-400 font-mono">
          Google Maps key not configured. Using Vector Map engine.
        </p>
      </div>
    );
  }

  // Compute map center based on selected destination
  let mapCenter: Coordinates = { lat: 22.5937, lng: 78.9629 };
  let zoomLevel = 5;

  if (selectedDestinationId !== 'all') {
    const dest = destinations.find((d) => d.id === selectedDestinationId);
    if (dest) {
      mapCenter = dest.coordinates;
      zoomLevel = 12;
    }
  } else if (geocodedLocation) {
    mapCenter = geocodedLocation.coordinates;
    zoomLevel = 14;
  }

  // Collect items to plot
  const itemsToPlot: Array<{
    type: 'destination' | 'attraction' | 'hotel' | 'hostel' | 'food' | 'car_rental' | 'bike_rental';
    data: any;
    coords: Coordinates;
    title: string;
  }> = [];

  if (selectedDestinationId === 'all' && (filterType === 'all' || filterType === 'attractions')) {
    destinations.forEach((d) => {
      itemsToPlot.push({
        type: 'destination',
        data: d,
        coords: d.coordinates,
        title: d.name,
      });
    });
  }

  if (filterType === 'all' || filterType === 'attractions') {
    mapData.attractions
      .filter((a) => selectedDestinationId === 'all' || a.destinationId === selectedDestinationId)
      .forEach((a) => {
        if (a.coordinates) {
          itemsToPlot.push({
            type: 'attraction',
            data: a,
            coords: a.coordinates,
            title: a.name,
          });
        }
      });
  }

  if (filterType === 'all' || filterType === 'hotels') {
    mapData.hotels
      .filter((h) => selectedDestinationId === 'all' || h.destinationId === selectedDestinationId)
      .filter((h) => !isHostelProperty(h))
      .forEach((h) => {
        if (h.coordinates) {
          itemsToPlot.push({
            type: 'hotel',
            data: h,
            coords: h.coordinates,
            title: h.name,
          });
        }
      });
  }

  if (filterType === 'all' || filterType === 'hostels') {
    mapData.hotels
      .filter((h) => selectedDestinationId === 'all' || h.destinationId === selectedDestinationId)
      .filter((h) => isHostelProperty(h))
      .forEach((h) => {
        if (h.coordinates) {
          itemsToPlot.push({
            type: 'hostel',
            data: h,
            coords: h.coordinates,
            title: h.name,
          });
        }
      });
  }

  if (filterType === 'all' || filterType === 'restaurants' || filterType === 'food') {
    mapData.food
      .filter((f) => selectedDestinationId === 'all' || f.destinationId === selectedDestinationId)
      .forEach((f) => {
        const coords = f.coordinates || f.famousEstablishment?.coordinates;
        if (coords) {
          itemsToPlot.push({
            type: 'food',
            data: f,
            coords,
            title: f.famousEstablishment?.name || f.name,
          });
        }
      });
  }

  if (filterType === 'all' || filterType === 'car_rental') {
    (mapData.rentals || [])
      .filter((r) => selectedDestinationId === 'all' || r.destinationId === selectedDestinationId)
      .filter((r) => r.rentalType === 'car')
      .forEach((r) => {
        if (r.coordinates) {
          itemsToPlot.push({
            type: 'car_rental',
            data: r,
            coords: r.coordinates,
            title: r.name,
          });
        }
      });
  }

  if (filterType === 'all' || filterType === 'bike_rental') {
    (mapData.rentals || [])
      .filter((r) => selectedDestinationId === 'all' || r.destinationId === selectedDestinationId)
      .filter((r) => r.rentalType === 'bike')
      .forEach((r) => {
        if (r.coordinates) {
          itemsToPlot.push({
            type: 'bike_rental',
            data: r,
            coords: r.coordinates,
            title: r.name,
          });
        }
      });
  }

  return (
    <APIProvider apiKey={apiKey} libraries={['places', 'routes', 'geometry', 'core']}>
      <div className="w-full h-full min-h-[520px] relative rounded-2xl overflow-hidden">
        <Map
          defaultCenter={{ lat: mapCenter.lat, lng: mapCenter.lng }}
          defaultZoom={zoomLevel}
          mapId="VVT_INDIA_MAP"
          internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
          gestureHandling="greedy"
          disableDefaultUI={false}
          className="w-full h-full min-h-[520px]"
          onClick={(e) => {
            if (e.detail.latLng && onMapClick) {
              onMapClick({ lat: e.detail.latLng.lat, lng: e.detail.latLng.lng });
            }
          }}
        >
          <MapCameraController
            center={mapCenter}
            zoom={zoomLevel}
            selectedDestinationId={selectedDestinationId}
          />

          {/* Route polyline */}
          {activeRoute && activeRoute.polylinePoints.length > 0 && (
            <RoutePolyline polylinePoints={activeRoute.polylinePoints} />
          )}

          {/* User Location Origin Marker */}
          {(userLocation || activeRoute?.originCoords) && (
            <AdvancedMarker
              position={{
                lat: (activeRoute?.originCoords || userLocation)!.lat,
                lng: (activeRoute?.originCoords || userLocation)!.lng,
              }}
              title={activeRoute?.originName || 'Your Current Location'}
            >
              <Pin background="#10B981" glyphColor="#FFFFFF" borderColor="#FFFFFF" scale={1.2} />
            </AdvancedMarker>
          )}

          {/* User Destination Marker */}
          {(destinationCoords || activeRoute?.destinationCoords) && (
            <AdvancedMarker
              position={{
                lat: (activeRoute?.destinationCoords || destinationCoords)!.lat,
                lng: (activeRoute?.destinationCoords || destinationCoords)!.lng,
              }}
              title={activeRoute?.destinationName || destinationName || 'Destination'}
            >
              <Pin background="#F27D26" glyphColor="#000000" borderColor="#FFFFFF" scale={1.2} />
            </AdvancedMarker>
          )}

          {/* Destination & Verified Items Advanced Markers */}
          {itemsToPlot.map((item, idx) => {
            let bg = '#F27D26';
            let glyphColor = '#FFFFFF';
            let borderColor = '#000000';

            if (item.type === 'destination') {
              bg = '#E11D48'; // Rose
            } else if (item.type === 'attraction') {
              bg = '#D97706'; // Amber
            } else if (item.type === 'hotel') {
              bg = '#9333EA'; // Purple
            } else if (item.type === 'hostel') {
              bg = '#06B6D4'; // Cyan
            } else if (item.type === 'food') {
              bg = '#10B981'; // Emerald
            } else if (item.type === 'car_rental') {
              bg = '#3B82F6'; // Blue
            } else if (item.type === 'bike_rental') {
              bg = '#F97316'; // Orange
            }

            return (
              <AdvancedMarker
                key={`${item.type}-${item.data.id || idx}`}
                position={{ lat: item.coords.lat, lng: item.coords.lng }}
                title={item.title}
                onClick={() => {
                  setSelectedMarker({
                    position: item.coords,
                    title: item.title,
                    type: item.type,
                    data: item.data,
                  });
                  onSelectItem(item.data, item.type);
                }}
              >
                <Pin
                  background={bg}
                  glyphColor={glyphColor}
                  borderColor={borderColor}
                />
              </AdvancedMarker>
            );
          })}

          {/* Live Searched Places Markers (Places API) */}
          {searchedPlaces.map((place) => {
            if (!place.location) return null;
            return (
              <AdvancedMarker
                key={`place-${place.id}`}
                position={{ lat: place.location.lat, lng: place.location.lng }}
                title={place.displayName.text}
                onClick={() => {
                  setSelectedMarker({
                    position: place.location!,
                    title: place.displayName.text,
                    type: 'place',
                    data: place,
                  });
                  onSelectItem(place, 'place');
                }}
              >
                <Pin background="#3B82F6" glyphColor="#FFFFFF" borderColor="#1E3A8A" />
              </AdvancedMarker>
            );
          })}

          {/* Geocoded Location Marker */}
          {geocodedLocation && (
            <AdvancedMarker
              position={{ lat: geocodedLocation.coordinates.lat, lng: geocodedLocation.coordinates.lng }}
              title={geocodedLocation.address}
              onClick={() => {
                setSelectedMarker({
                  position: geocodedLocation.coordinates,
                  title: 'Geocoded Address',
                  type: 'geocode',
                  data: geocodedLocation,
                });
              }}
            >
              <Pin background="#EC4899" glyphColor="#FFFFFF" borderColor="#831843" />
            </AdvancedMarker>
          )}

          {/* InfoWindow for selected pin */}
          {selectedMarker && (
            <InfoWindow
              position={{ lat: selectedMarker.position.lat, lng: selectedMarker.position.lng }}
              onCloseClick={() => setSelectedMarker(null)}
            >
              <div className="p-2 max-w-[280px] text-stone-900 font-sans space-y-1.5">
                {/* Category Badge */}
                <div className="flex items-center justify-between gap-1">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-amber-600 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                    {selectedMarker.type === 'destination' ? 'Destination' :
                     selectedMarker.type === 'attraction' ? (selectedMarker.data.category || 'Attraction') :
                     selectedMarker.type === 'hotel' ? (selectedMarker.data.hotelCategory || 'Hotel & Stay') :
                     selectedMarker.type === 'hostel' ? 'Backpacker Hostel' :
                     selectedMarker.type === 'food' ? (selectedMarker.data.cuisine ? `${selectedMarker.data.cuisine} Cuisine` : 'Restaurant / Eatery') :
                     selectedMarker.type === 'car_rental' ? 'Car Rental' :
                     selectedMarker.type === 'bike_rental' ? 'Bike Rental' : selectedMarker.type.toUpperCase()}
                  </span>
                  {selectedMarker.data.rating && (
                    <div className="flex items-center gap-0.5 text-xs text-amber-600 font-bold">
                      <Star className="w-3 h-3 fill-amber-400 text-amber-500" />
                      <span>{selectedMarker.data.rating}</span>
                      {selectedMarker.data.reviewCount && (
                        <span className="text-stone-400 text-[10px] font-normal">
                          ({selectedMarker.data.reviewCount})
                        </span>
                      )}
                    </div>
                  )}
                </div>

                {/* Place Name */}
                <h4 className="font-bold text-sm leading-snug text-stone-900">{selectedMarker.title}</h4>

                {/* Address */}
                {(selectedMarker.data.address || selectedMarker.data.formattedAddress || selectedMarker.data.state) && (
                  <div className="flex items-start gap-1 text-[11px] text-stone-600">
                    <MapPin className="w-3 h-3 text-stone-400 shrink-0 mt-0.5" />
                    <span className="line-clamp-2">
                      {selectedMarker.data.address || selectedMarker.data.formattedAddress || `${selectedMarker.data.destinationName || ''}, ${selectedMarker.data.state || ''}`}
                    </span>
                  </div>
                )}

                {/* Price (if available) */}
                {(() => {
                  let priceStr: string | null = null;
                  if (selectedMarker.type === 'attraction') {
                    priceStr = selectedMarker.data.entryFeeINR === 0 ? 'Free Entry (₹0)' : selectedMarker.data.entryFeeINR ? `Entry: ₹${selectedMarker.data.entryFeeINR} / person` : null;
                  } else if (selectedMarker.type === 'hotel' || selectedMarker.type === 'hostel') {
                    priceStr = selectedMarker.data.pricePerNightINR ? `₹${selectedMarker.data.pricePerNightINR.toLocaleString()} / night` : null;
                  } else if (selectedMarker.type === 'food') {
                    priceStr = selectedMarker.data.priceINR ? `₹${selectedMarker.data.priceINR} / person` : selectedMarker.data.famousEstablishment?.approxPriceForTwoINR ? `₹${selectedMarker.data.famousEstablishment.approxPriceForTwoINR} for two` : null;
                  } else if (selectedMarker.type === 'car_rental' || selectedMarker.type === 'bike_rental') {
                    priceStr = selectedMarker.data.priceText || (selectedMarker.data.pricePerDayINR ? `₹${selectedMarker.data.pricePerDayINR.toLocaleString()} / day` : null);
                  }
                  if (!priceStr) return null;
                  return (
                    <div className="flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      <Tag className="w-3 h-3 text-emerald-600" />
                      <span>{priceStr}</span>
                    </div>
                  );
                })()}

                {/* Opening hours (if available) */}
                {(selectedMarker.data.openingHours || selectedMarker.data.famousEstablishment?.openingHours) && (
                  <div className="flex items-center gap-1 text-[10px] text-stone-500">
                    <Clock className="w-3 h-3 text-stone-400 shrink-0" />
                    <span className="truncate">
                      {selectedMarker.data.openingHours || selectedMarker.data.famousEstablishment?.openingHours}
                    </span>
                  </div>
                )}

                {/* Available details (description / significance / fleet) */}
                {(selectedMarker.data.description || selectedMarker.data.localSignificance || selectedMarker.data.fleet) && (
                  <p className="text-[10px] text-stone-600 line-clamp-2 leading-relaxed bg-stone-50 p-1.5 rounded">
                    {selectedMarker.data.description || selectedMarker.data.localSignificance || `Fleet: ${(selectedMarker.data.fleet || []).join(', ')}`}
                  </p>
                )}

                {/* Action Buttons */}
                <div className="pt-1 flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      onSelectItem(selectedMarker.data, selectedMarker.type);
                      setSelectedMarker(null);
                    }}
                    className="flex-1 py-1.5 text-center bg-stone-900 hover:bg-stone-800 text-white rounded-lg text-[11px] font-semibold cursor-pointer transition-colors"
                  >
                    View Details
                  </button>

                  {onSelectRouteDestination && (
                    <button
                      type="button"
                      onClick={() => {
                        onSelectRouteDestination(selectedMarker.data, selectedMarker.type);
                        setSelectedMarker(null);
                      }}
                      className="py-1.5 px-2.5 text-center bg-amber-500 hover:bg-amber-600 text-black font-bold rounded-lg text-[11px] cursor-pointer transition-colors flex items-center justify-center gap-1"
                      title="Route to this location"
                    >
                      <Navigation className="w-3 h-3" />
                      <span>Route</span>
                    </button>
                  )}
                </div>
              </div>
            </InfoWindow>
          )}
        </Map>
      </div>
    </APIProvider>
  );
};
